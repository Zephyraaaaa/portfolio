import assert from 'node:assert/strict';
import { mkdir, readFile } from 'node:fs/promises';
import { fileURLToPath } from 'node:url';
import { chromium, devices } from 'playwright-core';

const file = new URL('dist/a-london-christmas-atlas.html', import.meta.url);
const output = new URL('screenshots-v4/', import.meta.url);
const stopsDir = new URL('stops/', output);
await mkdir(stopsDir, { recursive: true });
const browser = await chromium.launch({
  executablePath: process.env.CHROME_PATH || (process.platform === 'win32' ?
    'C:/Program Files/Google/Chrome/Application/chrome.exe' : undefined),
  headless: true,
  args: ['--enable-unsafe-swiftshader'],
});
const errors = [];
const requests = [];
async function open(options) {
  const page = await browser.newPage({ offline: true, ...options });
  page.on('request', req => { if (/^https?:/.test(req.url())) requests.push(req.url()); });
  page.on('pageerror', err => errors.push(err.message));
  page.on('console', msg => { if (msg.type() === 'error') errors.push(msg.text()); });
  await page.goto(file.href);
  await page.locator('#viewport[data-ready="true"]').waitFor({ timeout: 45000 });
  return page;
}
const buttons = (page, name) => page.getByRole('button', { name, exact: true });
const choose = (page, id) => page.locator('#location-select').selectOption(id);
const stage = page => page.locator('#stage');
const frame = page => page.evaluate(() => new Promise(resolve =>
  requestAnimationFrame(() => requestAnimationFrame(resolve))));
const shot = (page, name) => page.screenshot({
  path: fileURLToPath(new URL(name + '.png', output)), fullPage: false,
});

async function hotspot(page, test, points, click = false) {
  const viewport = page.locator('#viewport');
  await viewport.scrollIntoViewIfNeeded();
  const box = await viewport.boundingBox();
  for (const [x, y] of points) {
    const px = box.x + box.width * x, py = box.y + box.height * y;
    await page.mouse.move(px, py);
    const value = await viewport.getAttribute('data-story-hotspot');
    if (value && test(value)) {
      if (click) await page.mouse.click(px, py);
      return value;
    }
  }
  throw new Error('The scene prop was not found at the tested positions');
}

try {
  const desktop = await open({ viewport: { width: 1500, height: 1080 }, reducedMotion: 'reduce' });
  assert.equal(await desktop.locator('#location-select').inputValue(), 'covent');
  const options = await desktop.locator('#location-select option').evaluateAll(options =>
    options.map(option => [option.value, option.textContent]));
  assert.equal(options.length, 13);
  const sheet = [];
  for (const [index, [id, name]] of options.entries()) {
    await choose(desktop, id);
    await frame(desktop);
    assert.equal(await desktop.locator('#landmark-title').textContent(), name);
    assert.equal(await stage(desktop).getAttribute('data-scene'), 'atlas');
    const path = fileURLToPath(new URL(String(index + 1).padStart(2, '0') + '-' + id + '.jpg', stopsDir));
    await stage(desktop).screenshot({ path, type: 'jpeg', quality: 88 });
    sheet.push({ name, src: 'data:image/jpeg;base64,' + (await readFile(path)).toString('base64') });
    console.log('Rendered', name);
  }
  await shot(desktop, '01-covent-garden');
  await buttons(desktop, 'Street level').click();
  await frame(desktop);
  await shot(desktop, '02-apple-market-aisle');
  await buttons(desktop, 'Day').click();
  await choose(desktop, 'trafalgar');
  await frame(desktop);
  await shot(desktop, '03-trafalgar-day');
  await buttons(desktop, 'Night').click();
  await choose(desktop, 'fortnum');
  await frame(desktop);
  await shot(desktop, '04-fortnum-night');
  const dots = [.47, .51, .55, .60, .65, .70].flatMap(x => [.28, .33, .38, .43, .48, .53].map(y => [x, y]));
  const door = await hotspot(desktop, value => value.startsWith('advent:'), dots, true);
  await desktop.getByRole('dialog', { name: 'December ' + door.split(':')[1] }).waitFor();
  await buttons(desktop, 'Close Advent window').click();

  await buttons(desktop, 'Dusk').click();
  await desktop.getByRole('button', { name: /The Christmas sitting room/ }).click();
  await frame(desktop);
  assert.equal(await stage(desktop).getAttribute('data-scene'), 'room');
  await shot(desktop, '05-sitting-room');
  await buttons(desktop, 'Open window').click();
  assert.equal(await stage(desktop).getAttribute('data-window'), 'open');
  await buttons(desktop, 'Window view').click();
  await frame(desktop);
  assert.equal(await stage(desktop).getAttribute('data-viewpoint'), 'window');
  await shot(desktop, '06-window-view');
  await buttons(desktop, 'Close window').click();
  assert.equal(await stage(desktop).getAttribute('data-window'), 'closed');
  await buttons(desktop, 'Fireworks').click();
  assert.equal(await buttons(desktop, 'Fireworks').getAttribute('aria-pressed'), 'false');
  await buttons(desktop, 'Fireworks').click();

  await buttons(desktop, 'Music').click();
  const musicDialog = desktop.getByRole('dialog', { name: 'All I Want for Christmas Is You' });
  await musicDialog.waitFor();
  assert.equal(await musicDialog.locator('#official-track').getAttribute('href'), 'https://www.youtube.com/watch?v=fRyhqobl0sk');
  const sound = musicDialog.locator('#street-music');
  await buttons(desktop, 'Use the previous street soundtrack').click();
  await desktop.waitForFunction(() => document.getElementById('street-music').currentTime > .05);
  await musicDialog.locator('#track-file').setInputFiles(fileURLToPath(new URL('assets/london-christmas-original.mp3', import.meta.url)));
  await desktop.waitForFunction(() => {
    const sound = document.getElementById('street-music');
    return sound.src.startsWith('blob:') && sound.duration > 18;
  });
  assert(await sound.evaluate(el => el.loop && el.duration < 21));
  await sound.evaluate(el => el.pause());
  await buttons(desktop, 'Close music').click();
  await desktop.close();

  const motion = await open({ viewport: { width: 1440, height: 1020 } });
  await motion.getByRole('button', { name: /Walk Regent Street/ }).click();
  const roomMarker = buttons(motion, 'Enter the sitting room through the window');
  await roomMarker.waitFor();
  await roomMarker.click();
  assert.equal(await stage(motion).getAttribute('data-scene'), 'room');
  assert.equal(await stage(motion).getAttribute('data-window'), 'open');
  await motion.getByRole('button', { name: /Walk Regent Street/ }).click();
  await buttons(motion, 'By the bench').click();
  await motion.waitForTimeout(1350);
  const postcard = motion.getByRole('dialog', { name: 'A postcard from London' });
  assert.equal(await postcard.count(), 0);
  const benchPoints = [.51, .49, .55, .45].flatMap(x => [.67, .70, .73, .64].map(y => [x, y]));
  await hotspot(motion, id => id === 'postcard', benchPoints, true);
  await postcard.waitFor();
  await postcard.locator('.postcard-snow').waitFor();
  await motion.waitForTimeout(380);
  await shot(motion, '07-postcard-snow');
  await buttons(motion, 'Close postcard').click();
  await postcard.waitFor({ state: 'hidden' });
  assert.equal(await buttons(motion, 'By the bench').getAttribute('aria-pressed'), 'true');
  await motion.getByRole('button', { name: /Meet the street/ }).click();
  await buttons(motion, 'What’s in the bag?').click();
  assert.match(await motion.locator('#conversation-reply').textContent(), /first tree/);
  await motion.keyboard.press('Escape');
  await motion.close();

  const mobile = await open({ ...devices['Pixel 7'], reducedMotion: 'reduce' });
  await choose(mobile, 'dials');
  await frame(mobile);
  assert.equal(await mobile.locator('#landmark-title').textContent(), 'Seven Dials');
  await mobile.getByRole('button', { name: /The Christmas sitting room/ }).tap();
  await buttons(mobile, 'Window view').tap();
  await frame(mobile);
  assert.equal(await stage(mobile).getAttribute('data-window'), 'open');
  assert(await mobile.evaluate(() => document.documentElement.scrollWidth <= innerWidth));
  await mobile.close();

  const contact = await browser.newPage({ viewport: { width: 1560, height: 1200 }, deviceScaleFactor: 1, offline: true });
  await contact.setContent('<!doctype html><meta charset=utf-8><style>' +
    'body{margin:0;padding:36px;background:#19253b;color:#f4dfc3;font:16px Georgia,serif}h1{font:48px Georgia;margin:0 0 9px;letter-spacing:-2px}' +
    'p{margin:0 0 18px;color:#dbc1aa}main{display:grid;grid-template-columns:repeat(4,1fr);gap:12px}' +
    'figure{margin:0;background:#24314a;border:1px solid #82736d;border-radius:8px;overflow:hidden}img{display:block;width:100%;aspect-ratio:1.57;object-fit:cover}' +
    'figcaption{padding:8px 11px;font-size:18px}small{color:#f2c99c;font:700 11px Arial;margin-right:9px}' +
    'figure:last-child{grid-column:span 4;display:grid;grid-template-columns:1.55fr 1fr;align-items:center}figure:last-child img{aspect-ratio:1.83}figure:last-child figcaption{font-size:39px;padding:21px 29px}</style>' +
    '<h1>A London Christmas</h1><p>Field Editions · The 13 stops in blue hour</p><main></main>');
  await contact.evaluate(async data => {
    const main = document.querySelector('main');
    data.forEach(({ name, src }, index) => {
      const figure = document.createElement('figure');
      const image = new Image();
      image.src = src;
      const caption = document.createElement('figcaption');
      const number = document.createElement('small');
      number.textContent = String(index + 1).padStart(2, '0');
      caption.append(number, name);
      figure.append(image, caption);
      main.append(figure);
    });
    await Promise.all(Array.from(main.querySelectorAll('img'), image => image.decode()));
  }, sheet);
  await contact.screenshot({ path: fileURLToPath(new URL('08-atlas-contact-sheet.png', output)), fullPage: true });
  await contact.close();
  assert.deepEqual(errors, []);
  assert.deepEqual(requests, []);
  console.log('All thirteen destinations, the live window, the audio chooser and mobile controls passed offline Chrome checks.');
} finally {
  await browser.close();
}


