import * as T from 'three';
import './music.js';
import { makeAtlasTile, stops } from './atlas-places.js';
import { makeSittingRoom } from './sitting-room.js';
import { fireworks } from './fireworks.js';
import { batch, clamp, mat, mix, v } from './model.js';
import { buildTerrace, glassFinish } from './architecture.js';
import { buildDistrict } from './regent.js';
import { buildPeople, cast } from './people.js';
import { buildSleigh } from './sleigh.js';
import { reflections } from './finish.js';
import { buildStreet, busGlassFinish } from './street.js';
import { buildSnow } from './winter.js';
import { buildFestival } from './festival.js';
import { journalCovers, prepareStories } from './stories.js';

const viewport = document.getElementById('viewport');
const stage = document.getElementById('stage');
const status = document.getElementById('scene-status');
const timeName = document.getElementById('time-name');
const modes = [...document.querySelectorAll('[data-mode]')];
const viewButtons = [...document.querySelectorAll('[data-view]')];
const reduced = matchMedia('(prefers-reduced-motion: reduce)');
if (navigator.maxTouchPoints > 0) stage.dataset.touch = 'true';
const presets = {
  day: {
    title: 'Winter sun', sky: '#f0f5ff', ground: '#c4aa9a', key: '#ffe2b9', rim: '#cddcf1',
    skyPower: 1.34, keyPower: 2.33, rimPower: .56, warm: 0, glass: .0, dusk: 0, night: 0,
  },
  dusk: {
    title: 'Blue hour', sky: '#cad8ff', ground: '#9e7a85', key: '#edbeae', rim: '#a8bdff',
    skyPower: 1.37, keyPower: 1.07, rimPower: .96, warm: .87, glass: .83, dusk: 1, night: 0,
  },
  night: {
    title: 'After dark', sky: '#a4bce5', ground: '#776a76', key: '#a7c7f4', rim: '#a8c0f6',
    skyPower: .83, keyPower: .37, rimPower: .84, warm: 1, glass: 1, dusk: .12, night: 1,
  },
};
const colors = ['sky', 'ground', 'key', 'rim'];
const levels = ['skyPower', 'keyPower', 'rimPower', 'warm', 'glass', 'dusk', 'night'];

function values(mode) {
  return Object.fromEntries([...colors.map(key => [key, new T.Color(mode[key])]), ...levels.map(key => [key, mode[key]])]);
}

function run() {
  const renderer = new T.WebGLRenderer({ antialias: true, alpha: true, powerPreference: 'high-performance' });
  renderer.setClearColor(0, 0);
  renderer.setPixelRatio(Math.min(devicePixelRatio, 1.75));
  renderer.toneMapping = T.NeutralToneMapping;
  renderer.toneMappingExposure = 1.0;
  renderer.shadowMap.enabled = true;
  renderer.shadowMap.type = T.PCFShadowMap;
  renderer.shadowMap.autoUpdate = false;
  renderer.shadowMap.needsUpdate = true;
  renderer.domElement.setAttribute('aria-hidden', 'true');
  viewport.append(renderer.domElement);

  const scene = new T.Scene();
  scene.environment = reflections(renderer);
  const skyImage = document.getElementById('atlas-sky-image');
  const windowSky = new T.Texture(skyImage);
  windowSky.colorSpace = T.SRGBColorSpace;
  windowSky.needsUpdate = true;
  const display = fireworks(scene);
  const camera = new T.PerspectiveCamera(30, 1, .1, 120);
  const root = new T.Group();
  scene.add(root);
  const hemi = new T.HemisphereLight();
  const key = new T.DirectionalLight();
  key.position.set(-12, 9.1, 10.2);
  key.castShadow = true;
  key.shadow.mapSize.set(2048, 2048);
  Object.assign(key.shadow.camera, { left: -18, right: 15, top: 15, bottom: -13, near: .4, far: 51 });
  key.shadow.camera.updateProjectionMatrix();
  key.shadow.normalBias = .024;
  key.shadow.bias = -.00031;
  key.shadow.radius = 3.8;
  const rim = new T.DirectionalLight();
  rim.position.set(6, 7, -8);
  scene.add(hemi, key, rim);

  const draw = batch(root);
  const glass = glassFinish();
  const busGlass = [busGlassFinish(), busGlassFinish(true)];
  const districtWindows = [glass, glass.clone(), glass.clone()];
  districtWindows[1].emissive.set('#ffd3a2');
  districtWindows[2].emissive.set('#b6bbec');
  const bulbs = mat('#f3cd8c', { emissive: '#ffb967', emissiveIntensity: 0 });
  const covers = journalCovers();
  const walls = buildTerrace(draw, glass, bulbs);
  const { lampGlass, headlamp, busTrim, lights: streetLights, pools, benchBounds, rackBounds, busBounds } =
    buildStreet(root, draw, busGlass, bulbs, covers);
  const district = buildDistrict(root, districtWindows);
  const lights = [...streetLights, ...district.lamps];
  const festival = buildFestival(root, draw, walls, district.decorations);
  const people = buildPeople(root);
  const sleigh = buildSleigh(root);
  const snow = buildSnow(root);
  const atlasWeather = new T.Group();
  scene.add(atlasWeather);
  const atlasSnow = buildSnow(atlasWeather);
  draw.finish();

  let lightMode = document.documentElement.dataset.light;
  let lighting = values(presets[lightMode]), origin = lighting, destination = lighting;
  let start = 0, changing = false;

  function applyLighting() {
    const { sky, ground, key: keyTint, rim: rimTint, skyPower, keyPower, rimPower, warm, dusk, night } = lighting;
    hemi.color.copy(sky);
    hemi.groundColor.copy(ground);
    hemi.intensity = skyPower;
    key.color.copy(keyTint);
    key.intensity = keyPower;
    rim.color.copy(rimTint);
    rim.intensity = rimPower;
    glass.emissiveIntensity = lighting.glass * 1.84;
    districtWindows[1].emissiveIntensity = lighting.glass * 2.01;
    districtWindows[2].emissiveIntensity = lighting.glass * .71;
    for (const pane of busGlass) pane.emissiveIntensity = lighting.glass * 1.49;
    busTrim.emissiveIntensity = .10 + warm * 3.12;
    scene.environmentIntensity = .55 + warm * .25;
    sleigh.setLight(warm);
    lampGlass.emissiveIntensity = .12 + warm * 2.34;
    bulbs.emissiveIntensity = .12 + warm * 2.6;
    headlamp.emissiveIntensity = .08 + warm * 1.68;
    for (const { light, power } of lights) light.intensity = warm * power;
    for (const pool of pools) pool.opacity = warm * .53;
    festival.setLight(warm);
    snow.setNight(night);
    atlasSnow.setNight(night);
    stage.style.setProperty('--dusk', dusk.toFixed(4));
    stage.style.setProperty('--night', night.toFixed(4));
  }

  function setMode(mode) {
    if (mode === lightMode) return;
    lightMode = mode;
    document.documentElement.dataset.light = mode;
    timeName.textContent = presets[mode].title;
    for (const button of modes) button.setAttribute('aria-pressed', String(button.dataset.mode === mode));
    origin = lighting;
    destination = values(presets[mode]);
    start = performance.now();
    changing = true;
    invalidate();
  }
  modes.forEach(button => button.addEventListener('click', () => setMode(button.dataset.mode)));
  applyLighting();

  const atlasHome = { azimuth: .52, elevation: .443, zoom: .652, distance: 40, x: 0, y: 2.34, z: -.08 };
  const plaza = { azimuth: .26, elevation: .05, zoom: 1.04, distance: 14.0, x: -.12, y: 2.48, z: -.68 };
  const arcade = { azimuth: 1.55, elevation: -.037, zoom: 2.23, distance: 6.88, x: -1.53, y: 2.10, z: -3.20 };
  const roomHome = { azimuth: .48, elevation: .34, zoom: .97, distance: 23.5, x: .13, y: 1.86, z: -.04 };
  const windowView = { azimuth: .014, elevation: -.040, zoom: 2.57, distance: 4.14, x: .95, y: 2.70, z: -4.04 };
  const home = { azimuth: .56, elevation: .41, zoom: .545, distance: 53, x: -3.12, y: 3.62, z: 3.38 };
  const street = { azimuth: 1.40, elevation: -.074, zoom: .80, distance: 18.9, x: -4.10, y: 3.10, z: 4.02 };
  const bench = { azimuth: .23, elevation: .20, zoom: 2.25, distance: 29, x: -3.50, y: 1.48, z: 1.63 };
  const journalView = { azimuth: -.28, elevation: .23, zoom: 2.68, distance: 30, x: -.94, y: 1.25, z: 1.61 };
  const current = { ...atlasHome }, desired = { ...atlasHome };
  const focus = v(0, 0, 0);
  const orbitKeys = Object.keys(home);
  const orbitButton = document.querySelector('[data-view="orbit"]');

  const placeSelect = document.getElementById('location-select');
  const placeName = document.getElementById('landmark-title');
  const placeText = document.getElementById('landmark-note');
  const stageName = document.getElementById('current-scene');
  const sashToggle = document.getElementById('window-toggle');
  const fireToggle = document.getElementById('fireworks-toggle');
  const previousPlace = document.getElementById('previous-place');
  const nextPlace = document.getElementById('next-place');
  const calendar = document.getElementById('advent-note');
  let atlasTile, room, sceneKind = 'atlas', activeStop = stops.at(-1), showFireworks = true;
  let lastWindow = -Infinity, roomShadow = false;
  let orbiting = false;
  let width = 1, height = 1, dirty = true, onscreen = true, contextLost = false;
  let raf = 0, lastFrame = 0, worldTime = 0;

  function invalidate() {
    dirty = true;
    if (!raf && !document.hidden && onscreen && !contextLost) raf = requestAnimationFrame(frame);
  }

  function resize() {
    width = viewport.clientWidth;
    height = viewport.clientHeight;
    if (width && height) renderer.setSize(width, height, false);
    snow.resize(renderer.getPixelRatio());
    atlasSnow.resize(renderer.getPixelRatio());
    festival.resize(height * renderer.getPixelRatio());
    invalidate();
  }

  function updateCamera() {
    const { azimuth, elevation, zoom, distance } = current;
    focus.set(current.x, current.y, current.z);
    const ring = Math.cos(elevation) * distance;
    camera.position.copy(focus).add(v(Math.sin(azimuth) * ring, Math.sin(elevation) * distance, Math.cos(azimuth) * ring));
    camera.lookAt(focus);
    const aspect = width / height;
    const tiltRoom = Math.max(0, Math.sin(elevation) - Math.sin(home.elevation)) * 4.6;
    const baseWidth = sceneKind === 'atlas' ? 14.8 : sceneKind === 'room' ? 11.2 : 16.65;
    const viewHeight = Math.max(10.63 + tiltRoom, baseWidth / aspect) / zoom;
    camera.fov = 2 * T.MathUtils.radToDeg(Math.atan(viewHeight / (2 * distance)));
    camera.aspect = aspect;
    camera.updateProjectionMatrix();
    camera.updateMatrixWorld();
  }

  function frame(now) {
    raf = 0;
    if (document.hidden || !onscreen || contextLost || !width || !height) return;
    const dt = lastFrame ? clamp((now - lastFrame) / 1000, .001, .050) : .016;
    lastFrame = now;
    const still = reduced.matches;
    if (orbiting && !still && !stories.holdCamera) desired.azimuth += dt * .142;
    const cameraMoving = !stories.holdCamera && orbitKeys.some(key => current[key] !== desired[key]);
    if (cameraMoving || dirty) {
      const blend = stories.holdCamera ? 0 : still ? 1 : 1 - Math.exp(-15 * dt);
      for (const key of orbitKeys) {
        const next = mix(current[key], desired[key], blend);
        current[key] = Math.abs(next - desired[key]) < .0002 ? desired[key] : next;
      }
      updateCamera();
    }
    if (changing) {
      const t = still ? 1 : clamp((now - start) / 1250, 0, 1);
      const s = t * t * (3 - 2 * t);
      lighting = {};
      for (const key of colors) lighting[key] = origin[key].clone().lerp(destination[key], s);
      for (const key of levels) lighting[key] = mix(origin[key], destination[key], s);
      changing = t < 1;
      applyLighting();
    }
    if (!still && !stories.holdCamera) worldTime += dt;

    const atlas = sceneKind === 'atlas';
    const inside = sceneKind === 'room';
    const time = still ? 0 : worldTime;
    const ratio = renderer.getPixelRatio();
    display.update(time, ratio, lighting.warm, showFireworks, !atlas, still);
    if (atlas) {
      atlasTile.update(time, height * ratio, lighting.warm);
      atlasSnow.update(time);
    } else {
      snow.update(time);
      festival.animate(time);
      people.update(time, still);
      sleigh.update(time, still);
    }
    positionPeopleMarkers();
    if (inside) {
      room.update(time, dt, height * ratio, 1 - lighting.warm, still);
      if (dirty || now - lastWindow > 63) {
        renderWindow();
        lastWindow = now;
      }
      if (roomShadow) {
        renderer.shadowMap.needsUpdate = true;
        roomShadow = false;
      }
      renderer.render(room.scene, camera);
    } else renderer.render(scene, camera);
    if (viewport.dataset.ready !== 'true') {
      viewport.dataset.ready = 'true';
      status.hidden = true;
    }
    dirty = false;
    if ((!still && !stories.holdCamera) || changing || cameraMoving) raf = requestAnimationFrame(frame);
  }


  function renderWindow() {
    const outside = room.exteriorCamera;
    const offset = (camera.position.x - .95) * .105;
    outside.position.set(14.0, 2.78, 6.37 + offset);
    outside.lookAt(-4.70, 3.55, 3.62 + offset * .55);
    outside.updateMatrixWorld();
    scene.background = lighting.warm > .19 ? windowSky : new T.Color('#d2e4ee');
    renderer.setRenderTarget(room.renderTarget);
    renderer.render(scene, outside);
    renderer.setRenderTarget(null);
    scene.background = null;
  }

  function activate(kind, title, note) {
    sceneKind = kind;
    stage.dataset.scene = kind;
    stageName.textContent = title;
    placeName.textContent = title;
    placeText.textContent = note;
    root.visible = kind !== 'atlas';
    atlasWeather.visible = kind === 'atlas';
    if (atlasTile) atlasTile.group.visible = kind === 'atlas';
    sashToggle.hidden = kind !== 'room';
    const benchButton = viewButtons.find(button => button.dataset.view === 'bench');
    benchButton.hidden = kind !== 'street';
    const streetButton = viewButtons.find(button => button.dataset.view === 'street');
    streetButton.hidden = kind === 'room';
    const roomButton = viewButtons.find(button => button.dataset.view === 'window');
    roomButton.hidden = kind !== 'room';
    delete viewport.dataset.storyHotspot;
    if (calendar.open) calendar.close();
    if (kind === 'room') {
      roomShadow = true;
      lastWindow = -Infinity;
    }
    renderer.shadowMap.needsUpdate = true;
    setView('overview', true);
  }

  function selectPlace(id) {
    const place = stops.find(stop => stop.id === id);
    if (!place) return;
    if (atlasTile && activeStop.id !== id) {
      scene.remove(atlasTile.group);
      atlasTile.dispose();
      atlasTile = undefined;
    }
    activeStop = place;
    if (!atlasTile) {
      atlasTile = makeAtlasTile(activeStop);
      scene.add(atlasTile.group);
    }
    placeSelect.value = id;
    const index = stops.indexOf(place);
    previousPlace.disabled = index === 0;
    nextPlace.disabled = index === stops.length - 1;
    for (const button of document.querySelectorAll('[data-place]')) {
      button.setAttribute('aria-pressed', String(button.dataset.place === id));
    }
    activate('atlas', place.name, place.note);
  }

  function openRoom() {
    if (!room) room = makeSittingRoom(scene.environment, document.getElementById('room-rug'));
    activate('room', 'The Christmas sitting room', 'Open the casement and look out over the lights on Regent Street.');
  }

  function walkStreet() {
    activate('street', 'Regent Street at Christmas', 'Walk beneath the angels, meet the people on the pavement and look for the postcard by the bench.');
  }

  function setWindow(open) {
    room.setOpen(open);
    sashToggle.textContent = open ? 'Close window' : 'Open window';
    sashToggle.setAttribute('aria-pressed', String(open));
    stage.dataset.window = open ? 'open' : 'closed';
    invalidate();
  }
  sashToggle.addEventListener('click', () => setWindow(!room.isOpen));
  fireToggle.addEventListener('click', () => {
    showFireworks = !showFireworks;
    fireToggle.setAttribute('aria-pressed', String(showFireworks));
    invalidate();
  });

  const placesGrid = document.getElementById('places-grid');
  for (const [index, place] of stops.entries()) {
    const option = new Option(place.name, place.id);
    placeSelect.add(option);
    const button = document.createElement('button');
    button.type = 'button';
    button.dataset.place = place.id;
    button.innerHTML = '<span class="stop-no"></span><span class="stop-name"></span><small></small>';
    button.querySelector('.stop-no').textContent = String(index + 1).padStart(2, '0');
    button.querySelector('.stop-name').textContent = place.name;
    button.querySelector('small').textContent = place.zh;
    button.addEventListener('click', () => {
      selectPlace(place.id);
      stage.scrollIntoView({ block: 'start', behavior: reduced.matches ? 'instant' : 'smooth' });
    });
    placesGrid.append(button);
  }
  placeSelect.addEventListener('change', () => selectPlace(placeSelect.value));
  previousPlace.addEventListener('click', () => selectPlace(stops[stops.indexOf(activeStop) - 1]?.id));
  nextPlace.addEventListener('click', () => selectPlace(stops[stops.indexOf(activeStop) + 1]?.id));
  document.querySelectorAll('[data-explore]').forEach(button => button.addEventListener('click', () => {
    if (button.dataset.explore === 'room') openRoom();
    else if (button.dataset.explore === 'atlas') selectPlace(activeStop.id);
    else walkStreet();
  }));
  calendar.querySelector('button').addEventListener('click', () => calendar.close());
  calendar.addEventListener('close', () => viewport.focus({ preventScroll: true }));

  const pointers = new Map();
  const distance = () => {
    const [a, b] = pointers.values();
    return Math.hypot(a.x - b.x, a.y - b.y);
  };
  function zoomBy(factor) {
    stopOrbit();
    desired.zoom = clamp(desired.zoom * factor, .45, 2.75);
    invalidate();
  }
  function orbit(dx, dy) {
    stopOrbit();
    desired.azimuth -= dx;
    desired.elevation = clamp(desired.elevation + dy, -.09, 1.44);
    invalidate();
  }
  function showActiveView(view) {
    viewButtons.forEach(button => button.setAttribute('aria-pressed', String(button.dataset.view === view)));
  }
  function stopOrbit() {
    if (!orbiting) return;
    orbiting = false;
    desired.azimuth = current.azimuth;
    showActiveView('overview');
  }
  function setView(view, immediate = false) {
    if (view === 'orbit' && reduced.matches) return;
    if (view === 'orbit' && orbiting) {
      stopOrbit();
      return;
    }
    orbiting = view === 'orbit';
    const target = sceneKind === 'room' ? (view === 'window' ? windowView : roomHome) :
      sceneKind === 'atlas' ? (view === 'street' ? (activeStop.id === 'covent' ? arcade : plaza) : atlasHome) :
      ({ bench, street, journal: journalView }[view] ?? home);
    if (sceneKind === 'room' && view === 'window') setWindow(true);
    Object.assign(desired, target);
    desired.azimuth += Math.round((current.azimuth - target.azimuth) / (2 * Math.PI)) * 2 * Math.PI;
    if (immediate) Object.assign(current, desired);
    stage.dataset.viewpoint = ['bench', 'street', 'window'].includes(view) ? view : 'overview';
    showActiveView(view);
    invalidate();
  }
  const reset = () => setView('overview');
  let savedJournalView;
  const stories = prepareStories(covers, reduced, cast, dialog => {
    if (dialog.id === 'street-journal' && savedJournalView) {
      const { pose, viewpoint, active, spinning } = savedJournalView;
      Object.assign(desired, pose);
      stage.dataset.viewpoint = viewpoint;
      orbiting = spinning;
      showActiveView(active);
      savedJournalView = undefined;
    }
    invalidate();
  });

  function openStory(story, opener) {
    if (story === 'visit-room') {
      openRoom();
      setWindow(true);
      return;
    }
    if (story === 'window') {
      setWindow(!room.isOpen);
      return;
    }
    if (story.startsWith('advent:')) {
      calendar.querySelector('h2').textContent = 'December ' + story.split(':')[1];
      calendar.showModal();
      return;
    }
    if (story === 'journal' && sceneKind !== 'street') walkStreet();
    if (!stories.open(story, opener)) return;
    if (story !== 'journal') {
      Object.assign(desired, current);
    } else {
      savedJournalView = {
        pose: { ...current },
        viewpoint: stage.dataset.viewpoint ?? 'overview',
        active: viewButtons.find(button => button.getAttribute('aria-pressed') === 'true')?.dataset.view,
        spinning: orbiting,
      };
      setView('journal');
    }
    invalidate();
  }
  const markers = ['couple', 'photographer', 'pub'].map(id => {
    const role = cast.find(person => person.id === id);
    const button = document.createElement('button');
    button.type = 'button';
    button.className = 'people-marker';
    button.dataset.story = 'person:' + id;
    button.setAttribute('aria-haspopup', 'dialog');
    button.setAttribute('aria-controls', 'street-conversation');
    button.setAttribute('aria-label', 'Talk to ' + role.name);
    button.title = role.name;
    button.innerHTML = '<svg aria-hidden="true"><use href="#i-chat"/></svg><span></span>';
    button.lastElementChild.textContent = role.name;
    button.hidden = true;
    stage.append(button);
    return { button, person: people.actors.find(actor => actor.id === id) };
  });
  document.querySelectorAll('[data-story]').forEach(button => {
    button.addEventListener('click', () => openStory(button.dataset.story, button));
  });
  viewButtons.forEach(button => button.addEventListener('click', () => setView(button.dataset.view)));

  const ray = new T.Raycaster();
  const ndc = new T.Vector2();
  const hit = new T.Vector3();
  const homeWindow = new T.Box3(v(-4.95, 3.16, .82), v(-3.61, 4.49, 1.02));
  const windowMarker = document.getElementById('enter-room-marker');
  const windowAnchor = v(-4.27, 4.46, 1.03);
  const hotspots = [['postcard', benchBounds], ['journal', rackBounds], ['visit-room', homeWindow],
    ...people.actors.map(actor => ['person:' + actor.id, actor.bounds])];
  const occluders = [...walls, ...district.bounds, ...busBounds];
  const projection = new T.Vector3();
  const anchor = new T.Vector3();
  function blockingDistance() {
    let closest = Infinity;
    for (const bounds of occluders) {
      if (ray.ray.intersectBox(bounds, hit)) closest = Math.min(closest, ray.ray.origin.distanceToSquared(hit));
    }
    return closest;
  }
  function positionPeopleMarkers() {
    projection.copy(windowAnchor).project(camera);
    const showWindow = sceneKind === 'street' && stage.dataset.viewpoint !== 'bench' &&
      Math.abs(projection.x) < .90 && Math.abs(projection.y) < .82 && Math.abs(projection.z) < 1;
    windowMarker.hidden = true;
    if (showWindow) {
      ray.setFromCamera(projection, camera);
      if (blockingDistance() > camera.position.distanceToSquared(windowAnchor)) {
        windowMarker.hidden = false;
        windowMarker.style.left = ((projection.x + 1) * 50).toFixed(2) + '%';
        windowMarker.style.top = ((1 - projection.y) * 50).toFixed(2) + '%';
      }
    }
    for (const { button, person } of markers) {
      anchor.copy(person.actor.position);
      anchor.y += person.height * 1.94;
      projection.copy(anchor).project(camera);
      const inFrame = Math.abs(projection.x) < .92 && projection.y > -.84 && projection.y < .79 && Math.abs(projection.z) < 1;
      let visible = false;
      if (sceneKind === 'street' && inFrame && stage.dataset.viewpoint !== 'bench') {
        ray.setFromCamera(projection, camera);
        visible = blockingDistance() > camera.position.distanceToSquared(anchor);
      }
      button.hidden = !visible;
      if (visible) {
        button.style.left = ((projection.x + 1) * 50).toFixed(2) + '%';
        button.style.top = ((1 - projection.y) * 50).toFixed(2) + '%';
      }
    }
  }
  function storyAt(event) {
    const bounds = viewport.getBoundingClientRect();
    ndc.set((event.clientX - bounds.left) / bounds.width * 2 - 1, 1 - (event.clientY - bounds.top) / bounds.height * 2);
    ray.setFromCamera(ndc, camera);

    if (sceneKind === 'room') return ray.ray.intersectBox(room.bounds, hit) ? 'window' : null;
    if (sceneKind === 'atlas') {
      const door = atlasTile.interactive.find(item => ray.ray.intersectBox(item.box, hit));
      return door ? 'advent:' + door.day : null;
    }
    let closest = blockingDistance();
    let story = null;
    for (const [name, bounds] of hotspots) {
      if (!ray.ray.intersectBox(bounds, hit)) continue;
      const distance = ray.ray.origin.distanceToSquared(hit);
      if (distance < closest) {
        closest = distance;
        story = name;
      }
    }
    return story;
  }

  let clickCandidate = null;
  viewport.addEventListener('pointerdown', event => {
    if (event.button !== 0 || pointers.size >= 2) return;
    const story = pointers.size === 0 ? storyAt(event) : null;
    if (!story) stopOrbit();
    clickCandidate = story ? { story, id: event.pointerId, x: event.clientX, y: event.clientY } : null;
    viewport.setPointerCapture(event.pointerId);
    pointers.set(event.pointerId, { x: event.clientX, y: event.clientY });
  });
  viewport.addEventListener('pointermove', event => {
    const previous = pointers.get(event.pointerId);
    if (!previous) {
      const story = event.pointerType === 'mouse' ? storyAt(event) : null;
      if (story) viewport.dataset.storyHotspot = story;
      else delete viewport.dataset.storyHotspot;
      return;
    }
    if (clickCandidate) {
      if (Math.hypot(event.clientX - clickCandidate.x, event.clientY - clickCandidate.y) < 5) return;
      clickCandidate = null;
    }
    const pinching = pointers.size === 2;
    const before = pinching ? distance() : 0;
    pointers.set(event.pointerId, { x: event.clientX, y: event.clientY });
    if (pinching && before > 4) zoomBy(distance() / before);
    else if (!pinching) orbit((event.clientX - previous.x) * .008, (event.clientY - previous.y) * .007);
  });
  viewport.addEventListener('pointerleave', () => delete viewport.dataset.storyHotspot);
  viewport.addEventListener('pointerup', event => {
    if (clickCandidate?.id === event.pointerId && storyAt(event) === clickCandidate.story) {
      openStory(clickCandidate.story, viewport);
    }
  });
  for (const type of ['pointerup', 'pointercancel', 'lostpointercapture']) {
    viewport.addEventListener(type, event => {
      pointers.delete(event.pointerId);
      if (clickCandidate?.id === event.pointerId) clickCandidate = null;
    });
  }
  viewport.addEventListener('wheel', event => {
    event.preventDefault();
    const unit = event.deltaMode === 1 ? 16 : event.deltaMode === 2 ? height : 1;
    zoomBy(Math.exp(clamp(-event.deltaY * unit * .00115, -.35, .35)));
  }, { passive: false });
  viewport.addEventListener('keydown', event => {
    const actions = {
      ArrowLeft: () => orbit(-.19, 0), ArrowRight: () => orbit(.19, 0),
      ArrowUp: () => orbit(0, .12), ArrowDown: () => orbit(0, -.12),
      '+': () => zoomBy(1.16), '=': () => zoomBy(1.16), '-': () => zoomBy(1 / 1.16), Home: reset,
    };
    if (Object.hasOwn(actions, event.key)) {
      event.preventDefault();
      actions[event.key]();
    }
  });
  document.getElementById('zoom-in').addEventListener('click', () => zoomBy(1.21));
  document.getElementById('zoom-out').addEventListener('click', () => zoomBy(1 / 1.21));
  document.getElementById('reset').addEventListener('click', reset);
  new ResizeObserver(resize).observe(viewport);
  new IntersectionObserver(([entry]) => {
    onscreen = entry.isIntersecting;
    if (onscreen) invalidate();
  }).observe(stage);
  document.addEventListener('visibilitychange', invalidate);
  function syncMotionPreference() {
    orbitButton.disabled = reduced.matches;
    if (reduced.matches) stopOrbit();
    invalidate();
  }
  reduced.addEventListener('change', syncMotionPreference);
  renderer.domElement.addEventListener('webglcontextlost', event => {
    event.preventDefault();
    contextLost = true;
    status.textContent = 'The 3D view is reconnecting…';
    status.hidden = false;
  });
  renderer.domElement.addEventListener('webglcontextrestored', () => {
    contextLost = false;
    delete viewport.dataset.ready;
    renderer.shadowMap.needsUpdate = true;
    invalidate();
  });
  selectPlace('covent');
  syncMotionPreference();
  resize();
}

async function initialize() {
  try {
    await Promise.all([document.fonts.ready, document.getElementById('room-rug').decode(),
      document.getElementById('atlas-sky-image').decode()]);
    run();
  } catch (error) {
    console.error(error);
    status.textContent = 'The 3D scene needs a browser with WebGL 2 enabled.';
  }
}
initialize();


