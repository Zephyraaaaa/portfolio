import * as T from 'three';
import { box, cylinder, mat, random, texture, tube, v } from './model.js';

export const snow = mat('#e8edf0');
export const brass = mat('#d2a45e', { metalness: .42, roughness: .38 });
export const iron = mat('#1f292a', { roughness: .6 });
const green = mat('#1b4437');
const pale = mat('#e2d7bd');
const stone = mat('#b6aa94');
const slate = mat('#343b48');
const mortars = ['#8a6c60', '#8a695d', '#887268'];
const tones = ['#a45d4c', '#925040', '#ad6854'];
const rng = random(103);

function roofFinish() {
  const noise = random(216);
  const map = texture(768, 384, (ctx, w, h) => {
    ctx.fillStyle = '#354050';
    ctx.fillRect(0, 0, w, h);
    for (let row = 0; row < 8; row++) {
      for (let col = -1; col < 21; col++) {
        const x = col * 37 + (row % 2) * 18, y = row * 48;
        const tone = 64 + Math.floor(noise() * 22);
        ctx.fillStyle = 'rgb(' + tone + ',' + (tone + 8) + ',' + (tone + 16) + ')';
        ctx.fillRect(x + 1, y + 1, 36, 47);
        ctx.fillStyle = '#26303d9d';
        ctx.fillRect(x + 1, y + 45, 35, 3);
        const drift = Math.min(44, 14 + noise() * 29 + Math.sin(col * .54 + row * .57) * 12);
        ctx.fillStyle = noise() > .54 ? '#e0e9ec' : '#c9d6df';
        ctx.beginPath(); ctx.moveTo(x + 1, y + 1); ctx.lineTo(x + 36, y + 1);
        ctx.lineTo(x + 36, y + drift - 2);
        ctx.quadraticCurveTo(x + 25, y + drift - 8, x + 17, y + drift + 1);
        ctx.quadraticCurveTo(x + 10, y + drift + 5, x + 1, y + drift - 4);
        ctx.closePath(); ctx.fill();
      }
    }
    for (let i = 0; i < 13000; i++) {
      ctx.fillStyle = noise() > .5 ? '#fff1' : '#28293317';
      ctx.fillRect(noise() * w, noise() * h, 1 + noise() * 4, 1);
    }
  });
  map.anisotropy = 8;
  return mat('#ffffff', { map });
}

function brickFinish(base, mortar) {
  const map = texture(512, 256, (ctx, w, h) => {
    ctx.fillStyle = mortar;
    ctx.fillRect(0, 0, w, h);
    const colour = new T.Color(base);
    for (let row = 0; row < 8; row++) {
      for (let col = -1; col < 8; col++) {
        const x = col * 64 + (row % 2) * 32 + 1, y = row * 32 + 2;
        const brick = colour.clone().multiplyScalar(.79 + rng() * .44);
        ctx.fillStyle = brick.getStyle();
        ctx.fillRect(x, y, 61, 28);
        ctx.fillStyle = '#efbb9b42';
        ctx.fillRect(x + 1, y, 59, 2);
        ctx.fillStyle = '#341e2351';
        ctx.fillRect(x, y + 26, 61, 2);
        for (let i = 0; i < 62; i++) {
          ctx.fillStyle = rng() > .5 ? '#f1ccb02e' : '#2d192928';
          ctx.fillRect(x + rng() * 59, y + rng() * 26, 1 + rng() * 4, 1);
        }
      }
    }
  });
  map.wrapS = map.wrapT = T.RepeatWrapping;
  map.anisotropy = 8;
  return mat('#ffffff', { map });
}

function masonry(draw, finish, x, y, z, w, h, d) {
  const mesh = new T.BoxGeometry(w, h, d);
  const uv = mesh.attributes.uv;
  for (let i = 0; i < uv.count; i++) {
    const face = Math.floor(i / 4);
    uv.setXY(i, uv.getX(i) * (face < 2 ? d : w) / 2.36, uv.getY(i) * (face === 2 || face === 3 ? d : h) / .99);
  }
  draw.add(mesh, finish, x, y, z);
}

export function sign(draw, x, y, z, w, h, text, options = {}) {
  const { background = '#22483b', colour = '#f9dba0', serif = true, yaw = 0, transient = false } = options;
  const map = texture(768, Math.max(96, Math.round(768 * h / w)), (ctx, width, height) => {
    ctx.fillStyle = background;
    ctx.fillRect(0, 0, width, height);
    ctx.strokeStyle = colour;
    ctx.lineWidth = 2;
    ctx.strokeRect(9, 9, width - 18, height - 18);
    ctx.font = 'bold ' + Math.min(height * .46, width / (text.length * .61)) + 'px ' + (serif ? 'Georgia' : 'Arial');
    ctx.fillStyle = colour;
    ctx.textAlign = 'center';
    ctx.textBaseline = 'middle';
    ctx.fillText(text, width / 2, height / 2 + 1);
  });
  const material = mat('#ffffff', { map });
  material.userData.atlasOwned = transient;
  draw.add(new T.PlaneGeometry(w, h), material, x, y, z, yaw, false);
}

const leaves = ['#174436', '#245743', '#356553'].map(c => mat(c));
const berries = mat('#a92535');
const ribbon = mat('#a72f35');
const baubles = [mat('#c0333c', { metalness: .36 }), brass, mat('#c3d5d9', { metalness: .35 })];

export function greenery(draw, x, y, z, rx, ry = rx, count = 40) {
  for (let i = 0; i < count; i++) {
    const a = i * 2.39996;
    const r = .86 + rng() * .29;
    const lx = x + Math.cos(a) * rx * r;
    const ly = y + Math.sin(a) * ry * r;
    const lz = z + (rng() - .5) * .10;
    const geo = new T.SphereGeometry(1, 5, 3).scale(.095, .033, .027);
    draw.add(geo, leaves[i % 3], lx, ly, lz, rng() - .5, true, 0, a + .68);
    if (i % 7 === 0) draw.add(new T.SphereGeometry(.035, 6, 5), berries, lx, ly, lz + .043);
  }
}

export function glassFinish() {
  const map = texture(256, 256, (ctx, w, h) => {
    const tint = ctx.createLinearGradient(0, 0, w, h);
    tint.addColorStop(0, '#657b82');
    tint.addColorStop(.44, '#384c4f');
    tint.addColorStop(1, '#203031');
    ctx.fillStyle = tint;
    ctx.fillRect(0, 0, w, h);
    ctx.fillStyle = '#d0e4df29';
    ctx.beginPath();
    ctx.moveTo(0, 5); ctx.lineTo(78, 0); ctx.lineTo(256, 129); ctx.lineTo(256, 163);
    ctx.closePath(); ctx.fill();
    ctx.fillStyle = '#b2c5c025';
    ctx.fillRect(0, 181, w, 2);
  });
  const emissiveMap = texture(256, 256, (ctx, w, h) => {
    const lamp = ctx.createRadialGradient(w * .52, h * .69, 7, w * .52, h * .69, w * .70);
    lamp.addColorStop(0, '#fff0ba'); lamp.addColorStop(.37, '#e7ad62'); lamp.addColorStop(1, '#653621');
    ctx.fillStyle = lamp; ctx.fillRect(0, 0, w, h);
    ctx.fillStyle = '#4126237a';
    ctx.beginPath();
    ctx.moveTo(0, 0); ctx.lineTo(w * .38, 0); ctx.quadraticCurveTo(w * .18, h * .51, w * .18, h);
    ctx.lineTo(0, h); ctx.fill();
    ctx.beginPath();
    ctx.moveTo(w, 0); ctx.lineTo(w * .78, 0); ctx.quadraticCurveTo(w * .88, h * .44, w * .91, h);
    ctx.lineTo(w, h); ctx.fill();
  });
  return mat('#d9ded8', { map, emissive: '#ffcb83', emissiveMap, emissiveIntensity: 0, roughness: .37 });
}

function stringLights(draw, bulb, left, right, y, z, sag) {
  const points = Array.from({ length: 21 }, (_, i) => {
    const t = i / 20;
    return v(T.MathUtils.lerp(left, right, t), y - Math.sin(t * Math.PI) * sag, z);
  });
  tube(draw, iron, points, .012);
  points.forEach(({ x, y, z }, i) => {
    if (i % 2 === 1) return;
    cylinder(draw, iron, x, y - .035, z, .027, .025, .057, 6);
    draw.add(new T.SphereGeometry(.044, 8, 6).scale(.83, 1.25, .83), bulb, x, y - .08, z, 0, false);
  });
}

export function buildTerrace(draw, glass, bulbs) {
  const fronts = [];
  const roofTiles = roofFinish();
  function sash(x, y, z, w, h, yaw = 0, finish = pale, panes = 2, display = false) {
    const at = (a, b, c) => [x + Math.cos(yaw) * a + Math.sin(yaw) * c, y + b, z - Math.sin(yaw) * a + Math.cos(yaw) * c];
    const part = (m, a, b, c, width, height, depth) => box(draw, m, ...at(a, b, c), width, height, depth, yaw);
    part(stone, 0, 0, -.027, w + .20, h + .18, .13);
    draw.add(new T.PlaneGeometry(w, h), glass, ...at(0, 0, .05), yaw, false);
    for (const a of [-1, 1]) {
      part(finish, a * w / 2, 0, .08, .065, h + .11, .11);
      part(finish, 0, a * h / 2, .08, w + .08, .065, .11);
    }
    part(finish, 0, display ? -.31 : .06, .086, w, .045, .065);
    for (let i = 1; i < panes; i++) part(finish, w * (i / panes - .5), 0, .085, .041, h, .066);
    part(pale, 0, -h / 2 - .072, .09, w + .22, .09, .23);
    if (!display) part(pale, 0, h / 2 + .081, .025, w + .20, .09, .17);
  }

  function bay(x, y, z, finish) {
    box(draw, stone, x, y, z + .27, 1.66, 1.53, .52);
    box(draw, finish, x, y - .81, z + .38, 1.87, .13, .83);
    box(draw, finish, x, y + .81, z + .38, 1.87, .15, .86);
    box(draw, snow, x - .06, y + .901, z + .44, 1.73, .038, .73);
    sash(x, y, z + .548, 1.15, 1.32, 0, finish);
    for (const side of [-1, 1]) {
      sash(x + side * .775, y, z + .33, .48, 1.32, side * .92, finish, 1);
      box(draw, finish, x + side * .605, y, z + .56, .10, 1.55, .12);
    }
  }

  function door(x, front, number) {
    for (const [y, depth, w] of [[.06, .73, 1.36], [.17, .50, 1.24], [.28, .28, 1.12]]) {
      box(draw, stone, x, y, front + depth / 2, w, .12, depth);
    }
    box(draw, pale, x, 1.55, front + .04, 1.21, 2.43, .20);
    box(draw, green, x, 1.36, front + .16, .92, 2.03, .10);
    for (const dx of [-.22, .22]) for (const y of [.68, 1.21, 1.90]) {
      box(draw, iron, x + dx, y, front + .211, .32, y > 1.5 ? .53 : .33, .018);
      box(draw, green, x + dx, y, front + .229, .255, y > 1.5 ? .45 : .26, .024);
    }
    sash(x, 2.53, front + .16, .90, .28, 0, green, 3);
    box(draw, brass, x, 1.18, front + .245, .22, .046, .018);
    draw.add(new T.TorusGeometry(.057, .013, 8, 20), brass, x, 1.39, front + .257);
    draw.add(new T.SphereGeometry(.036, 8, 6), brass, x, 1.456, front + .252);
    greenery(draw, x, 1.95, front + .293, .24, .25, 41);
    for (const side of [-1, 1]) draw.add(new T.SphereGeometry(1, 9, 6).scale(.09, .039, .033),
      ribbon, x + side * .06, 2.18, front + .356, 0, true, 0, side * .33);
    sign(draw, x + .72, 1.98, front + .018, .24, .20, number, { background: '#282d2b' });
  }

  const w = 3.66;
  for (const [i, x] of [-3.66, 0, 3.66].entries()) {
    const front = .28 + i * .055, depth = 3.30;
    const center = front - depth / 2;
    const cornice = 5.98 + [0, .35, .09][i];
    const brick = brickFinish(tones[i], mortars[i]);
    masonry(draw, brick, x, cornice / 2, center, w, cornice, depth);
    fronts.push(new T.Box3(v(x - w / 2, 0, front - depth), v(x + w / 2, cornice, front)));
    box(draw, stone, x, .16, center, w + .04, .31, depth + .07);
    for (const [y, height] of [[2.94, .12], [4.61, .075], [cornice - .16, .09], [cornice, .15]]) {
      box(draw, pale, x, y, center, w + .05, height, depth + .17);
    }
    for (let j = 0; j < 16; j++) {
      box(draw, stone, x - 1.70 + j * .226, cornice - .17, front + .093, .085, .13, .11);
    }
    box(draw, snow, x, cornice + .096, front + .045, w, .042, .19);
    for (const side of [-1, 1]) {
      const pitch = Math.atan2(1.01, depth / 2 + .14);
      const length = Math.hypot(1.01, depth / 2 + .14);
      const z = center + side * (depth / 2 + .14) / 2;
      draw.add(new T.BoxGeometry(w + .055, .18, length), slate, x, cornice + .54, z, 0, true, side * pitch);
      const roofPitch = side * pitch;
      draw.add(new T.PlaneGeometry(w + .043, length - .012), roofTiles,
        x, cornice + .54 + .093 * Math.cos(roofPitch), z + .093 * Math.sin(roofPitch),
        0, false, roofPitch - Math.PI / 2);
    }
    const triangle = new T.Shape([new T.Vector2(-depth / 2, 0), new T.Vector2(0, 1.01), new T.Vector2(depth / 2, 0)]);
    for (const edge of [-1, 1]) {
      draw.add(new T.ExtrudeGeometry(triangle, { depth: .06, bevelEnabled: false }), brick,
        x + edge * w * .49, cornice, center, Math.PI / 2);
    }
    box(draw, slate, x, cornice + 1.08, center, w + .05, .14, .22);
    masonry(draw, brick, x + (i === 2 ? .99 : -.94), cornice + .99, center - .58, .56, 1.51, .69);
    box(draw, pale, x + (i === 2 ? .99 : -.94), cornice + 1.76, center - .58, .65, .12, .78);
    for (const dz of [-.17, .17]) cylinder(draw, mat('#884e3b'), x + (i === 2 ? .99 : -.94), cornice + 1.97, center - .58 + dz, .11, .10, .31);
    for (const dx of [-.84, .84]) sash(x + dx, 5.23, front + .058, .76, .92, 0, pale, 2);

    if (i === 1) {
      sash(x + .36, 1.46, front + .20, 2.40, 1.46, 0, green, 3, true);
      box(draw, green, x + .36, 2.43, front + .18, 2.61, .37, .25);
      sign(draw, x + .36, 2.43, front + .316, 2.52, .31, 'HOLLY & IVY');
      door(x - 1.23, front, '28');
      bay(x + .22, 3.81, front, pale);
      stringLights(draw, bulbs, x - .79, x + 1.64, 2.25, front + .37, .19);
      for (let j = 0; j < 9; j++) {
        const bx = x - .65 + j * .25;
        box(draw, [green, ribbon, pale][j % 3], bx, .89 + (j % 3) * .058, front + .267, .17, .20 + j % 3 * .11, .15);
        box(draw, brass, bx, .89 + (j % 3) * .058, front + .349, .027, .205 + j % 3 * .11, .017);
      }
    } else {
      bay(x - .62, 1.47, front, pale);
      bay(x - .62, 3.83, front, pale);
      door(x + 1.12, front, i === 0 ? '24' : '26');
      sash(x + 1.10, 3.83, front + .055, .68, 1.28, 0, pale, 1);
    }
    stringLights(draw, bulbs, x - 1.65, x + 1.65, 2.98, front + .77, .30);
    cylinder(draw, iron, x - 1.70, 3.04, front + .147, .038, .038, 5.79, 8);
  }

  for (const side of [-1, 1]) for (const z of [-.57, -1.96]) {
    for (const y of [1.53, 3.78, 5.21]) sash(side * 5.511, y, z, .79, y === 5.21 ? .92 : 1.24, side * Math.PI / 2);
  }
  return fronts;
}

export function gift(draw, x, y, z, size, wrap, yaw = 0) {
  box(draw, wrap, x, y + size / 2, z, size, size, size, yaw);
  box(draw, brass, x, y + size * .51, z, size * .19, size * 1.03, size * 1.018, yaw);
  box(draw, brass, x, y + size * .51, z, size * 1.018, size * 1.025, size * .19, yaw);
  for (const side of [-1, 1]) draw.add(new T.TorusGeometry(size * .12, size * .026, 5, 10),
    brass, x + side * size * .11, y + size * 1.09, z, yaw, true, 0, side * .33);
}

export function buildTree(draw, x, z, bulbs) {
  cylinder(draw, mat('#5c463b'), x, .47, z, .12, .19, .89, 11);
  const needles = ['#21473b', '#285749', '#355e49', '#3c6853', '#204033'].map(c => mat(c));
  const tier = new T.ConeGeometry(1, 1, 8, 1);
  const twig = new T.ConeGeometry(1, 1, 5, 1);
  for (let i = 0; i < 360; i++) {
    const t = i / 360;
    const angle = i * 2.39996;
    const radius = (1 - t) ** .77 * (.65 + rng() * .56);
    const base = .69 + t * 3.13;
    const r = .24 * (1 - t) + .056;
    const pitch = -.99 - rng() * .27;
    const gx = x + Math.sin(angle) * radius, gz = z + Math.cos(angle) * radius;
    draw.add(tier.clone().scale(r, .73 * (1 - t * .62), r * .64), needles[i % 5],
      gx, base, gz, angle, true, pitch);
    for (const side of [-1, 1]) {
      const a = angle + side * .25;
      const tip = radius + .28 * (1 - t);
      draw.add(twig.clone().scale(r * .37, .32 * (1 - t * .58), r * .27), needles[(i + side + 5) % 5],
        x + Math.sin(a) * tip, base + .009, z + Math.cos(a) * tip, a, true, pitch + side * .18);
    }
    if (i % 7 === 0) {
      draw.add(new T.SphereGeometry(.046 + rng() * .041, 8, 7), baubles[i % 3],
        x + Math.sin(angle) * (radius + .24), base - .063, z + Math.cos(angle) * (radius + .24));
    }
    if (i % 9 === 0) draw.add(new T.IcosahedronGeometry(.115, 0).scale(1.45, .27, .82), snow,
      gx, base + .109, gz, angle, false, -.31);
  }
  const spiral = [];
  for (let i = 0; i <= 106; i++) {
    const t = i / 106, a = i * .32, r = 1.18 * (1 - t) ** .87 + .08;
    const p = v(x + Math.sin(a) * r, .78 + t * 3.00, z + Math.cos(a) * r);
    spiral.push(p);
    if (i % 2 === 0) draw.add(new T.SphereGeometry(.039, 7, 5), bulbs, p.x, p.y, p.z, 0, false);
  }
  tube(draw, iron, spiral, .010);
  const star = new T.Shape(Array.from({ length: 10 }, (_, i) => {
    const a = Math.PI / 2 + i * Math.PI / 5, r = i % 2 ? .115 : .25;
    return new T.Vector2(Math.cos(a) * r, Math.sin(a) * r);
  }));
  draw.add(new T.ExtrudeGeometry(star, { depth: .04, bevelEnabled: true, bevelSize: .018, bevelThickness: .015, bevelSegments: 1 }),
    brass, x, 4.03, z, .37);
  for (const [dx, dz, s, m] of [[-.70, .58, .32, ribbon], [-.29, .70, .24, green], [.37, .67, .37, ribbon], [.75, .20, .25, pale], [.13, .89, .20, green]]) {
    gift(draw, x + dx, .07, z + dz, s, m, dx * .44);
  }
}


