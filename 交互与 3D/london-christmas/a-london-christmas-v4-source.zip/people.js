import * as T from 'three';
import { batch, box, mat, plane, texture, v } from './model.js';
import { curve } from './regent.js';

export const cast = [
  { id: 'couple', name: 'Iris & Noah', role: 'A winter walk', intro: 'Iris pulls Noah beneath the lights as the last bus rounds the bend.',
    topics: [['Where are you going?', '“Nowhere quite yet,” says Iris. “We always take the long way home when the angels are lit.”'],
      ['What’s in the bag?', '“A little ornament for our first tree,” Noah says. “Iris has guessed what it is, but she’s pretending she hasn’t.”'],
      ['A favourite Christmas memory?', '“Last year it snowed just as the clock struck six. We stood here until our tea went cold.”']] },
  { id: 'photographer', name: 'Maya', role: 'Street photographer', intro: 'Maya lowers her camera and checks the light in the puddles.',
    topics: [['Where should I stand?', '“A little farther along the kerb. The second angel fits between the first one’s wings there.”'],
      ['What are you photographing?', '“The red bus, mostly. I’m waiting for the headlamps to catch the wet stones.”']] },
  { id: 'florist', name: 'Evelyn', role: 'Florist at Holly & Ivy', intro: 'Evelyn brushes snow from her sleeve outside the shop.',
    topics: [['Who made the wreaths?', '“We did. The velvet ribbon is tied with florist’s wire so it holds its shape in the rain.”'],
      ['Any gifts left?', '“There are brass bells in the window. Take one off the hook and give it a shake.”']] },
  { id: 'pub', name: 'Arthur', role: 'Crown & Anchor regular', intro: 'Arthur pauses under the pub sign, his scarf wrapped twice.',
    topics: [['What’s on inside?', '“Mulled cider by the window and a few carols later. You can watch the buses from the corner table.”'],
      ['What was that overhead?', '“A sleigh, if my eyes are any good. Keep watching the gap above the roofs.”']] },
  { id: 'friends', name: 'Leila & Sam', role: 'Christmas shoppers', intro: 'Their paper bags rustle as they stop to admire the tree.',
    topics: [['Finished shopping?', '“Almost,” says Leila. “We came for a book and somehow bought a tiny brass reindeer.”'],
      ['Which way is the bus?', '“Straight along the curve. Look for the red double-decker with the gold lights on its roof.”']] },
  { id: 'baker', name: 'Ada', role: 'Baker at The Lantern', intro: 'Ada tucks a paper parcel under her arm.',
    topics: [['What’s in the parcel?', '“Mince pies for the late shift. The ones with star-shaped lids always go first.”'],
      ['Are you open tomorrow?', '“We’ll have the ovens on early. Follow the smell of orange peel and butter.”']] },
  { id: 'reader', name: 'Daniel', role: 'Winter Books customer', intro: 'Daniel stops at the kerb with a book wrapped in brown paper.',
    topics: [['What did you buy?', '“A book of ghost stories for the train home. We read one aloud every Christmas Eve.”'],
      ['Do you come here often?', '“Every December. I walk the whole curve before I get on the bus.”']] },
  { id: 'runner', name: 'Theo', role: 'On the way home', intro: 'Theo slows down to keep his takeaway cup from spilling.',
    topics: [['In a hurry?', '“A little. The pudding’s in the oven, and I promised I’d be home before the candles were lit.”'],
      ['Where did you get the coffee?', '“The Lantern, on the other side of the road. They put a twist of orange in it at Christmas.”']] },
];

const shoes = mat('#493743', { roughness: .51 });
const eye = new T.MeshBasicMaterial({ color: '#3b3541' });
const lining = mat('#e8d9c1');
const button = mat('#e1b680', { metalness: .35, roughness: .30 });
const contact = texture(64, 64, (ctx, w, h) => {
  const radial = ctx.createRadialGradient(w / 2, h / 2, 1, w / 2, h / 2, w / 2);
  radial.addColorStop(0, '#1b1828a4');
  radial.addColorStop(.42, '#201b3168');
  radial.addColorStop(1, '#22213a00');
  ctx.fillStyle = radial;
  ctx.fillRect(0, 0, w, h);
});

function oval(draw, finish, x, y, z, rx, ry, rz, roll = 0) {
  draw.add(new T.SphereGeometry(1, 13, 9).scale(rx, ry, rz), finish, x, y, z, 0, true, 0, roll);
}

function makeWalker(parent, outfit) {
  const { coat, scarf, skin, hair, hat, bag, height, long } = outfit;
  const jacket = mat(coat);
  const knit = mat(scarf);
  const face = mat(skin);
  const haircut = mat(hair);
  const trousers = mat(outfit.trousers || '#494458');
  const lipstick = mat('#ad615a');
  const paper = mat('#c69868');
  const actor = new T.Group();
  actor.scale.setScalar(height);
  parent.add(actor);
  const body = new T.Group();
  actor.add(body);
  const draw = batch(body);
  const hem = long ? .57 : .76;
  const top = 1.38;
  const contour = [[.052, hem], [.228, hem], [.229, hem + .078], [.205, top - .23],
    [.247, top - .071], [.185, top + .014], [.09, top + .042]];
  const torso = new T.LatheGeometry(contour.map(([r, y]) => new T.Vector2(r, y)), 18).scale(1, 1, .70);
  draw.add(torso, jacket);
  for (const y of [1.02, 1.14, 1.25]) oval(draw, button, .029, y, .153, .021, .019, .010);
  box(draw, jacket, -.128, .897, .111, .10, .052, .024, .05);
  box(draw, jacket, .128, .897, .111, .10, .052, .024, -.05);
  oval(draw, knit, 0, 1.399, .021, .161, .071, .137);
  box(draw, knit, -.108, 1.24, .159, .107, .244, .038);
  box(draw, lining, -.108, 1.151, .18, .109, .017, .006);
  oval(draw, face, 0, 1.57, .02, .122, .148, .115);
  oval(draw, haircut, -.012, 1.629, -.008, .130, .118, .122);
  oval(draw, haircut, -.066, 1.624, .070, .081, .048, .063, -.34);
  oval(draw, face, 0, 1.56, .139, .022, .023, .022);
  for (const x of [-.044, .044]) {
    oval(draw, eye, x, 1.582, .130, .012, .015, .007);
    oval(draw, face, x * 2.7, 1.56, .030, .023, .038, .025);
    oval(draw, lipstick, x * 1.68, 1.538, .108, .018, .009, .005);
  }
  if (hat) {
    oval(draw, knit, 0, 1.68, .007, .142, .096, .131);
    oval(draw, lining, 0, 1.646, .017, .146, .026, .136);
    oval(draw, knit, 0, 1.779, .004, .044, .044, .039);
  } else if (long) oval(draw, haircut, -.041, 1.465, -.059, .083, .135, .073);
  draw.finish();

  const arms = [], legs = [];
  for (const side of [-1, 1]) {
    const arm = new T.Group();
    arm.position.set(side * .202, 1.312, 0);
    body.add(arm);
    const armDraw = batch(arm);
    oval(armDraw, jacket, side * .035, -.18, .01, .082, .235, .077, side * .14);
    oval(armDraw, knit, side * .061, -.370, .042, .061, .072, .056);
    if (bag && side === 1) {
      box(armDraw, paper, .059, -.522, .071, .193, .222, .126);
      box(armDraw, lining, .059, -.513, .138, .160, .038, .009);
      armDraw.add(new T.TorusGeometry(.068, .012, 5, 12), button, .059, -.414, .071);
    }
    armDraw.finish();
    arms.push(arm);

    const leg = new T.Group();
    leg.position.set(side * .102, .759, -.014);
    actor.add(leg);
    const legDraw = batch(leg);
    oval(legDraw, trousers, 0, -.305, 0, .086, .359, .085);
    oval(legDraw, shoes, 0, -.672, .045, .089, .092, .156);
    legDraw.finish();
    legs.push(leg);
  }
  const shadow = plane(parent, new T.MeshBasicMaterial({
    map: contact, transparent: true, depthWrite: false, polygonOffset: true, polygonOffsetFactor: -1,
  }), 0, .139, 0, .91 * height, .72 * height);
  actor.traverse(object => { if (object.isMesh) object.castShadow = false; });
  return { actor, body, arms, legs, shadow };
}

export function buildPeople(parent) {
  const castings = [
    ['couple', '#b14a5f', '#edd7b7', '#e2a582', '#463033', true, true, .91, true, 1.30, 2.9, 8.26, .48],
    ['couple', '#34576e', '#b7735a', '#d8a180', '#332b34', false, false, 1.00, true, 1.30, 2.9, 8.91, .48],
    ['photographer', '#72805a', '#d8a6a2', '#c88c72', '#352d37', true, false, .97, false, -7.97, -7.14, 2.39, 1.22],
    ['florist', '#a66a4b', '#8d4559', '#f0bb97', '#674646', false, false, .92, true, -.51, .55, 1.85, 1.65],
    ['pub', '#534b61', '#e4be83', '#e2b49a', '#c0a69a', true, false, 1.06, true, 8.15, 9.25, 2.07, 1.70],
    ['friends', '#8e4c66', '#eda979', '#ac7563', '#332c3b', false, true, .94, true, -4.6, -2.9, 8.12, 2.18],
    ['friends', '#596c80', '#b97c52', '#b77b5d', '#352d34', true, true, .92, false, -4.95, -3.25, 8.77, 2.18],
    ['runner', '#566e5d', '#d4a55b', '#e2aa8a', '#432e39', true, true, .96, false, -11.8, -9.2, 8.24, 2.8],
    ['baker', '#986e60', '#ece5d0', '#c58870', '#392e37', true, false, .90, false, -9.77, -8.53, 8.75, 1.89],
    ['reader', '#536984', '#9d5b61', '#dea78f', '#3c3441', false, false, .94, true, -14.52, -12.27, 1.77, 3.24],
  ];
  const actors = castings.map(([id, coat, scarf, skin, hair, hat, bag, height, long, min, max, z, phase]) => ({
    ...makeWalker(parent, { coat, scarf, skin, hair, hat, bag, height, long }),
    id, min, max, z, phase, height, bounds: new T.Box3(),
  }));
  const anchor = new T.Vector3();

  function update(time, still) {
    for (const [i, person] of actors.entries()) {
      const { actor, body, arms, legs, min, max, z, phase, height } = person;
      const t = phase + time * .55;
      const x = T.MathUtils.lerp(min, max, .5 + .5 * Math.sin(t));
      const direction = Math.cos(t);
      const speed = Math.min(1, Math.abs(direction) * 2);
      const swing = still ? 0 : Math.sin(time * (4.9 + i * .081) + phase * 4) * speed;
      actor.position.set(x, .103, z + curve(x));
      actor.rotation.y = 1.29 * Math.tanh(direction * 3) + (z > 6 ? -.18 : .23);
      body.position.y = Math.abs(swing) * .028;
      body.rotation.z = .026 * swing;
      for (let side = 0; side < 2; side++) {
        const sign = side * 2 - 1;
        legs[side].rotation.x = .31 * swing * sign;
        arms[side].rotation.x = -.37 * swing * sign;
        arms[side].rotation.z = sign * (.08 + .02 * swing);
      }
      if (person.id === 'couple') {
        const inside = (i === 0 ? -1 : 1) * Math.sin(actor.rotation.y) > 0 ? 1 : 0;
        arms[inside].rotation.x = i === 0 ? -.27 : .27;
        arms[inside].rotation.z = inside === 1 ? .47 : -.47;
      }
      person.shadow.position.x = actor.position.x;
      person.shadow.position.z = actor.position.z;
      anchor.copy(actor.position);
      person.bounds.min.set(anchor.x - .34, anchor.y, anchor.z - .32);
      person.bounds.max.set(anchor.x + .34, anchor.y + 1.82 * height, anchor.z + .32);
    }
  }

  return { actors, update };
}




