import { build } from 'esbuild';
import { mkdir, readFile, writeFile } from 'node:fs/promises';
import { fileURLToPath } from 'node:url';

const path = file => new URL(file, import.meta.url);
const read = file => readFile(path(file), 'utf8');
const dataUrl = async (file, type) => 'data:' + type + ';base64,' + (await readFile(path(file))).toString('base64');
const [template, css, postcard, branches, sky, rug, music, threeLicense, frauncesLicense, manropeLicense] = await Promise.all([
  read('index.template.html'), read('style.css'),
  dataUrl('assets/westminster-blue-hour.png', 'image/png'), dataUrl('assets/holly.svg', 'image/svg+xml'),
  dataUrl('assets/atlas-sky.webp', 'image/webp'),
  dataUrl('assets/sitting-room-rug.webp', 'image/webp'),
  dataUrl('assets/london-christmas-original.mp3', 'audio/mpeg'),
  read('node_modules/three/LICENSE'),
  read('node_modules/@fontsource-variable/fraunces/LICENSE'),
  read('node_modules/@fontsource-variable/manrope/LICENSE'),
]);
const fonts = [
  ['Fraunces', 'normal', 'fraunces/files/fraunces-latin-opsz-normal.woff2'],
  ['Fraunces', 'italic', 'fraunces/files/fraunces-latin-opsz-italic.woff2'],
  ['Manrope', 'normal', 'manrope/files/manrope-latin-wght-normal.woff2'],
];
const faces = await Promise.all(fonts.map(async ([family, style, file]) => {
  const src = await dataUrl('node_modules/@fontsource-variable/' + file, 'font/woff2');
  return '@font-face{font-family:' + family + ';font-style:' + style + ';font-weight:100 900;src:url(' + src +
    ') format("woff2");font-display:swap;}';
}));
const result = await build({
  entryPoints: [fileURLToPath(path('scene.js'))],
  absWorkingDir: import.meta.dirname,
  bundle: true, minify: true, write: false, format: 'iife', target: 'es2022', legalComments: 'inline',
});
const script = result.outputFiles[0].text.replace(/<\/script/gi, '<\\/script');
const licenses = [threeLicense, frauncesLicense, manropeLicense,
  'GSAP 3.14.2 is distributed under the GSAP Standard License at https://gsap.com/standard-license/.']
  .join('\n\n').replaceAll('-->', '--&gt;');
const html = template
  .replace('/* INLINE_STYLE */', () => css.replace('/* INLINE_FONTS */', faces.join('\n')).replace('/* INLINE_SKY */', () => sky))
  .replace('/* INLINE_SKY */', () => sky)
  .replace('/* INLINE_RUG */', () => rug)
  .replace('/* INLINE_POSTCARD */', () => postcard)
  .replaceAll('/* INLINE_BRANCHES */', () => branches)
  .replace('/* INLINE_MUSIC */', () => music)
  .replace('/* INLINE_SCRIPT */', () => script) + '\n<!-- Third-party licenses\n' + licenses + '\n-->\n';
await mkdir(path('dist/'), { recursive: true });
await writeFile(path('dist/a-london-christmas-atlas.html'), html);
