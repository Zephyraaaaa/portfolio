import * as T from 'three';
import { atlasVisitors } from './atlas-people.js';
import { batch, box, cylinder, random, slab, tube, v } from './model.js';
import { pbr, metals, snow, spruce, glints, mapBox, parcel, strand, star, velvetBow, wreath } from './atlas-finish.js';
import { atlasWindows, arch, bell, column, facade, lamp, marketStall, pad, palette, plinthLabel, road, sash, sign, starStrand } from './atlas-kit.js';

export const stops = [
  ['trafalgar', 'Trafalgar Square', '特拉法加广场', 'The Norwegian spruce stands between the gallery, the fountains and Nelson’s Column.'],
  ['waterloo', 'Waterloo Place', '滑铁卢广场', 'Stone terraces and lit garlands lead toward the Duke of York Steps.'],
  ['regent', 'Regent Street St James’s', '摄政街圣詹姆斯段', 'The golden angels gather over a bend in the road.'],
  ['fortnum', 'Fortnum & Mason', '福南梅森百货', 'Twenty-four illuminated windows turn the Piccadilly frontage into an Advent calendar.'],
  ['bond', 'New Bond Street', '新邦德街', 'A crown of lights hangs between jewellers and ribbon-wrapped shopfronts.'],
  ['annabel', 'Annabel’s, Berkeley Square', '伯克利广场安娜贝尔俱乐部', 'A gilded door, winter firs and a sculpted lion dress the Berkeley Square townhouse.'],
  ['selfridges', 'Selfridges', '塞尔福里奇百货', 'Portland stone columns rise above a row of miniature festive window displays.'],
  ['oxford', 'Oxford Street', '牛津街', 'A canopy of stars follows the broad shopping street.'],
  ['liberty', 'Liberty', '利伯提百货', 'Leaded windows and dark Tudor timbers frame the Christmas shop.'],
  ['carnaby', 'Carnaby Street', '卡纳比街', 'The Carnaby Universe theme sends luminous planets over the narrow street.'],
  ['leicester', 'Leicester Square', '莱斯特广场', 'Timber stalls, a striped Spiegeltent and a lit spruce fill the square.'],
  ['dials', 'Seven Dials', '七面钟街区', 'Seven little streets meet beneath the Sundial Pillar and a fan of lights.'],
  ['covent', 'Covent Garden', '考文特花园', 'A towering tree stands beside the covered Apple Market and its hanging gold bells.'],
].map(([id, name, zh, note]) => ({ id, name, zh, note }));

const brass = metals.gold;
const iron = metals.iron;
const cream = palette.moulding;
const greenery = pbr('#294836');
const burgundy = pbr('#8c2033');
const calendarRed = pbr('#a4293d', { roughness: .39 });
const calendarGlow = pbr('#e25542', { emissive: '#c83328', emissiveIntensity: .55, roughness: .35 });
const giftGlass = new T.MeshPhysicalMaterial({ color: '#c4d8e7', transparent: true, opacity: .27,
  metalness: .30, roughness: .23, clearcoat: .8, side: T.DoubleSide, depthWrite: false });
const whiteFluff = pbr('#e5e9e1', { roughness: .9 });
const velvet = pbr('#8c1831', { roughness: .83 });
const copper = pbr('#54716b', { roughness: .58, metalness: .26 });
const fuchsia = pbr('#eb6b8f', { emissive: '#d24776', emissiveIntensity: .75 });
const blueNeon = pbr('#68ddea', { emissive: '#48a9dc', emissiveIntensity: .72 });
const lilac = pbr('#b68afb', { emissive: '#8c6cf4', emissiveIntensity: .68 });
const iris = pbr('#6968ab', { roughness: .52, metalness: .14 });
const copperRoof = pbr('#516c67', { metalness: .22, roughness: .68 });

const half = 6.84;
const roofSnow = pbr('#e8eef4', { roughness: .9 });
const fillColor = '#ffcb92';
const stars = ['#ffdb97', '#c3e1ff', '#f8aa99'];
const ellipsoid = (draw, mat, x, y, z, a, b, c, yaw = 0, roll = 0) =>
  draw.add(new T.SphereGeometry(1, 16, 12).scale(a, b, c), mat, x, y, z, yaw, true, 0, roll);
const centered = (count, gap) => Array.from({ length: count }, (_, i) => (i - (count - 1) / 2) * gap);

function statue(draw, material, x, y, z, h, yaw = 0) {
  const place = (a, b, c) => [x + Math.cos(yaw) * a + Math.sin(yaw) * c, y + b, z - Math.sin(yaw) * a + Math.cos(yaw) * c];
  for (const side of [-1, 1]) {
    ellipsoid(draw, material, ...place(side * h * .082, h * .24, 0), h * .072, h * .25, h * .068, yaw);
    ellipsoid(draw, material, ...place(side * h * .081, h * .045, h * .043), h * .083, h * .045, h * .11, yaw);
    ellipsoid(draw, material, ...place(side * h * .171, h * .565, .014 * side), h * .064, h * .221, h * .076, yaw, side * .16);
  }
  ellipsoid(draw, material, ...place(0, h * .57, 0), h * .176, h * .24, h * .093, yaw);
  ellipsoid(draw, material, ...place(0, h * .853, .01 * h), h * .094, h * .122, h * .082, yaw);
  ellipsoid(draw, material, ...place(0, h * .924, 0), h * .116, h * .061, h * .097, yaw);
}

function lion(draw, x, y, z, size, yaw, mat = metals.bronze) {
  const put = (a, b, c) => [x + (a * Math.cos(yaw) + c * Math.sin(yaw)) * size, y + b * size,
    z + (c * Math.cos(yaw) - a * Math.sin(yaw)) * size];
  ellipsoid(draw, mat, ...put(0, .28, 0), .28 * size, .25 * size, .58 * size, yaw);
  ellipsoid(draw, mat, ...put(0, .52, .34), .29 * size, .33 * size, .23 * size, yaw);
  ellipsoid(draw, mat, ...put(0, .64, .52), .19 * size, .19 * size, .19 * size, yaw);
  ellipsoid(draw, mat, ...put(0, .57, .677), .143 * size, .090 * size, .10 * size, yaw);
  for (const s of [-1, 1]) {
    ellipsoid(draw, mat, ...put(s * .19, .11, .43), .105 * size, .099 * size, .29 * size, yaw);
    ellipsoid(draw, mat, ...put(s * .151, .75, .478), .058 * size, .070 * size, .041 * size, yaw);
  }
}

function monument(draw, x, z, height, type) {
  const r = type === 'dials' ? .18 : .224;
  const base = type === 'trafalgar' ? 1.50 : type === 'dials' ? .75 : 1.03;
  for (let i = 0; i < 4; i++) box(draw, i % 2 ? cream : palette.stone, x, .12 + i * .11, z,
    base * (1.20 - i * .107), .12, base * (1.20 - i * .107));
  if (type === 'trafalgar') {
    mapBox(draw, palette.stone, x, .725, z, 1.05, .59, 1.05, 1.2);
    for (const yaw of [0, Math.PI / 2, Math.PI, Math.PI * 1.5]) {
      const px = x + Math.sin(yaw) * .53, pz = z + Math.cos(yaw) * .53;
      box(draw, metals.bronze, px, .745, pz, .73, .295, .028, yaw);
    }
    for (const dx of [-1, 1]) for (const dz of [-1, 1]) {
      const xx = x + dx * .91, zz = z + dz * .90;
      box(draw, cream, xx, .124, zz, .65, .14, .92, dz < 0 ? Math.PI : 0);
      lion(draw, xx, .193, zz, .65, dz < 0 ? Math.PI : 0);
    }
  }
  const lower = type === 'trafalgar' ? 1.03 : .51;
  column(draw, x, lower, z, height - lower, r, cream);
  if (type === 'dials') {
    cylinder(draw, cream, x, height + .19, z, .275, .28, .385, 6);
    for (let i = 0; i < 6; i++) {
      const yaw = i * Math.PI / 3;
      const dx = Math.sin(yaw) * .253, dz = Math.cos(yaw) * .253;
      draw.add(new T.CircleGeometry(.102, 18), brass, x + dx, height + .20, z + dz, yaw, false);
      box(draw, iron, x + dx + Math.sin(yaw) * .021, height + .204, z + dz + Math.cos(yaw) * .021, .017, .15, .021, yaw);
    }
    ellipsoid(draw, brass, x, height + .414, z, .081, .081, .081);
  } else {
    box(draw, cream, x, height + .075, z, .61, .133, .61);
    statue(draw, type === 'waterloo' ? metals.bronze : cream, x, height + .14, z, .66);
  }
}
function fountain(draw, dots, x, z, radius) {
  cylinder(draw, cream, x, .136, z, radius, radius * .98, .18, 24);
  cylinder(draw, palette.water, x, .233, z, radius * .90, radius * .90, .045, 32);
  draw.add(new T.TorusGeometry(radius * .928, .065, 8, 48), cream, x, .282, z, 0, true, -Math.PI / 2);
  cylinder(draw, cream, x, .508, z, .135, .235, .51, 18);
  cylinder(draw, cream, x, .78, z, .42, .29, .135, 18);
  cylinder(draw, palette.water, x, .855, z, .384, .384, .029, 18);
  const water = pbr('#afdae9', { metalness: .14, roughness: .24, transparent: true, opacity: .72 });
  water.userData.atlasOwned = true;
  for (let i = 0; i < 8; i++) {
    const a = i * Math.PI / 4;
    tube(draw, water, [v(x, .91, z), v(x + Math.cos(a) * radius * .24, 1.23, z + Math.sin(a) * radius * .24),
      v(x + Math.cos(a) * radius * .53, .91, z + Math.sin(a) * radius * .53),
      v(x + Math.cos(a) * radius * .66, .26, z + Math.sin(a) * radius * .66)], .016, true, 5);
  }
  dots.push({ point: v(x, .30, z + .65), color: '#b8defa', radius: .33 });
}

function sideBuildings(context, { left = palette.brick, right = palette.stone, gap = 4.0, height = 5.45, depth = 1.72, labels = [], columns = false } = {}) {
  const { group, dots } = context;
  for (const side of [-1, 1]) for (const [index, z] of [-3.34, .15, 3.60].entries()) {
    facade(group, dots, { x: side * gap, z, yaw: -side * Math.PI / 2, w: 3.39, d: depth,
      h: height + (index === 1 ? .45 : index === 2 ? -.35 : .0), bays: 3,
      colour: side < 0 ? left : right, columns: columns && index === 1,
      label: labels[(side === 1 ? 3 : 0) + index], ground: [palette.teal, palette.oxblood, palette.navy][(index + (side === 1 ? 1 : 0)) % 3] });
  }
}

function angel(draw, dots, z, height, width) {
  const scale = width / 3.28;
  for (const side of [-1, 1]) {
    for (let row = 0; row < 9; row++) {
      const t = row / 8, x = side * width * (1 - t * .59);
      const end = height + 1.13 * scale - 1.08 * t * scale;
      strand(draw, dots, [v(side * .11, height + .21, z), v(x * .31, height + .34 - t * .19, z + .12),
        v(x * .68, end - .14, z + .15), v(x, end, z)], { spacing: .084, radius: .14, thickness: .005 });
    }
    for (let j = 0; j < 4; j++) {
      const offset = j * .104, endX = side * width * 1.24;
      strand(draw, dots, [v(side * .21, height - .31, z + .11 + offset),
        v(endX * .48, height - .91 - offset, z + .23 + offset), v(endX, height + .11, z + .12 + offset)],
      { color: j === 0 ? '#ffe2ad' : '#c6e8ff', spacing: .15, radius: .13, thickness: .004 });
    }
  }
  for (let i = 0; i < 8; i++) {
    const a = i * Math.PI / 4, r = .11;
    strand(draw, dots, [v(Math.cos(a) * r, height + .19, z + Math.sin(a) * r),
      v(Math.cos(a) * r * .81, height - .19, z + Math.sin(a) * r),
      v(Math.cos(a) * r * 2.22, height - .86, z + Math.sin(a) * r * 2)], { spacing: .10, radius: .12, thickness: .004 });
  }
  for (let i = 0; i < 17; i++) {
    const a = i * Math.PI * 2 / 17;
    dots.push({ point: v(Math.cos(a) * .108, height + .46 + Math.sin(a) * .148, z), color: '#ffdc91', radius: .117 });
  }
}

function tinyBus(draw, dots, x, z, yaw = 0) {
  const red = new T.MeshPhysicalMaterial({ color: '#b31e38', metalness: .26, roughness: .25, clearcoat: .93 });
  const wheels = pbr('#2d2932', { roughness: .87 });
  red.userData.atlasOwned = wheels.userData.atlasOwned = true;
  const cos = Math.cos(yaw), sin = Math.sin(yaw);
  const P = (u, y, q) => [x + cos * u + sin * q, y, z - sin * u + cos * q];
  const part = (mat, u, y, q, w, h, d) => box(draw, mat, ...P(u, y, q), w, h, d, yaw);
  part(red, 0, .79, 0, 2.7, 1.17, .96);
  part(red, 0, 1.654, 0, 2.7, .58, .96);
  part(red, 0, 1.978, 0, 2.73, .105, .992);
  for (const side of [-1, 1]) {
    for (const y of [.90, 1.671]) for (const dx of centered(6, .411)) {
      part(palette.navy, dx, y, side * .493, .369, .377, .032);
      draw.add(new T.PlaneGeometry(.326, .331), atlasWindows[1], ...P(dx, y, side * .515), yaw + (side < 0 ? Math.PI : 0), false);
    }
    for (const dx of [-.87, .86]) {
      draw.add(new T.CylinderGeometry(.269, .269, .113, 20), wheels, ...P(dx, .29, side * .482), yaw, true, Math.PI / 2);
      draw.add(new T.CylinderGeometry(.123, .123, .044, 16), brass, ...P(dx, .29, side * .544), yaw, true, Math.PI / 2);
    }
    part(brass, 0, 1.253, side * .50, 2.64, .029, .025);
    for (let i = 0; i < 20; i++) dots.push({ point: v(...P(-1.22 + i * .128, 1.912, side * .51)), color: '#ffd399', radius: .111 });
  }
  for (const y of [.91, 1.665]) for (const dz of [-.223, .223]) {
    draw.add(new T.PlaneGeometry(.390, .353), atlasWindows[0], ...P(1.365, y, dz), yaw + Math.PI / 2, false);
  }
  sign(draw, ...P(1.377, 1.266, 0), .76, .17, '94  REGENT ST.', { background: '#272631', yaw: yaw + Math.PI / 2 });
  part(iron, 1.369, .526, 0, .035, .18, .43);
  for (const dz of [-.341, .341]) {
    ellipsoid(draw, palette.lantern, ...P(1.383, .567, dz), .035, .059, .058, yaw);
    dots.push({ point: v(...P(1.44, .567, dz)), color: '#ffddaa', radius: .42 });
  }
}
function gallery(context) {
  const { draw, group, dots } = context;
  facade(group, dots, { x: 0, z: -3.53, w: 11.12, d: 2.79, h: 3.88, bays: 9, roof: 'flat', shop: false, colour: palette.pale });
  for (let i = 0; i < 4; i++) box(draw, cream, 0, .112 + i * .127, -2.92 - i * .147, 7.33 - i * .12, .135, 1.13 - i * .12);
  for (const x of centered(8, .662)) column(draw, x, .566, -2.96, 2.29, .132, cream);
  box(draw, cream, 0, 2.947, -3.08, 5.71, .22, .711);
  const pediment = new T.Shape().moveTo(-2.94, 0).lineTo(0, .87).lineTo(2.94, 0).closePath();
  draw.add(new T.ExtrudeGeometry(pediment, { depth: .75, bevelEnabled: true, bevelSegments: 1,
    bevelThickness: .041, bevelSize: .034 }), palette.pale, 0, 3.072, -3.73);
  tube(draw, cream, [v(-2.94, 3.08, -2.952), v(0, 3.95, -2.952), v(2.94, 3.08, -2.952)], .065);
  cylinder(draw, cream, 0, 4.38, -4.78, 1.16, 1.18, .91, 28);
  draw.add(new T.SphereGeometry(1.13, 30, 16, 0, Math.PI * 2, 0, Math.PI / 2).scale(1, .87, 1),
    copperRoof, 0, 4.84, -4.78);
  cylinder(draw, cream, 0, 5.89, -4.78, .13, .173, .33, 12);
  monument(draw, 1.45, .87, 6.68, 'trafalgar');
  fountain(draw, dots, -3.65, 2.51, 1.37);
  fountain(draw, dots, 4.02, 2.62, 1.22);
  spruce(draw, dots, -3.34, .057, -.57, 5.93, { vertical: true, gifts: false, radius: 1.24 });
  for (const x of [-5.36, 5.21]) lamp(draw, dots, x, 4.46);
}

function waterloo(context) {
  const { draw, dots } = context;
  road(draw, 0, .48, 5.52, 11.77);
  sideBuildings(context, { left: palette.pale, right: palette.stone, gap: 3.98, height: 5.46, columns: true,
    labels: ['PALL MALL', '', 'ST JAMES’S', '', 'WATERLOO PLACE', ''] });
  for (let i = 0; i < 6; i++) box(draw, cream, 0, .099 + i * .131, -4.18 - i * .193, 4.59, .133, 1.82 - i * .15);
  monument(draw, 0, -5.12, 6.74, 'waterloo');
  for (const z of [-2.9, .50, 3.85]) for (const x of [-3.02, 3.02]) lamp(draw, dots, x, z, 3.02);
  for (const [i, z] of [-2.9, .50, 3.85].entries()) {
    for (let j = 0; j < 3; j++) strand(draw, dots, [v(-3.68, 4.79, z + j * .16), v(0, 3.98 - j * .13, z + j * .16),
      v(3.68, 4.79, z + j * .16)], { color: stars[(i + j) % 3], radius: .151, spacing: .16 });
    star(draw, brass, 0, 4.14, z + .22, .38);
  }
  spruce(draw, dots, -2.6, .058, -4.64, 2.65, { seed: 6200, gifts: false });
}
function regent(context) {
  const { draw, dots, group } = context;
  road(draw, 0, 0, 5.26, 13.63);
  sideBuildings(context, { left: palette.pale, right: palette.stone, gap: 3.78, height: 5.99, columns: true,
    labels: ['', 'REGENT HOUSE', '', '', 'ST JAMES’S', ''] });
  facade(group, dots, { x: .27, z: -5.47, w: 3.55, d: 1.24, h: 5.13, bays: 3, colour: palette.stone });
  angel(draw, dots, 3.14, 5.38, 2.92);
  angel(draw, dots, -.57, 5.08, 2.73);
  angel(draw, dots, -3.55, 4.87, 2.55);
  tinyBus(draw, dots, 1.21, 3.42, -Math.PI / 2);
  tinyBus(draw, dots, -1.08, -.37, Math.PI / 2);
  lamp(draw, dots, -3.01, 3.18);
  lamp(draw, dots, 2.99, -.20);
}

function fortnum(context) {
  const { draw, dots, group, interactive } = context;
  road(draw, 0, 4.78, 4.14, 13.60, Math.PI / 2);
  facade(group, dots, { x: 0, z: -1.63, w: 10.37, d: 4.36, h: 7.11, bays: 6, brick: true, ground: palette.teal, label: 'FORTNUM & MASON' });
  for (const x of centered(6, 1.45)) {
    box(draw, palette.teal, x, 2.089, -.978, 1.35, .068, .69);
    box(draw, palette.aqua, x, 2.02, -.599, 1.37, .112, .067);
    for (let i = 0; i < 8; i++) box(draw, palette.white, x + (i - 3.5) * .164, 2.129, -.962, .052, .019, .60);
  }
  for (let i = 0; i < 24; i++) {
    const col = i % 6, row = Math.floor(i / 6), x = (col - 2.5) * 1.73, y = 2.77 + row * 1.03;
    box(draw, burgundy, x, y, -1.346, 1.06, .89, .075);
    box(draw, calendarGlow, x, y, -1.284, .84, .73, .060);
    sign(draw, x, y, -1.247, .799, .678, String(i + 1).padStart(2, '0'),
      { background: '#9d2937', colour: '#ffe5b2' });
    for (const sx of [-1, 1]) {
      box(draw, brass, x + sx * .437, y, -1.239, .022, .746, .019, 0, false);
      box(draw, brass, x, y + sx * .371, -1.239, .89, .020, .019, 0, false);
    }
    dots.push({ point: v(x, y + .344, -1.181), color: '#ffbc81', radius: .24 });
    interactive.push({ id: 'advent', day: i + 1, box: new T.Box3(v(x - .45, y - .37, -1.33), v(x + .45, y + .38, -1.21)) });
  }
  box(draw, palette.teal, 0, 2.157, -.532, 4.94, .269, .077);
  sign(draw, 0, 2.157, -.487, 4.76, .222, 'FORTNUM & MASON', { background: '#214c44' });
  draw.add(new T.CylinderGeometry(.270, .270, .075, 22), brass, 0, 6.709, -1.390, 0, true, Math.PI / 2);
  draw.add(new T.CircleGeometry(.222, 22), cream, 0, 6.709, -1.334, 0, false);
  tube(draw, iron, [v(0, 6.709, -1.322), v(.082, 6.792, -1.322)], .017, false);
  tube(draw, iron, [v(0, 6.709, -1.322), v(-.031, 6.836, -1.322)], .011, false);
  for (const x of [-4.98, 5.02]) lamp(draw, dots, x, 2.65);
  for (const x of [-3.8, 3.8]) spruce(draw, dots, x, .057, .68, 2.36, { radius: .57, seed: 897 + x * 11 });
}

function bond(context) {
  const { draw, dots, group } = context;
  road(draw, 0, 1.64, 5.03, 13.64, Math.PI / 2);
  for (const [i, x] of [-4.18, -.08, 4.05].entries()) facade(group, dots, { x, z: -.92,
    w: i === 1 ? 3.96 : 4.04, d: 3.87, h: i === 1 ? 6.83 : 5.91, bays: 3, columns: i !== 0,
    colour: i === 0 ? palette.pale : palette.stone, label: ['CARTIER', 'NEW BOND ST.', 'BOODLES'][i] });
  box(draw, velvet, -4.15, 3.33, -.625, .47, 6.64, .071);
  box(draw, velvet, -4.15, 4.81, -.604, 4.05, .38, .064);
  velvetBow(draw, -4.15, 4.81, -.39, 1.26);
  const center = 1.58, y = 4.39;
  const crown = [[-1.42, .05], [-1.71, 1.13], [-.83, .59], [-.57, 1.55], [0, .89], [.58, 1.55],
    [.82, .59], [1.72, 1.13], [1.41, .05]];
  strand(draw, dots, crown.map(([x, yy]) => v(x + center, y + yy, 1.76)), { spacing: .088, radius: .18, thickness: .037 });
  strand(draw, dots, [v(center - 1.42, y + .052, 1.76), v(center, y - .093, 1.81),
    v(center + 1.41, y + .052, 1.76)], { spacing: .095, radius: .15, thickness: .034 });
  for (const x of [-5.57, 5.55]) lamp(draw, dots, x, 3.38);
  spruce(draw, dots, 4.47, .059, .58, 3.19, { radius: .77, gifts: true });
}

function annabel(context) {
  const { draw, dots, group } = context;
  road(draw, 0, 4.92, 3.50, 13.65, Math.PI / 2, false);
  facade(group, dots, { x: .05, z: -1.76, w: 6.29, d: 4.40, h: 6.44, bays: 5,
    brick: true, ground: palette.teal, label: 'ANNABEL’S' });
  for (const [i, x] of [-4.77, 4.82].entries()) facade(group, dots, { x, z: -2.00, w: 3.18, d: 3.85, h: 5.63 + i * .28, bays: 3, brick: i === 0 });
  const doors = arch(2.41, 3.46);
  draw.add(new T.ExtrudeGeometry(doors, { depth: .16, bevelEnabled: true, bevelThickness: .041, bevelSize: .038,
    bevelSegments: 2 }), palette.white, 0, .24, -1.52);
  for (const [i, x] of [-1.31, 1.31].entries()) {
    column(draw, x, .24, -1.24, 3.10, .154, brass);
    box(draw, brass, x, 3.45, -1.20, .30, .092, .20);
    for (const h of [.79, 1.44, 2.08, 2.64]) box(draw, brass, x * .49, h, -1.30, 1.00, .042, .048);
    for (const zz of [.30, 1.42]) spruce(draw, dots, x * 1.8 + (i ? .22 : -.22), .065, zz, 2.12 + (zz < 1 ? .72 : 0),
      { gifts: false, seed: 557 + i * 101 + zz * 44, radius: .65 });
  }
  for (let i = 0; i < 29; i++) {
    const a = i * Math.PI / 28;
    dots.push({ point: v(Math.cos(a) * 1.23, 2.48 + Math.sin(a) * 1.23, -1.16), color: '#fff1d1', radius: .23 });
  }
  box(draw, cream, .15, .27, 1.31, 1.64, .38, 1.42);
  lion(draw, .15, .474, 1.36, 1.14, -.28, brass);
  wreath(draw, dots, 0, 4.58, -1.32, .67);
  for (const x of [-5.77, 5.70]) lamp(draw, dots, x, 2.87);
}

function selfridges(context) {
  const { draw, dots, group } = context;
  road(draw, 0, 4.59, 4.54, 13.66, Math.PI / 2);
  facade(group, dots, { x: 0, z: -1.42, w: 11.39, d: 4.89, h: 6.75, bays: 7, columns: true,
    roof: 'flat', colour: palette.pale, label: 'SELFRIDGES' });
  for (const [i, x] of centered(7, 1.59).entries()) {
    box(draw, palette.navy, x, 1.139, -.871, 1.31, 1.62, .094);
    box(draw, i % 2 ? palette.plum : palette.aqua, x, 1.13, -.800, 1.09, 1.34, .031);
    for (const dx of [-.607, .607]) box(draw, brass, x + dx, 1.133, -.754, .031, 1.476, .043);
    for (const yy of [.401, 1.863]) box(draw, brass, x, yy, -.754, 1.245, .035, .041);
    for (let j = 0; j < 3; j++) parcel(draw, x + (j - 1) * .291, .448, -.707, .258 + j * .048, i + j, j * .18);
    if (i % 2) star(draw, brass, x + .18, 1.36, -.707, .217, .08);
    else {
      cylinder(draw, palette.forest, x, 1.08, -.703, .026, .26, .61, 11);
      star(draw, brass, x, 1.414, -.685, .106);
    }
    dots.push({ point: v(x, 1.49, -.654), color: i % 2 ? '#ffb3b7' : '#ffda9f', radius: .43 });
  }
  for (const x of [-5.58, 5.58]) lamp(draw, dots, x, 2.55);
  tinyBus(draw, dots, 1.98, 4.68, Math.PI);
}

function oxford(context) {
  const { draw, dots } = context;
  road(draw, 0, 0, 6.09, 13.64);
  sideBuildings(context, { left: palette.stone, right: palette.redBrick, gap: 4.31, height: 5.53, labels: ['MARBLE ARCH', 'WINTER WINDOWS', '', '', 'OXFORD ST.', ''] });
  for (let i = 0; i < 9; i++) starStrand(draw, dots, -4.18, 4.18, -5.02 + i * 1.33, 5.04 + .12 * (i % 2), 15, i % 4 === 0 ? '#d8e7ff' : '#fff0c3');
  tinyBus(draw, dots, -1.41, 1.24, Math.PI / 2);
  for (const [x, z] of [[3.22, 4.35], [-3.23, -1.53], [3.18, -4.31]]) lamp(draw, dots, x, z, 2.72);
}

function liberty(context) {
  const { group, draw, dots } = context;
  road(draw, 0, 4.64, 4.36, 13.63, Math.PI / 2);
  facade(group, dots, { x: 0, z: -.82, w: 10.51, d: 4.19, h: 5.41, bays: 7, timber: true,
    roof: 'flat', colour: palette.white, ground: palette.walnut, label: 'LIBERTY' });
  for (let i = 0; i < 19; i++) {
    const x = -5.19 + i * .576;
    box(draw, palette.walnut, x, 3.86, -.728, .106, 2.85, .16);
    if (i % 2 === 0) tube(draw, palette.walnut, [v(x, 2.51, -.629), v(x + .553, 3.60, -.629)], .053, false, 7);
  }
  for (const y of [2.38, 3.44, 4.76, 5.26]) box(draw, palette.walnut, 0, y, -.708, 10.47, .15, .181);
  for (const [i, x] of centered(3, 3.05).entries()) {
    const w = 2.79 + (i === 1 ? .34 : 0), rise = 1.35 + (i === 1 ? .46 : 0);
    const gable = new T.Shape().moveTo(-w / 2, 0).lineTo(w / 2, 0).lineTo(0, rise).closePath();
    draw.add(new T.ExtrudeGeometry(gable, { depth: 3.11, bevelEnabled: false }), palette.white, x, 5.41, -4.03);
    for (const side of [-1, 1]) {
      const pitch = side * Math.atan2(rise, w / 2);
      draw.add(new T.BoxGeometry(Math.hypot(rise, w / 2) + .18, .13, 3.24),
        palette.roof, x + side * w / 4, 5.41 + rise * .51, -2.47, 0, true, 0, -pitch);
      tube(draw, palette.walnut, [v(x + side * w / 2, 5.414, -.818), v(x, 5.41 + rise, -.818)], .066, false, 8);
    }
    sash(draw, x, 5.85, -.78, .49, .55, { timber: true });
    box(draw, palette.walnut, x, 5.45 + rise * .52, -.716, .090, rise * .9, .145);
    wreath(draw, dots, x, 4.86, -.56, .291);
  }
  for (const x of [-4.75, 4.75]) spruce(draw, dots, x, .060, .85, 2.44, { seed: 6003 + x * 63 });
  lamp(draw, dots, -5.81, 2.5);
  lamp(draw, dots, 5.79, 2.5);
}

function carnaby(context) {
  const { draw, dots } = context;
  road(draw, 0, 0, 5.14, 13.68, 0, false);
  sideBuildings(context, { gap: 3.70, left: palette.redBrick, right: palette.stone, height: 4.61,
    labels: ['CARNABY', 'VINYL', 'WINTER CAFÉ', 'SOHO', 'THE ARCADE', ''] });
  const colours = [fuchsia, blueNeon, lilac];
  for (let row = 0; row < 5; row++) {
    const z = -4.85 + row * 2.36;
    for (let i = 0; i < 3; i++) {
      const t = i / 2, x = (t - .5) * 6.85;
      const y = 4.75 - .36 * Math.sin(t * Math.PI) + .11 * row;
      const r = .245 + .11 * ((row + i) % 3);
      ellipsoid(draw, colours[(i + row) % 3], x, y, z, r, r, r);
      draw.add(new T.TorusGeometry(r * 1.52, .022, 6, 36), colours[(i + row + 1) % 3], x, y, z, .38, true, .42, .16);
      dots.push({ point: v(x, y, z + .076), color: ['#ff8cbb', '#91edff', '#baa1ff'][(i + row) % 3], radius: r * 1.82 });
    }
    for (let i = 0; i < 4; i++) {
      const x = (i - 1.5) * 2.32;
      const y = 4.37 + .29 * Math.sin(i * 1.7 + row * .8);
      star(draw, colours[(i + row) % 3], x, y, z + .34, .205, .10);
    }
  }
  tube(draw, lilac, [v(-3.47, .11, 5.62), v(-3.47, 3.68, 5.62), v(-2.21, 5.35, 5.62), v(0, 5.69, 5.62),
    v(2.21, 5.35, 5.62), v(3.47, 3.68, 5.62), v(3.47, .11, 5.62)], .042);
  box(draw, palette.navy, 0, 5.52, 5.689, 3.08, .46, .10);
  sign(draw, 0, 5.53, 5.75, 2.95, .385, 'CARNABY', { background: '#383152', colour: '#ffe1af' });
}

function leicester(context) {
  const { draw, dots, group } = context;
  facade(group, dots, { x: -.21, z: -4.48, w: 10.81, d: 2.28, h: 4.76, bays: 8, colour: palette.redBrick, label: 'LEICESTER SQUARE' });
  const x = 2.56, z = -.58, r = 2.61;
  cylinder(draw, palette.oak, x, .134, z, r, r, .148, 32);
  for (let i = 0; i < 24; i++) {
    const a = i * Math.PI * 2 / 24, b = (i + 1) * Math.PI * 2 / 24;
    const shape = new T.BufferGeometry();
    shape.setAttribute('position', new T.Float32BufferAttribute([
      x + Math.cos(b) * r, 2.10, z + Math.sin(b) * r,
      x + Math.cos(a) * r, 2.10, z + Math.sin(a) * r,
      x, 3.78, z,
    ], 3));
    shape.setAttribute('uv', new T.Float32BufferAttribute([0, 0, 1, 0, .5, 1], 2));
    shape.computeVertexNormals();
    draw.add(shape, i % 2 ? palette.tent : cream, 0, 0, 0, 0, false);
    const dx = x + Math.cos(a) * r * .96, dz = z + Math.sin(a) * r * .96;
    cylinder(draw, i % 2 ? cream : brass, dx, 1.134, dz, .038, .045, 1.95, 8);
    dots.push({ point: v(dx, 2.09, dz), color: '#ffc889', radius: .255 });
    if (i % 2) box(draw, palette.walnut, dx * .87 + x * .13, .64, dz * .87 + z * .13, .40, .85, .39, -a);
  }
  cylinder(draw, brass, x, 3.85, z, .03, .11, .29, 9);
  box(draw, palette.oxblood, x, 2.098, z + 2.653, 1.71, .25, .10);
  sign(draw, x, 2.10, z + 2.72, 1.64, .202, 'SPIEGELTENT', { background: '#662d3f' });
  spruce(draw, dots, -3.14, .064, .61, 5.26, { radius: 1.33 });
  for (const [i, [px, pz, yaw]] of [[-4.91, -2.70, .36], [-2.98, -2.85, -.14], [-.80, -2.91, .03],
    [-4.62, 3.77, .56], [-2.39, 4.21, .21], [.06, 4.39, -.16], [2.53, 4.13, -.25], [4.98, 3.95, -.46]].entries()) {
    marketStall(group, dots, px, pz, yaw, i);
  }
  lamp(draw, dots, -.71, 1.78);
}

function dials(context) {
  const { group, draw, dots } = context;
  const colours = [palette.brick, palette.pale, palette.redBrick, palette.stone, palette.brick, palette.pale, palette.redBrick];
  for (let i = 0; i < 7; i++) {
    const a = i * Math.PI * 2 / 7;
    const x = Math.sin(a) * 3.61, z = Math.cos(a) * 3.61;
    road(draw, x, z, 1.34, 5.65, a, false);
    const t = a + Math.PI / 7;
    facade(group, dots, { x: Math.sin(t) * 4.76, z: Math.cos(t) * 4.76, yaw: t + Math.PI,
      w: 2.28, d: 1.08, h: 3.41 + i % 3 * .41, bays: 2, colour: colours[i],
      ground: [palette.teal, palette.plum, palette.oxblood, palette.navy][i % 4] });
    strand(draw, dots, [v(Math.sin(t) * 4.63, 4.09, Math.cos(t) * 4.63),
      v(Math.sin(t) * 2.80, 3.12, Math.cos(t) * 2.80),
      v(Math.sin(t) * .30, 3.38, Math.cos(t) * .30)], { spacing: .12, radius: .15 });
    lamp(draw, dots, Math.sin(t) * 2.26, Math.cos(t) * 2.26, 1.82);
  }
  cylinder(draw, cream, 0, .108, 0, 1.05, 1.05, .128, 26);
  monument(draw, 0, 0, 3.72, 'dials');
  spruce(draw, dots, -4.36, .062, 4.52, 2.61, { radius: .67 });
}

function covent(context) {
  const { group, draw, dots } = context;
  const lo = -2.18, hi = 5.80, front = -.48, back = -5.82, mid = (lo + hi) / 2;
  mapBox(draw, palette.paver, mid, .11, (front + back) / 2, hi - lo, .13, front - back, 1.59);
  facade(group, dots, { x: -4.61, z: -3.60, w: 3.93, d: 2.82, h: 4.66, bays: 3, brick: true,
    ground: palette.teal, label: 'COVENT GARDEN' });
  for (const z of [front, back]) {
    for (const x of [lo, -.60, 1.00, 2.60, 4.20, hi]) column(draw, x, .173, z, 2.63, .133, cream);
    box(draw, palette.pale, mid, 2.903, z, 8.22, .276, .39);
    box(draw, cream, mid, 3.091, z, 8.36, .11, .46);
    for (const x of [-1.39, .20, 1.80, 3.40, 5.00]) {
      const pts = Array.from({ length: 13 }, (_, i) => {
        const a = i / 12 * Math.PI;
        return v(x + Math.cos(a) * .751, 2.09 + Math.sin(a) * .61, z + .073);
      });
      tube(draw, cream, pts, .055, true, 8);
      tube(draw, cream, [v(x - .751, .289, z), v(x - .751, 2.08, z)], .055, false);
      tube(draw, cream, [v(x + .751, .289, z), v(x + .751, 2.08, z)], .055, false);
    }
  }
  const span = (front - back) / 2, zc = (front + back) / 2, rise = 1.38;
  for (const side of [-1, 1]) {
    const pitch = Math.atan2(rise, span) * side;
    draw.add(new T.PlaneGeometry(8.17, Math.hypot(rise, span)), giftGlass, mid, 3.21 + rise / 2,
      zc + span * .5 * side, 0, false, pitch - Math.PI / 2);
    for (let j = 0; j < 16; j++) {
      const x = lo + (hi - lo) * j / 15;
      tube(draw, iron, [v(x, 3.19, zc + span * side), v(x, 3.19 + rise, zc)], .025, false, 6);
    }
    for (let j = 0; j < 5; j++) {
      const u = j / 5;
      tube(draw, iron, [v(lo, 3.19 + rise * u, zc + span * side * (1 - u)),
        v(hi, 3.19 + rise * u, zc + span * side * (1 - u))], .022, false, 6);
    }
  }
  for (const x of [lo, hi]) {
    for (const z of [-4.44, -1.90]) column(draw, x, .173, z, 2.63, .121, cream);
    box(draw, cream, x, 2.94, zc, .33, .245, front - back + .17);
    tube(draw, cream, [v(x, 3.17, front), v(x, 4.56, zc), v(x, 3.17, back)], .050, true, 7);
  }
  box(draw, iron, mid, 4.59, zc, hi - lo + .18, .083, .085);
  for (const [i, x] of [-1.09, .37, 1.82, 3.31, 4.73].entries()) {
    const z = i % 2 ? -2.17 : -3.13;
    bell(draw, dots, x, 2.78, z, .64, i % 2 ? .18 : -.18);
    tube(draw, brass, [v(x, 3.66, z), v(x, 2.95, z)], .016, false);
    velvetBow(draw, x, 3.04, z + .015, .29);
    ellipsoid(draw, i % 2 ? brass : burgundy, x + .44, 2.33, z - .55, .158, .165, .158);
  }
  strand(draw, dots, [v(lo, 3.07, front + .12), v(0, 2.89, front + .12), v(3.58, 2.89, front + .12),
    v(hi, 3.07, front + .12)], { spacing: .124, radius: .19 });
  sign(draw, mid, 2.954, front + .251, 2.97, .218, 'APPLE MARKET', { background: '#303b3b' });
  for (const x of [-1.27, .69, 2.62, 4.57]) {
    strand(draw, dots, [v(x, 3.13, front - .10), v(x, 2.99, -3.07), v(x, 3.13, back + .16)],
      { color: '#ffdb9d', spacing: .135, radius: .18 });
  }
  for (const [i, x] of [-1.04, .93, 2.89, 4.82].entries()) marketStall(group, dots, x, -4.82, 0, i, true);
  for (const [i, x] of [.02, 2.00, 4.00].entries()) marketStall(group, dots, x, -1.50, Math.PI, i + 2, true);
  marketStall(group, dots, 4.80, 3.13, -.26, 0);
  marketStall(group, dots, 2.57, 3.89, -.18, 3);
  spruce(draw, dots, -3.70, .062, 2.40, 6.12, { radius: 1.54, seed: 8092 });
  for (const [x, z] of [[-5.64, 4.91], [5.82, 4.80], [-1.08, 1.73]]) lamp(draw, dots, x, z, 2.86);
}

const builders = { trafalgar: gallery, waterloo, regent, fortnum, bond, annabel, selfridges, oxford, liberty, carnaby, leicester, dials, covent };

export function makeAtlasTile(stop) {
  const group = new T.Group();
  const draw = batch(group);
  const dots = [], interactive = [];
  pad(draw);
  builders[stop.id]({ draw, group, dots, interactive });
  atlasVisitors(draw, stop.id);
  plinthLabel(draw, stop.name === 'Regent Street St James’s' ? 'REGENT STREET' : stop.name.replace(', Berkeley Square', ''));
  const rng = random(6018);
  for (let i = 0; i < 95; i++) {
    const z = rng() * (half * 2 - .38) - half + .19;
    const x = rng() * (half * 2 - .42) - half + .21;
    const r = .041 + rng() ** 2 * .194;
    if (rng() > .55 && Math.max(Math.abs(x), Math.abs(z)) < 5) continue;
    draw.add(new T.IcosahedronGeometry(1, 1).scale(r, .019 + r * .064, r * .59), roofSnow, x, .063, z, rng(), false);
  }
  draw.finish();
  const sparkle = glints(group, dots);
  const key = new T.PointLight('#ffd5a5', 0, 14, 2);
  key.position.set(-3.1, 2.42, 2.9);
  const fill = new T.PointLight(fillColor, 0, 14, 2);
  fill.position.set(3.4, 2.75, 1.25);
  group.add(key, fill);
  const marketLights = stop.id === 'covent' ? [-1.06, .96, 2.91, 4.82].map(x => {
    const light = new T.PointLight('#ffc280', 0, 4.6, 2);
    light.position.set(x, 2.00, -3.63);
    group.add(light);
    return light;
  }) : [];
  return {
    group, interactive,
    dispose() {
      const materials = new Set();
      group.traverse(object => {
        object.geometry?.dispose();
        if (object.material?.userData.atlasOwned || object.material?.isShaderMaterial) materials.add(object.material);
      });
      for (const material of materials) {
        material.map?.dispose();
        material.dispose();
      }
    },
    update(time, height, warm) {
      sparkle.update(time, height, .13 + warm * .91);
      key.intensity = warm * 17;
      fill.intensity = warm * 15;
      for (const lamp of marketLights) lamp.intensity = warm * 5.9;
      atlasWindows.forEach((m, i) => { m.emissiveIntensity = warm * [1.34, 1.12, .67][i]; });
      palette.lantern.emissiveIntensity = .18 + warm * 2.12;
    },
  };
}



