import * as T from 'three';
import { box, cylinder, random, texture, tube, v } from './model.js';

export const pbr = (color, options = {}) => new T.MeshStandardMaterial({ color, roughness: .76, ...options });
export const metals = {
  gold: pbr('#dcac59', { metalness: .76, roughness: .23 }),
  bronze: pbr('#4f6556', { metalness: .61, roughness: .37 }),
  iron: pbr('#313942', { metalness: .63, roughness: .33 }),
};
export const snow = pbr('#e5eef5', { roughness: .85 });
const ornament = [
  new T.MeshPhysicalMaterial({ color: '#a01b32', roughness: .22, metalness: .49, clearcoat: 1 }),
  metals.gold,
  new T.MeshPhysicalMaterial({ color: '#e4d6b7', roughness: .16, metalness: .71, clearcoat: .8 }),
];
const cloth = pbr('#8c1329', { roughness: .91 });
const bark = pbr('#5f3d2d');
const foliage = pbr('#fff', { vertexColors: true, roughness: .79, side: T.DoubleSide });
const needleMass = ['#163a2a', '#254835', '#31523b', '#3d5c42'].map(color => pbr(color));
const wraps = ['#9f2938', '#dac2a3', '#205145', '#c78b60'].map(color => pbr(color, { roughness: .48 }));

export function texturedStone(color, variant = 'stone') {
  const base = new T.Color(color);
  const rng = random(7302);
  const map = texture(512, 384, (ctx, w, h) => {
    ctx.fillStyle = base.clone().multiplyScalar(.68).getStyle();
    ctx.fillRect(0, 0, w, h);
    const isBrick = variant === 'brick';
    const unitW = isBrick ? 64 : variant === 'paver' ? 86 : 128;
    const unitH = isBrick ? 24 : variant === 'paver' ? 48 : 64;
    for (let y = 0; y < h; y += unitH) for (let col = -1; col <= w / unitW; col++) {
      const x = col * unitW + ((y / unitH) % 2) * unitW / 2;
      ctx.fillStyle = base.clone().multiplyScalar(.81 + rng() * .27).getStyle();
      ctx.fillRect(x + 1.4, y + 1.4, unitW - 2.8, unitH - 2.8);
      ctx.fillStyle = '#f7e9da24';
      ctx.fillRect(x + 2.5, y + 2, unitW - 5, 1.35);
      ctx.fillStyle = '#31293221';
      ctx.fillRect(x + 3, y + unitH - 3, unitW - 6, 1.5);
    }
    for (let i = 0; i < 28000; i++) {
      ctx.fillStyle = rng() > .54 ? '#f6eceb23' : '#211b2720';
      ctx.fillRect(rng() * w, rng() * h, .7 + rng() * 4, .65 + rng() * 1.4);
    }
  });
  map.wrapS = map.wrapT = T.RepeatWrapping;
  map.anisotropy = 8;
  return pbr('#fff', { map, bumpMap: map, bumpScale: .026, roughness: variant === 'paver' ? .49 : .82 });
}

export function woodFinish(color, panel = false) {
  const rng = random(9911);
  const base = new T.Color(color);
  const map = texture(512, 512, (ctx, w, h) => {
    ctx.fillStyle = base.getStyle();
    ctx.fillRect(0, 0, w, h);
    for (let i = 0; i < 560; i++) {
      const x = rng() * w, phase = rng() * 7;
      ctx.strokeStyle = rng() > .57 ? '#f5bb8644' : '#37231e45';
      ctx.lineWidth = .22 + rng() * 1.15;
      ctx.beginPath();
      for (let y = 0; y <= h; y += 18) {
        ctx.lineTo(x + Math.sin(y * .013 + phase) * (2 + rng() * 4), y);
      }
      ctx.stroke();
    }
    if (panel) {
      for (let x = 0; x < w; x += 42) {
        ctx.fillStyle = '#32201f98'; ctx.fillRect(x, 0, 2, h);
        ctx.fillStyle = '#ffe0b841'; ctx.fillRect(x + 2, 0, 1.3, h);
        const y = (x * 7.2) % h;
        ctx.fillStyle = '#37211d98'; ctx.fillRect(x, y, 42, 2);
      }
    }
  });
  map.wrapS = map.wrapT = T.RepeatWrapping;
  map.anisotropy = 8;
  return pbr('#fff', { map, bumpMap: map, bumpScale: .021, roughness: .44 });
}

export function mapBox(draw, mat, x, y, z, w, h, d, unit = 2.5, yaw = 0) {
  const geom = new T.BoxGeometry(w, h, d);
  const uv = geom.attributes.uv;
  for (let i = 0; i < uv.count; i++) {
    const face = i >> 2;
    const u = face < 2 ? d : w;
    const t = face === 2 || face === 3 ? d : h;
    uv.setXY(i, uv.getX(i) * u / unit, uv.getY(i) * t / unit);
  }
  draw.add(geom, mat, x, y, z, yaw);
}

export function star(draw, material, x, y, z, radius, yaw = 0, arms = 5, depth = .040) {
  const shape = new T.Shape(Array.from({ length: arms * 2 }, (_, index) => {
    const a = Math.PI / 2 + index * Math.PI / arms, r = index % 2 ? radius * .40 : radius;
    return new T.Vector2(Math.cos(a) * r, Math.sin(a) * r);
  }));
  draw.add(new T.ExtrudeGeometry(shape, { depth, bevelEnabled: true, bevelThickness: .014, bevelSize: .012,
    bevelSegments: 2, curveSegments: 2 }), material, x, y, z, yaw);
}

export function velvetBow(draw, x, y, z, size, yaw = 0) {
  const positions = [-1, 1];
  for (const side of positions) {
    const loop = new T.SphereGeometry(1, 12, 7).scale(size * .39, size * .195, size * .10);
    const shift = side * size * .31;
    draw.add(loop, cloth, x + Math.cos(yaw) * shift, y, z - Math.sin(yaw) * shift, yaw, false, 0, side * .24);
    const tail = new T.Shape().moveTo(-.13, 0).lineTo(.11, 0).quadraticCurveTo(.17, -.37, .16, -.71)
      .lineTo(.025, -.62).lineTo(-.11, -.73).quadraticCurveTo(-.16, -.39, -.13, 0);
    draw.add(new T.ExtrudeGeometry(tail, { depth: .027, bevelEnabled: true, bevelThickness: .012,
      bevelSize: .014, bevelSegments: 1 }).scale(size, size, size),
    cloth, x + Math.cos(yaw) * side * size * .095, y - size * .058, z - Math.sin(yaw) * side * size * .095,
    yaw, false, .12, side * .32);
  }
  draw.add(new T.SphereGeometry(size * .142, 9, 7).scale(1, 1.08, .75), cloth, x, y, z, yaw);
}

export function parcel(draw, x, y, z, size, index, yaw = 0) {
  const h = size * (.73 + index % 3 * .14);
  const wrap = wraps[index % wraps.length];
  box(draw, wrap, x, y + h / 2, z, size, h, size * .81, yaw);
  box(draw, wrap, x, y + h - .018, z, size + .029, .058, size * .81 + .034, yaw);
  box(draw, metals.gold, x, y + h * .51, z, size * .16, h + .037, size * .81 + .043, yaw, false);
  box(draw, metals.gold, x, y + h * .51, z, size + .046, h + .036, size * .133, yaw, false);
}

export function spruce(draw, dots, x, y, z, height, { vertical = false, seed = 9323, gifts = true, radius = height * .28 } = {}) {
  const rng = random(seed);
  const colors = ['#153627', '#264734', '#3d5b41', '#567153'].map(colour => new T.Color(colour));
  cylinder(draw, bark, x, y + height * .28, z, height * .019, height * .043, height * .56, 14);
  const xyz = [], rgb = [];
  const pivot = v(0, 0, 0), side = v(0, 0, 0);
  for (let branch = 0; branch < 265; branch++) {
    const t = branch / 265, a = branch * 2.39996 + (rng() - .5) * .31;
    const extent = radius * (1 - t) ** .77 * (.78 + rng() * .24);
    const baseY = height * (.105 + t * .856);
    const dx = Math.cos(a), dz = Math.sin(a);
    side.set(-dz, 0, dx);
    const yaw = Math.atan2(dx, dz);
    const mass = new T.ConeGeometry(1, 1, 7, 2).scale(extent * .255, extent * .994, extent * .154);
    draw.add(mass, needleMass[branch % 4], x + dx * extent * .444,
      y + baseY - height * .023, z + dz * extent * .444, yaw, false, 1.70);
    for (const k of [-1, 1]) {
      const b = a + k * .41;
      const tuft = new T.ConeGeometry(1, 1, 5, 1).scale(extent * .099, extent * .395, extent * .084);
      draw.add(tuft, needleMass[(branch + 2 + k) % 4], x + dx * extent * .69 + Math.cos(b) * extent * .12,
        y + baseY - height * .031, z + dz * extent * .69 + Math.sin(b) * extent * .12,
        Math.PI / 2 - b, false, 1.47);
    }
    for (let twig = 0; twig < 14; twig++) {
      const s = (twig + 1) / 14;
      const width = height * (.023 + .010 * rng()) * (1 - t * .54) * (1 - s * .51);
      const start = extent * s;
      pivot.set(dx * start, baseY - height * .066 * s + height * .047 * s ** 3, dz * start);
      const angle = a + (twig % 2 ? -.71 : .71);
      const twigX = Math.cos(angle), twigZ = Math.sin(angle);
      for (let n = 0; n < 6; n++) {
        const sign = n % 2 ? 1 : -1;
        const spread = width * (.65 + n * .21);
        const px = pivot.x + twigX * spread, pz = pivot.z + twigZ * spread;
        const py = pivot.y + width * (.08 + n * .09);
        const length = width * (.65 + rng() * 1.12), b = angle + sign * (.63 + rng() * .68);
        const rootWidth = width * (.068 + rng() * .075);
        xyz.push(px + side.x * rootWidth, py, pz + side.z * rootWidth,
          px - side.x * rootWidth, py + width * .08, pz - side.z * rootWidth,
          px + Math.cos(b) * length, py + length * (rng() * .7 - .18), pz + Math.sin(b) * length);
        const color = colors[(branch + twig + n) % colors.length];
        rgb.push(...color.toArray(), ...color.toArray(), ...color.clone().multiplyScalar(.97 + rng() * .24).toArray());
      }
    }
    if (!vertical && branch % 6 === 0 && t < .92) {
      const r = height * (.009 + rng() * .011);
      const edge = extent * .96 + height * .025;
      const ox = x + dx * edge, oz = z + dz * edge;
      draw.add(new T.SphereGeometry(r, 12, 9), ornament[branch % 5 === 0 ? 2 : branch % 12 === 0 ? 1 : 0],
        ox, y + baseY - height * .056, oz);
      cylinder(draw, metals.gold, ox, y + baseY - height * .056 + r * 1.02, oz, r * .22, r * .38, r * .33, 7);
    }
    if (!vertical && branch % 43 === 13 && t < .88) {
      const edge = extent + height * .018;
      velvetBow(draw, x + dx * edge, y + baseY - height * .015, z + dz * edge, height * .099, Math.PI / 2 - a);
    }
  }
  const shape = new T.BufferGeometry();
  shape.setAttribute('position', new T.Float32BufferAttribute(xyz, 3));
  shape.setAttribute('color', new T.Float32BufferAttribute(rgb, 3));
  shape.computeVertexNormals();
  draw.add(shape, foliage, x, y, z, 0, false);
  for (let i = 0; i < (vertical ? 162 : 265); i++) {
    const t = (i + .25) / (vertical ? 162 : 265);
    const a = vertical ? (i % 9) * Math.PI * 2 / 9 + Math.sin(i * .8) * .052 : i * 2.39996;
    const r = radius * (1 - t) ** .77 * (.82 + rng() * .24) + height * .018;
    dots.push({ point: v(x + Math.cos(a) * r, y + height * (.08 + t * .86), z + Math.sin(a) * r),
      color: vertical ? '#fff1d7' : i % 19 === 0 ? '#ec6054' : '#ffd4a1', radius: height * (.019 + rng() * .021) });
  }
  if (!vertical) {
    star(draw, metals.gold, x, y + height * .992, z, height * .071, .27, 7);
    dots.push({ point: v(x, y + height * .992, z + .075), color: '#ffe0a5', radius: height * .13 });
  }
  if (gifts) for (let i = 0; i < 14; i++) {
    const a = i * 2.39996, r = radius * (.48 + rng() * .64);
    parcel(draw, x + Math.cos(a) * r, y, z + Math.sin(a) * r, height * (.056 + rng() * .054), i, a * .32);
  }
}

export function strand(draw, dots, knots, { color = '#ffd9a2', spacing = .18, radius = .16, thickness = .008 } = {}) {
  tube(draw, metals.iron, knots, thickness);
  const curve = new T.CatmullRomCurve3(knots);
  const count = Math.max(3, Math.round(curve.getLength() / spacing));
  for (let i = 0; i <= count; i++) dots.push({ point: curve.getPointAt(i / count), color, radius });
}

export function wreath(draw, dots, x, y, z, radius, yaw = 0) {
  const greens = wreath.greens ??= ['#173c2a', '#2b543e', '#426344'].map(c => pbr(c));
  const rng = random(9410);
  for (let i = 0; i < 102; i++) {
    const a = i * 2.39996, r = radius * (.86 + rng() * .25);
    const dx = Math.cos(a) * r, dy = Math.sin(a) * r;
    const geo = new T.ConeGeometry(radius * .11, radius * (.24 + rng() * .22), 5);
    draw.add(geo, greens[i % 3], x + Math.cos(yaw) * dx, y + dy, z - Math.sin(yaw) * dx,
      yaw, false, .57, a + Math.PI / 2);
    if (i % 5 === 0) {
      dots.push({ point: v(x + Math.cos(yaw) * dx + .075 * Math.sin(yaw), y + dy,
        z - Math.sin(yaw) * dx + .075 * Math.cos(yaw)), color: '#ffe2b5', radius: .105 + radius * .13 });
    }
  }
  velvetBow(draw, x + Math.sin(yaw) * .075, y + radius * .95, z + Math.cos(yaw) * .075, radius * .71, yaw);
}

export function glints(parent, dots) {
  const position = [], tint = [], radius = [], phase = [];
  for (const dot of dots) {
    position.push(...dot.point.toArray());
    tint.push(...new T.Color(dot.color).toArray());
    radius.push(dot.radius ?? .16);
    phase.push((phase.length * 3.397) % (2 * Math.PI));
  }
  const geo = new T.BufferGeometry();
  for (const [name, value, count] of [['position', position, 3], ['tint', tint, 3], ['radius', radius, 1], ['phase', phase, 1]]) {
    geo.setAttribute(name, new T.Float32BufferAttribute(value, count));
  }
  const uniforms = { strength: { value: 1 }, height: { value: 1 }, time: { value: 0 } };
  const material = new T.ShaderMaterial({
    transparent: true, depthWrite: false, blending: T.AdditiveBlending, uniforms,
    vertexShader: [
      'attribute vec3 tint; attribute float radius, phase;',
      'uniform float height, time; varying vec3 c; varying float pulse;',
      'void main() {',
      ' c = tint; pulse = pow(.5 + .5 * sin(phase + time * 2.2), 8.);',
      ' gl_Position = projectionMatrix * modelViewMatrix * vec4(position,1.);',
      ' gl_PointSize = clamp(radius * (1. + pulse * .29) * height * projectionMatrix[1][1] / gl_Position.w, 3., 92.);',
      '}',
    ].join('\n'),
    fragmentShader: [
      'uniform float strength; varying vec3 c; varying float pulse;',
      'void main() {',
      ' vec2 p=abs(gl_PointCoord-.5)*2.; float d=length(p);',
      ' float core=exp(-d*d*54.); float halo=exp(-d*d*7.);',
      ' float ray=max(exp(-p.x*43.-p.y*5.),exp(-p.y*43.-p.x*5.));',
      ' gl_FragColor = vec4(c, strength * (.75*core + .30*halo + .54*pulse*ray));',
      ' #include <colorspace_fragment>',
      '}',
    ].join('\n'),
  });
  const points = new T.Points(geo, material);
  parent.add(points);
  return { update(time, height, strength) {
    uniforms.time.value = time;
    uniforms.height.value = height;
    uniforms.strength.value = strength;
  } };
}


