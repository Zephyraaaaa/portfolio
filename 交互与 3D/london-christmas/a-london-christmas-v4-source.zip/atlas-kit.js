import * as T from 'three';
import { batch, box, cylinder, rounded, slab, texture, tube, v } from './model.js';
import { sign as baseSign, glassFinish } from './architecture.js';
import { pbr, texturedStone, woodFinish, mapBox, metals, snow, wreath, parcel, star } from './atlas-finish.js';

export const palette = {
  stone: texturedStone('#bda88e'), pale: texturedStone('#ddcbb0'), brick: texturedStone('#a76551', 'brick'),
  redBrick: texturedStone('#8e5349', 'brick'), paver: texturedStone('#9a98a1', 'paver'),
  plaza: texturedStone('#b0a599', 'paver'), road: texturedStone('#686b79', 'paver'),
  ash: pbr('#968373'), moulding: pbr('#dcccb5'), white: pbr('#ebddd0'), roof: texturedStone('#3b4556', 'brick'),
  oxblood: pbr('#782337'), navy: pbr('#23364e'), teal: pbr('#216055'), aqua: pbr('#52867d'),
  plum: pbr('#613f62'), oak: woodFinish('#77503e', true), walnut: woodFinish('#483025'),
  base: woodFinish('#28252b'), kerb: pbr('#bdb5aa'), glass: glassFinish(),
  lantern: pbr('#fff0c8', { emissive: '#ffd196', emissiveIntensity: 1.2 }),
  water: new T.MeshPhysicalMaterial({ color: '#577b87', roughness: .15, metalness: .29, clearcoat: .8 }),
  tent: pbr('#a52f42'), forest: pbr('#32563e'),
};
palette.glass.roughness = .26;
palette.glass.metalness = .26;
const darkGlass = palette.glass.clone();
darkGlass.emissive.set('#e1bca4');
const silverGlass = palette.glass.clone();
silverGlass.emissive.set('#b6dcff');
export const atlasWindows = [palette.glass, darkGlass, silverGlass];

export const sign = (draw, x, y, z, w, h, text, options) =>
  baseSign(draw, x, y, z, w, h, text, { ...options, transient: true });

const brass = metals.gold;
const iron = metals.iron;
const trim = palette.moulding;

export function pad(draw, size = 13.7, plaza = true) {
  const h = size / 2;
  const contour = rounded(-h, h, -h, h, [.19, .19, .19, .19], 8);
  slab(draw, palette.base, contour, -.67, .61, .074);
  slab(draw, brass, contour, -.127, .036, .021, false);
  mapBox(draw, plaza ? palette.plaza : palette.paver, 0, -.012, 0, size - .025, .10, size - .025, 2.18);
}
export function road(draw, x, z, w, d, yaw = 0, lines = true) {
  mapBox(draw, palette.road, x, .041, z, w, .032, d, 2.19, yaw);
  if (!lines) return;
  for (let i = 0; i < Math.floor(d / 1.17); i++) {
    const dz = -d / 2 + .69 + i * 1.17;
    for (const side of [-1, 0, 1]) {
      const dx = side * (w / 2 - .31);
      const xx = x + Math.cos(yaw) * dx + Math.sin(yaw) * dz;
      const zz = z - Math.sin(yaw) * dx + Math.cos(yaw) * dz;
      box(draw, side ? palette.ash : trim, xx, .061, zz, side ? .028 : .048, .007, .69, yaw, false);
    }
  }
}
export function arch(w, h) {
  const spring = h - w / 2;
  return new T.Shape().moveTo(-w / 2, 0).lineTo(w / 2, 0).lineTo(w / 2, spring)
    .absarc(0, spring, w / 2, 0, Math.PI, false).closePath();
}
function archTrim(draw, mat, x, y, z, w, h, width, depth, yaw = 0) {
  const shape = arch(w + 2 * width, h + width);
  const inside = arch(w, h);
  shape.holes.push(new T.Path(inside.getPoints(15).reverse()));
  draw.add(new T.ExtrudeGeometry(shape, { depth, bevelEnabled: true, bevelThickness: .015,
    bevelSize: .012, bevelSegments: 1, curveSegments: 14 }), mat, x, y, z, yaw);
}
function paneGeo(w, h, arched) {
  if (!arched) return new T.PlaneGeometry(w, h);
  const geo = new T.ShapeGeometry(arch(w, h), 16).translate(0, -h / 2, 0);
  const uv = geo.attributes.uv;
  const pos = geo.attributes.position;
  for (let i = 0; i < uv.count; i++) uv.setXY(i, pos.getX(i) / w + .5, pos.getY(i) / h + .5);
  return geo;
}

export function sash(draw, x, y, z, w, h, { arched = false, shop = false, timber = false, pane = 0, yaw = 0, display = false } = {}) {
  const cosine = Math.cos(yaw), sine = Math.sin(yaw);
  const frame = timber ? palette.walnut : shop ? palette.navy : trim;
  const P = (u, q, r) => [x + u * cosine + r * sine, y + q, z - u * sine + r * cosine];
  const part = (m, u, q, r, a, b, c) => box(draw, m, ...P(u, q, r), a, b, c, yaw);
  if (arched) archTrim(draw, frame, ...P(0, -h / 2, 0), w, h, .079, .105, yaw);
  else {
    part(frame, 0, -h / 2, .045, w + .16, .081, .12);
    part(frame, 0, h / 2, .045, w + .16, .081, .12);
    for (const k of [-1, 1]) part(frame, k * (w / 2 + .025), 0, .045, .076, h, .12);
  }
  part(shop ? palette.navy : palette.ash, 0, -h / 2 - .081, .095, w + .27, .091, .25);
  draw.add(paneGeo(w, h, arched), atlasWindows[pane % 3], ...P(0, 0, .046), yaw, false);
  for (const dx of shop ? [-.25, .25] : [0]) part(frame, w * dx, arched ? -.07 : 0, .117, .032, h - (arched ? .14 : 0), .066);
  part(frame, 0, h * (arched ? .05 : .01), .117, w, .034, .066);
  if (timber && !arched) {
    for (const k of [-1, 1]) {
      const a = [v(...P(-w * .49, h * k * .48, .128)), v(...P(w * .49, h * -k * .48, .128))];
      tube(draw, frame, a, .018, false, 6);
    }
  }
  if (display) {
    for (let i = 0; i < 3; i++) {
      const point = P(w * (-.30 + i * .30), -h / 2 + .047, .168);
      parcel(draw, ...point, Math.min(.26, w * .21) + i % 2 * .055, i + pane, yaw + .18 * i);
    }
  }
}

export function column(draw, x, baseY, z, h, radius, mat = trim, flute = true) {
  box(draw, mat, x, baseY + .065, z, radius * 2.78, .13, radius * 2.78);
  cylinder(draw, mat, x, baseY + .16, z, radius * 1.18, radius * 1.29, .15, 20);
  cylinder(draw, mat, x, baseY + h / 2, z, radius * .86, radius, h - .21, 24);
  cylinder(draw, mat, x, baseY + h - .10, z, radius * 1.27, radius * .90, .17, 20);
  box(draw, mat, x, baseY + h - .018, z, radius * 2.74, .12, radius * 2.74);
  if (flute) {
    for (let i = 0; i < 14; i++) {
      const a = i * Math.PI * 2 / 14, dx = Math.cos(a) * radius, dz = Math.sin(a) * radius;
      tube(draw, mat, [v(x + dx * .98, baseY + .25, z + dz * .98),
        v(x + dx * .875, baseY + h - .22, z + dz * .875)], radius * .053, false, 5);
    }
  }
}

function rail(draw, x, y, z, width) {
  for (let i = 0; i < Math.round(width / .128) + 1; i++) {
    const dx = -width / 2 + i * .128;
    cylinder(draw, iron, x + dx, y + .165, z, .012, .014, .33, 7);
  }
  box(draw, iron, x, y + .33, z, width + .047, .032, .035);
  box(draw, trim, x, y - .035, z - .101, width + .14, .068, .39);
}

export function facade(root, dots, settings) {
  const { x = 0, z = -3, w = 6.3, d = 3.0, h = 6.0, bays = 5, yaw = 0, label, columns = false,
    brick = false, roof = 'mansard', colour, ground = palette.navy, timber = false, festive = true, shop = true } = settings;
  const group = new T.Group();
  group.position.set(x, .064, z);
  group.rotation.y = yaw;
  group.updateMatrix();
  root.add(group);
  const draw = batch(group);
  const local = [];
  const body = colour || (brick ? palette.brick : palette.stone);
  mapBox(draw, body, 0, h / 2, -d / 2, w, h, d, brick ? 2.63 : 2.72);
  mapBox(draw, palette.ash, 0, .195, -d / 2, w + .08, .26, d + .12, 2.2);
  if (shop) box(draw, ground, 0, 1.12, .035, w + .018, 1.78, .106);
  const rows = h > 6.5 ? [2.98, 4.45, 5.87] : h > 4.8 ? [2.78, 4.23] : [2.74];
  for (const [y, thick] of [[.325, .087], [2.12, .145], ...rows.map(y => [y - .67, .072]), [h - .19, .125], [h + .015, .153]]) {
    box(draw, trim, 0, y, -d / 2, w + .23, thick, d + .24);
    if (y > h - .3) box(draw, palette.white, 0, y + thick * .61, -d / 2, w + .29, thick * .35, d + .30);
  }
  for (let i = 0; i < Math.floor(w / .15); i++) {
    const xx = -w / 2 + .081 + i * .151;
    box(draw, trim, xx, h - .207, .092, .067, .17, .14);
  }
  const gap = w / bays;
  for (let i = 0; i < bays; i++) {
    const dx = (i - (bays - 1) / 2) * gap;
    if (shop) {
      sash(draw, dx, 1.255, .10, gap * .70, 1.42, { arched: !timber && i % 3 !== 1, shop: true, timber, pane: i % 3, display: i % 2 === 0 });
      if (i % 2 === 0 && festive) wreath(draw, local, dx, 2.12, .18, .184);
    }
    for (const [r, y] of rows.entries()) {
      sash(draw, dx, y, .042, gap * (r === 0 ? .53 : .48), r === 0 ? 1.11 : .92, { arched: !timber && r === 0, timber, pane: (i + r) % 3 });
      if (r === 0 && i % 2 === 1 && gap > .8) rail(draw, dx, y - .61, .30, gap * .66);
    }
  }
  if (columns) {
    for (let i = 0; i <= bays; i++) {
      const xx = (i / bays - .5) * (w - .20);
      column(draw, xx, 2.17, .22, Math.min(3.11, h - 2.27), .122, trim);
    }
  } else {
    for (const xx of [-w / 2 + .11, w / 2 - .11]) for (let i = 0; i < Math.floor(h / .24); i++) {
      box(draw, trim, xx, .31 + i * .235, .027, i % 2 ? .19 : .30, .184, .10);
    }
  }
  for (const side of [-1, 1]) for (let i = 0; i < Math.max(1, Math.floor(d / 1.1)); i++) {
    const zz = -(i + .54) * d / Math.max(1, Math.floor(d / 1.1));
    for (const [j, yy] of rows.entries()) sash(draw, side * (w / 2 + .026), yy, zz, .61, j === 0 ? 1.1 : .89,
      { yaw: side * Math.PI / 2, arched: j === 0 && !timber, timber, pane: (j + i) % 3 });
  }
  if (d < 2.40) {
    for (const xx of [-w * .29, w * .29]) for (const [i, yy] of rows.entries()) {
      sash(draw, xx, yy, -d - .045, Math.min(w * .22, .76), i === 0 ? 1.08 : .90,
        { yaw: Math.PI, arched: i === 0, timber, pane: (i + 1) % 3 });
    }
  }
  if (roof === 'mansard') {
    const profile = new T.Shape().moveTo(-w * .49, 0).lineTo(w * .49, 0).lineTo(w * .413, .72).lineTo(-w * .413, .72).closePath();
    draw.add(new T.ExtrudeGeometry(profile, { depth: d - .19, bevelEnabled: true, bevelSize: .016,
      bevelThickness: .021, bevelSegments: 2 }), palette.roof, 0, h + .087, -d + .085);
    box(draw, snow, 0, h + .835, -d / 2, w * .824, .044, d - .32);
    for (const xx of [-w * .31, 0, w * .31]) {
      box(draw, palette.roof, xx, h + .48, -.228, .55, .55, .64);
      sash(draw, xx, h + .45, .094, .37, .40, { pane: 2 });
      box(draw, trim, xx, h + .783, .053, .68, .070, .60);
    }
  } else {
    box(draw, palette.roof, 0, h + .102, -d / 2, w - .1, .13, d - .18);
    box(draw, snow, 0, h + .181, -d / 2, w - .29, .042, d - .36);
  }
  for (const side of [-1, 1]) {
    mapBox(draw, brick ? palette.redBrick : palette.stone, side * w * .38, h + .41, -d * .78, .36, .76, .42, 1.38);
    box(draw, trim, side * w * .38, h + .792, -d * .78, .444, .094, .50);
    cylinder(draw, palette.oxblood, side * w * .38, h + .893, -d * .78, .065, .061, .16, 10);
  }
  if (label) {
    box(draw, ground, 0, 2.09, .108, Math.min(w * .88, 4.2), .26, .125);
    sign(draw, 0, 2.09, .182, Math.min(w * .86, 4.0), .21, label, { background: ground === palette.teal ? '#254c46' : '#382e39' });
  }
  if (festive) {
    for (let i = 0; i <= Math.ceil(w / .142); i++) {
      const dx = (i / Math.ceil(w / .142) - .5) * (w - .07);
      local.push({ point: v(dx, h - .12, .155), color: '#ffdbac', radius: .14 });
      if (i % 2 === 0 && shop) local.push({ point: v(dx, 1.96, .196), color: '#ffcd8a', radius: .13 });
    }
  }
  draw.finish();
  for (const point of local) dots.push({ ...point, point: point.point.applyMatrix4(group.matrix) });
  return group;
}

export function lamp(draw, dots, x, z, height = 2.9) {
  const s = height / 3.0;
  cylinder(draw, iron, x, .22 * s, z, .119 * s, .195 * s, .31 * s, 14);
  cylinder(draw, iron, x, 1.36 * s, z, .043 * s, .067 * s, 2.12 * s, 12);
  cylinder(draw, brass, x, 2.41 * s, z, .098 * s, .062 * s, .097 * s, 13);
  draw.add(new T.CylinderGeometry(.174 * s, .105 * s, .34 * s, 4), palette.lantern, x, 2.61 * s, z, Math.PI / 4, false);
  for (const dx of [-1, 1]) for (const dz of [-1, 1]) tube(draw, iron, [v(x + dx * .082 * s, 2.44 * s, z + dz * .082 * s),
    v(x + dx * .124 * s, 2.78 * s, z + dz * .124 * s)], .013 * s, false, 6);
  draw.add(new T.CylinderGeometry(.071 * s, .196 * s, .168 * s, 4), iron, x, 2.86 * s, z, Math.PI / 4);
  cylinder(draw, brass, x, 2.99 * s, z, .028 * s, .068 * s, .123 * s, 8);
  dots.push({ point: v(x, 2.63 * s, z + .14 * s), color: '#ffc78b', radius: .70 * s });
}
export function bell(draw, dots, x, y, z, size, roll = 0) {
  const profile = [[.13, .55], [.27, .45], [.30, .20], [.32, -.05], [.43, -.22],
    [.50, -.31], [.47, -.38], [.39, -.37], [.36, -.27], [.25, -.02], [.23, .34], [.16, .48]]
    .map(([r, yy]) => new T.Vector2(r * size, yy * size));
  draw.add(new T.LatheGeometry(profile, 32), brass, x, y, z, 0, true, 0, roll);
  draw.add(new T.SphereGeometry(size * .107, 12, 9), brass, x + roll * size * .31, y - size * .36, z);
  dots.push({ point: v(x + size * .33, y - size * .265, z + size * .20), color: '#ffe0a5', radius: size * .35 });
}

export function marketStall(root, dots, x, z, yaw, index, indoors = false) {
  const group = new T.Group();
  group.position.set(x, .06, z);
  group.rotation.y = yaw;
  group.updateMatrix();
  root.add(group);
  const draw = batch(group);
  const h = 1.53;
  const canopies = [palette.oxblood, palette.teal, palette.navy, palette.plum];
  mapBox(draw, palette.oak, 0, .12, 0, 1.65, .19, 1.24, 1.4);
  mapBox(draw, palette.oak, 0, .74, -.592, 1.62, 1.33, .085, 1.28);
  for (const xx of [-.78, .78]) {
    mapBox(draw, palette.oak, xx, .78, 0, .095, 1.55, 1.17, 1.28);
    for (const zz of [-.60, .61]) box(draw, palette.walnut, xx, .79, zz, .088, 1.55, .091);
  }
  mapBox(draw, palette.oak, 0, .37, .598, 1.61, .57, .109, 1.4);
  mapBox(draw, palette.walnut, 0, .671, .62, 1.72, .091, .43, 1.3);
  for (const side of [-1, 1]) {
    draw.add(new T.BoxGeometry(1.80, .065, .798), canopies[index % 4], 0, h + .106, side * .349, 0, true, side * .28);
    if (!indoors && side < 0) draw.add(new T.BoxGeometry(1.68, .024, .736), snow, -.02, h + .157, side * .349, 0, false, side * .28);
  }
  sign(draw, 0, 1.421, .697, 1.25, .155, ['MULLED WINE', 'HANDMADE', 'MINCE PIES', 'WINTER GIFTS'][index % 4],
    { background: '#53332f' });
  for (let i = 0; i < 6; i++) {
    const xx = -.64 + i * .252;
    parcel(draw, xx, .717, .64 + i % 2 * .08, .155 + i % 3 * .021, i + index, (i % 3 - 1) * .18);
    const pos = v(xx, 1.53, .735).applyMatrix4(group.matrix);
    dots.push({ point: pos, color: '#ffce86', radius: .19 });
  }
  for (let i = 0; i < 4; i++) {
    cylinder(draw, i % 2 ? trim : palette.oxblood, -.55 + i * .36, 1.005, -.38, .086, .070, .21, 11);
    cylinder(draw, brass, -.55 + i * .36, 1.119, -.38, .050, .076, .041, 11);
  }
  draw.finish();
}

export function plinthLabel(draw, label, size = 13.7) {
  box(draw, brass, 0, -.361, size / 2 + .063, 3.86, .304, .043);
  sign(draw, 0, -.359, size / 2 + .088, 3.72, .245, label.toUpperCase(), { background: '#292630', colour: '#f5d69f' });
}

export function starStrand(draw, dots, x0, x1, z, height, count, tint = '#ffe6ae') {
  const luminous = pbr(tint, { emissive: tint, emissiveIntensity: .42 });
  luminous.userData.atlasOwned = true;
  for (let i = 0; i < count; i++) {
    const t = i / (count - 1), x = x0 + (x1 - x0) * t;
    const y = height - .60 * Math.sin(Math.PI * t);
    const r = i % 3 === 0 ? .27 : .16;
    star(draw, luminous, x, y, z, r, 0, 5, .017);
    dots.push({ point: v(x, y, z + .029), color: tint, radius: r * 2.22 });
  }
  tube(draw, iron, [v(x0, height, z), v((x0 + x1) / 2, height - .60, z), v(x1, height, z)], .008);
}



