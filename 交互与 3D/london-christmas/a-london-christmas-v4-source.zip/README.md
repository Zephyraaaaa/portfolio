# A London Christmas Atlas

Field Editions 第 04 期。由《A London Christmas》摄政街版扩展为 13 站伦敦圣诞微缩地图。以各地标的主要轮廓和有代表性的节庆陈设建模，建筑比例、街道关系和各年灯饰为微缩体验做了重组。

## 打开与浏览

先解压打开版 ZIP，再把里面的 `a-london-christmas-atlas.html` 拖入支持 WebGL 2 的 Chrome 或 Edge。单文件内嵌代码、字体、图像和上一版街景配乐。

- 顶部下拉框和下方站点列表均可切换 13 个方形台座场景。默认从 Covent Garden 开场。选择 `Street level` 可进入 Apple Market 的摊位之间。
- `The Christmas sitting room` 进入客厅。点窗扇或 `Open window` 可开关窗，`Window view` 推近窗边。窗外是实时渲染的原摄政街场景。也可在 `Walk Regent Street` 中点亮着灯的客厅窗户进入。
- `Fireworks` 控制黄昏及夜间烟花，也会影响从窗内看到的夜空。白天、黄昏、夜间三档灯光对各站和窗外街景生效。
- 摄政街长版保留双层巴士、天使灯、飞行雪橇、行人对话和长椅明信片。点击 `By the bench` 推近长椅，再点长椅打开明信片。
- `Music` 提供 Mariah Carey 专辑录音的官方完整版入口，打开官方播放页需要联网。离线探索时可选择本地音频文件，或使用上一版的抖音街景配乐。[Columbia 官方音频](https://www.youtube.com/watch?v=fRyhqobl0sk) · [上一版配乐出处](https://www.douyin.com/video/7572996174560939429)

## 构建和浏览器检查

使用 Node.js 20.11 或更新版本。

```sh
npm ci
npm run build
npm run verify
```

构建输出为 `dist/a-london-christmas-atlas.html`。检查脚本使用断网的 Chrome，逐个渲染 13 站并输出截图，验证室内窗景、倒数日历、手机触控、本地音频及保留的摄政街交互。Windows 默认查找 Chrome 的常规路径，也可通过 `CHROME_PATH` 指定浏览器。截图保存至 `screenshots-v4/`。

## 文件

- `atlas-places.js` 包含 13 站各自的构图和标志性建筑。
- `atlas-kit.js`、`atlas-finish.js`、`atlas-people.js` 包含街区材质、建筑部件、树木和场景人物。
- `sitting-room.js` 包含客厅、窗扇、火炉和绕树火车。窗外画面由 `scene.js` 通过独立相机实时渲染。
- `fireworks.js` 处理烟花，`music.js` 处理音频选择和播放。其余场景模块保留摄政街长版体验。

## 参考

- 广场云杉和圣诞传统参考伦敦市政府。[Christmas at Trafalgar Square](https://www.london.gov.uk/who-we-are/city-halls-buildings-and-squares/trafalgar-square/christmas)
- Waterloo Place 和 Regent Street 的灯饰参考丽晶街官方介绍。[The Spirit of Christmas](https://www.regentstreetonline.com/news/the-spirit-of-christmas-by-regent-street)
- 倒数日历、邦德街王冠和卡纳比星球取自代表性的过往主题。[Fortnum & Mason](https://www.fortnumandmason.com/stories/christmas-windows-2020) · [Bond Street](https://www.bondstreet.co.uk/articles/the-jewel-in-the-crown-bond-streets-dazzling-new-christmas-lights) · [Carnaby Universe](https://www.shaftesburycapital.com/content/dam/shaftesbury/corporate/Media/Pressreleases/2023/CARNABY%20ANNOUNCES%20BRAND%20NEW%20CHRISTMAS%20INSTALLATION%20CARNABY%20UNIVERSE.pdf)
- 七面钟柱和有顶市集的金铃参考考文特花园官方介绍。莱斯特广场以 Underbelly 的木屋市集和 Spiegeltent 为基础。[Seven Dials](https://www.coventgarden.london/experience/visit/seven-dials) · [Covent Garden 灯饰资料](https://www.coventgarden.london/press-centre/covent-garden-christmas-press-gallery) · [Leicester Square Christmas](https://www.christmasinleicestersquare.co.uk/about)
- 橱窗和街道细节参考伦敦旅游局、牛津街、Selfridges 与 Liberty 的公开资料。Annabel’s 的金色大门和狮子采用过往冬季门面作为灵感。[Visit London](https://www.visitlondon.com/things-to-do/whats-on/christmas/best-christmas-lights-in-london) · [Oxford Street](https://www.oxfordstreet.co.uk/christmas/) · [Selfridges](https://www.selfridges.com/US/en/inspiration/ralph-lauren-holiday/) · [Liberty](https://www.libertylondon.com/uk/features/culture/things-to-do-in-london-over-christmas.html) · [Annabel’s 冬季门面](https://www.countrylife.co.uk/out-and-about/what-on-earth-is-the-person-who-comes-up-with-annabels-otherworldly-facade-displays-on-londons-most-magical-christmas-shop-displays)

## 生成素材

天空 `assets/atlas-sky.webp`、地毯 `assets/sitting-room-rug.webp` 和上一版的威斯敏斯特明信片使用内置 ImageGen 制作。天空和地毯的原始 PNG 随源码附带。

天空提示词

> Wide 2:1 photographic environment matte for an offline WebGL experience of tiny museum-quality London Christmas architectural models. No foreground model. An authentic London winter blue-hour sky after snowfall, layered indigo-blue clouds, soft cold moonlight, faint pink and silver along the low horizon, distant London skyline haze confined to the extreme bottom, tasteful photographic film grain and soft depth. Calm and quiet middle for architecture to be composited in front. No lettering or holiday objects. Photoreal natural lighting with careful shadow and highlight detail.

地毯提示词

> Texture source for a photoreal architectural 3D miniature, top-down flat orthographic product photograph of one antique rectangular British living-room Persian-style wool carpet. Carpet fills the rectangular image edge to edge, all four corners squared, red wine and warm faded cream with charcoal teal arabesques, small scattered floral vines and tightly woven fibers, refined finely drawn border on all four sides. One centered continuous natural design, subtle age wear and rich textile detail. Even soft neutral light, no directional shadows, no floor visible, no perspective distortion or props. Landscape 3:2 texture.


