import * as T from 'three';
import { batch, box, cylinder, mat, random, rounded, slab, texture, tube, v } from './model.js';
import { curb, curve, eastEnd, farCurb, planter, westEnd } from './regent.js';
import { brass, buildTree, gift, greenery, iron, sign, snow } from './architecture.js';

const rng = random(912);
const pick = list => list[Math.floor(rng() * list.length)];
const base = mat('#49382f');
const bevel = mat('#a49a8a');
const granite = ['#a5a19b', '#b6aba1', '#bcb5a8', '#a6aaa8', '#b1aca4'].map(c => mat(c));
const snowShade = mat('#ced9df');
const wood = ['#67412d', '#7c4b31', '#905c3a'].map(c => mat(c));
const pillarRed = mat('#a32532');
const bottle = mat('#244b3d');

function patchedSnow(draw, x, z, w, d, y = .083) {
  const outline = Array.from({ length: 13 }, (_, i) => {
    const a = i * Math.PI * 2 / 13, r = .75 + rng() * .26;
    return [x + Math.cos(a) * w * r, z + Math.sin(a) * d * r];
  });
  slab(draw, rng() < .2 ? snowShade : snow, outline, y, .017 + rng() * .018, .014, false);
}


function ground(draw) {
  const outline = (back, front) => {
    const xs = Array.from({ length: 61 }, (_, i) => westEnd + i * (eastEnd - westEnd) / 60);
    return [
      ...xs.map(x => [x, back + curve(x)]),
      ...xs.reverse().map(x => [x, front(x) + curve(x)]),
    ];
  };
  const nearEdge = x => 9.53 + 2.45 * (1 - T.MathUtils.smoothstep(x, -9.0, -7.4))
    - 2.03 * (1 - T.MathUtils.smoothstep(x, -21.6, -18.10));
  const footprint = outline(-4.30, nearEdge);
  slab(draw, base, footprint, -.53, .46, .062);
  slab(draw, bevel, footprint, -.143, .115, .048);

  const roadway = mat('#fff', {
    map: texture(1280, 512, (ctx, w, h) => {
      ctx.fillStyle = '#343c47';
      ctx.fillRect(0, 0, w, h);
      const tones = ['#4e5360', '#505761', '#59616b', '#575d67', '#515661', '#5f626a'];
      for (let row = 0; row < 20; row++) {
        const y = row * 26;
        for (let col = -1; col < 100; col++) {
          const x = col * 13 + row % 2 * 6;
          ctx.fillStyle = pick(tones);
          ctx.beginPath();
          ctx.roundRect(x + 1, y + 1.9, 11.65, 23.5, 2.0);
          ctx.fill();
          ctx.fillStyle = '#bfc9e229';
          ctx.fillRect(x + 2.1, y + 2, 8.8, 2);
        }
      }
      for (let i = 0; i < 21000; i++) {
        ctx.fillStyle = pick(['#ffffff0d', '#0e1b2239', '#c7b3a826', '#b9c6d228']);
        ctx.fillRect(rng() * w, rng() * h, 1 + rng() * 3, 1 + rng() * 2);
      }
    }),
    roughness: .51,
  });
  const road = new T.Shape(outline(curb, () => farCurb).map(([x, z]) => new T.Vector2(x, -z)));
  const surface = new T.ShapeGeometry(road);
  const uv = surface.attributes.uv;
  for (let i = 0; i < uv.count; i++) {
    const x = uv.getX(i);
    uv.setXY(i, (x - westEnd) / (eastEnd - westEnd), (-uv.getY(i) - curb - curve(x)) / (farCurb - curb));
  }
  surface.rotateX(-Math.PI / 2);
  draw.add(surface, roadway, 0, .039, 0, 0, false);

  function pave(from, to) {
    for (let row = 0; from + (row + .5) * .526 < to; row++) {
      const z = from + (row + .5) * .526;
      for (let x = westEnd + .365 + (row % 2) * .165; x < eastEnd - .25; x += .725) {
        if (z > nearEdge(x) - .21) continue;
        const yaw = Math.atan(.047 * Math.min(x + 5.48, 0));
        box(draw, pick(granite), x, .038 + rng() * .009, z + curve(x), .710, .089, .510, yaw, false);
      }
    }
  }
  pave(-4.26, curb - .08);
  pave(farCurb + .10, 11.95);
  const paint = mat('#e8c794');
  const lane = mat('#c1b6a5');
  for (let i = 0; westEnd + .32 + i * .595 < eastEnd - .14; i++) {
    const x = westEnd + .32 + i * .595;
    const dz = curve(x);
    const yaw = Math.atan(.047 * Math.min(x + 5.48, 0));
    for (const z of [curb, farCurb]) {
      box(draw, pick(granite), x, .051, z + dz, .582, .152, .27, yaw);
      if (i % 2 === 0) {
        box(draw, paint, x, .042, z + dz + (z === curb ? .29 : -.29), 1.12, .005, .036, yaw, false);
      }
    }
    if (i % 3 === 0) box(draw, lane, x, .042, (curb + farCurb) / 2 + dz, .94, .004, .049, yaw, false);
  }
  for (let i = 0; i < 134; i++) {
    const x = westEnd + .31 + rng() * (eastEnd - westEnd - .55);
    const z = (rng() > .26 ? .54 + rng() * 2.20 : farCurb + .21 + rng() * 1.7) + curve(x);
    patchedSnow(draw, x, z, .056 + rng() ** 2 * .32, .037 + rng() ** 2 * .145);
  }
  for (let i = 0; westEnd + .38 + i * .416 < eastEnd - .22; i++) {
    const x = westEnd + .38 + i * .416;
    patchedSnow(draw, x, curb + curve(x) + rng() * .09, .093 + rng() * .15, .046 + rng() * .064, .126);
  }
  for (const x of [-15.21, -12.95, -8.22, -6.75, -6.18, 8.35, 9.43]) {
    const z = curb + curve(x) - .20;
    cylinder(draw, iron, x, .32, z, .055, .076, .49, 9);
    draw.add(new T.SphereGeometry(.068, 9, 6), iron, x, .59, z);
    cylinder(draw, brass, x, .493, z, .059, .059, .048, 10);
  }
}

function bench(draw, x, z) {
  for (const end of [-.94, .94]) {
    const a = x + end;
    for (const b of [-.245, .23]) {
      tube(draw, iron, [v(a, .105, z + b * 1.12), v(a, .27, z + b * .9),
        v(a, .54, z + b)], .048, true, 8, true);
      box(draw, iron, a, .106, z + b, .18, .044, .18);
    }
    tube(draw, iron, [v(a, .46, z - .21), v(a, .77, z - .34), v(a, 1.10, z - .40)], .042, true, 8, true);
    tube(draw, iron, [v(a, .49, z + .24), v(a, .75, z + .22), v(a, .79, z - .10),
      v(a, .79, z - .34)], .038, true, 8, true);
  }
  for (let i = 0; i < 5; i++) box(draw, wood[i % 3], x, .553, z - .25 + .118 * i, 2.16, .055, .102);
  for (let i = 0; i < 4; i++) {
    const y = .70 + i * .108, zz = z - .295 - i * .025;
    box(draw, wood[(i + 1) % 3], x, y, zz, 2.16, .084, .053);
    for (const side of [-.94, .94]) {
      draw.add(new T.SphereGeometry(.021, 6, 5), brass, x + side, y, zz + .033);
    }
  }
  box(draw, brass, x, .919, z - .209, .32, .061, .018);
  for (let i = 0; i < 7; i++) patchedSnow(draw, x - 1.01 + i * .13, z - .22, .11, .046, .579);
  return new T.Box3(v(x - 1.09, .09, z - .41), v(x + 1.09, 1.05, z + .27));
}

function lamp(draw, x, z, bulb) {
  for (const [y, r, h] of [[.14, .226, .18], [.28, .157, .20], [.45, .112, .26], [.65, .082, .12],
    [2.10, .049, 2.89], [3.55, .12, .15], [3.67, .21, .11]]) {
    cylinder(draw, iron, x, y, z, r * .85, r, h, 8);
  }
  cylinder(draw, bulb, x, 3.96, z, .255, .162, .52, 4);
  cylinder(draw, iron, x, 4.25, z, .083, .30, .21, 4);
  draw.add(new T.SphereGeometry(.079, 8, 6), brass, x, 4.39, z);
  for (let i = 0; i < 4; i++) {
    const a = i * Math.PI / 2;
    tube(draw, iron, [v(x + Math.sin(a) * .163, 3.68, z + Math.cos(a) * .163),
      v(x + Math.sin(a) * .263, 4.20, z + Math.cos(a) * .263)], .022, false, 6, true);
  }
  greenery(draw, x, 2.75, z + .08, .25, .25, 38);
  box(draw, pillarRed, x, 2.50, z + .16, .14, .08, .035);
}

function postBox(draw, x, z) {
  for (const [y, r, h, m] of [[.19, .252, .23, iron], [.64, .230, .91, pillarRed], [1.09, .254, .075, pillarRed],
    [1.16, .22, .072, pillarRed]]) cylinder(draw, m, x, y, z, r, r, h, 22);
  box(draw, iron, x, .927, z + .229, .21, .052, .026);
  sign(draw, x, .742, z + .241, .154, .13, 'POST', { background: '#f0ddc8', colour: '#54262d' });
  draw.add(new T.SphereGeometry(1, 12, 5).scale(.187, .029, .173), snow, x - .012, 1.205, z);
}

function nutcracker(draw, x, z) {
  const uniform = mat('#a72c38'), black = mat('#26252a'), skin = mat('#dba884');
  const white = mat('#eee5d3'), blue = mat('#32495a');
  cylinder(draw, bottle, x, .11, z, .28, .34, .11);
  for (const dx of [-.105, .105]) {
    box(draw, black, x + dx, .215, z + .053, .155, .12, .255);
    box(draw, blue, x + dx, .405, z, .145, .34, .15);
    box(draw, brass, x + dx, .43, z + .084, .019, .28, .013);
  }
  box(draw, uniform, x, .77, z, .40, .39, .248);
  box(draw, black, x, .628, z + .012, .416, .056, .259);
  box(draw, brass, x, .628, z + .15, .093, .074, .024);
  for (const dx of [-.245, .245]) {
    cylinder(draw, uniform, x + dx, .76, z, .067, .050, .30, 8);
    box(draw, brass, x + dx, .917, z, .156, .056, .21);
    draw.add(new T.SphereGeometry(.062, 8, 5), white, x + dx, .603, z);
  }
  for (const y of [.735, .80, .865]) box(draw, brass, x, y, z + .133, .226, .025, .018);
  cylinder(draw, skin, x, 1.094, z, .154, .139, .257, 12);
  box(draw, white, x, .984, z + .12, .174, .118, .067);
  for (const dx of [-.056, .056]) box(draw, black, x + dx, 1.132, z + .146, .026, .022, .018);
  box(draw, skin, x, 1.075, z + .151, .045, .041, .07);
  box(draw, black, x, 1.035, z + .16, .111, .026, .026);
  cylinder(draw, black, x, 1.353, z, .161, .159, .289, 14);
  cylinder(draw, brass, x, 1.231, z, .169, .174, .037, 14);
  draw.add(new T.SphereGeometry(.061, 8, 5), uniform, x, 1.42, z + .162);
}

function journalRack(draw, x, z, covers) {
  for (const side of [-.33, .33]) {
    tube(draw, iron, [v(x + side, .07, z + .27), v(x + side, 1.15, z - .05)], .030, false, 7, true);
    tube(draw, iron, [v(x + side, .07, z - .32), v(x + side, 1.15, z - .05)], .030, false, 7, true);
  }
  box(draw, bottle, x, .69, z + .076, .76, .75, .063);
  box(draw, brass, x, .34, z + .143, .83, .052, .16);
  for (let i = 0; i < 2; i++) {
    const material = mat('#fff', { map: covers[i] });
    draw.add(new T.PlaneGeometry(.31, .447), material, x + (i - .5) * .345, .65 + i * .055, z + .115, 0, false, 0, (i - .5) * .12);
  }
  sign(draw, x, 1.105, z + .012, .81, .17, 'FIELD EDITIONS');
  return new T.Box3(v(x - .41, .07, z - .15), v(x + .41, 1.2, z + .24));
}

function railings(draw, left, right, z) {
  for (const y of [.29, .77]) box(draw, iron, (left + right) / 2, y, z, right - left, .036, .035);
  const count = Math.round((right - left) / .18);
  for (let i = 0; i <= count; i++) {
    const x = left + (right - left) * i / count;
    cylinder(draw, iron, x, .463, z, .019, .023, .793, 6);
    draw.add(new T.OctahedronGeometry(.044).scale(.64, 1.30, .64), i % 5 ? iron : brass, x, .884, z);
  }
}


export function busGlassFinish(windscreen = false) {
  const map = texture(256, 256, (ctx, w, h) => {
    const base = ctx.createLinearGradient(0, 0, w, h);
    base.addColorStop(0, '#7b8eab');
    base.addColorStop(.38, '#43586c');
    base.addColorStop(1, '#282c43');
    ctx.fillStyle = base;
    ctx.fillRect(0, 0, w, h);
    const shine = ctx.createLinearGradient(0, 0, w, h * .35);
    shine.addColorStop(0, '#e4d7cc02');
    shine.addColorStop(.48, '#d7e7f383');
    shine.addColorStop(1, '#f4a88514');
    ctx.fillStyle = shine;
    ctx.beginPath();
    ctx.moveTo(0, 9); ctx.lineTo(53, 0); ctx.lineTo(w, 130);
    ctx.lineTo(w, 165); ctx.lineTo(185, 153); ctx.closePath(); ctx.fill();
    ctx.fillStyle = '#fef2db41';
    for (let i = 0; i < 3; i++) ctx.fillRect(w * .17 + i * 47, 12 + i * 3, 25, 2);
  });
  const emissiveMap = texture(256, 256, (ctx, w, h) => {
    const cabin = ctx.createLinearGradient(0, 0, 0, h);
    cabin.addColorStop(0, '#a38978'); cabin.addColorStop(.18, '#b39c86');
    cabin.addColorStop(.47, '#6d5965'); cabin.addColorStop(.77, '#46323a'); cabin.addColorStop(1, '#292532');
    ctx.fillStyle = cabin; ctx.fillRect(0, 0, w, h);
    const aisle = ctx.createRadialGradient(w * .51, h * .55, 9, w * .51, h * .55, w * .55);
    aisle.addColorStop(0, '#dabc8d9c'); aisle.addColorStop(1, '#bc8b5500');
    ctx.fillStyle = aisle; ctx.fillRect(0, 0, w, h);
    ctx.fillStyle = '#dbbd9e';
    ctx.fillRect(0, 26, w, windscreen ? 8 : 5);
    ctx.fillStyle = '#f7ddae';
    ctx.fillRect(18, 28, w - 36, 3);
    if (windscreen) {
      ctx.strokeStyle = '#e1b57e'; ctx.lineWidth = 3;
      for (const dx of [37, 219]) {
        ctx.beginPath(); ctx.moveTo(dx, h - 10);
        ctx.quadraticCurveTo(dx - 7, h * .38, w / 2 + (dx - w / 2) * .69, 36); ctx.stroke();
      }
      ctx.fillStyle = '#4b3541';
      ctx.beginPath(); ctx.roundRect(32, 156, 66, 111, [12, 12, 0, 0]); ctx.fill();
      ctx.fillStyle = '#5b3d4c';
      ctx.beginPath(); ctx.roundRect(166, 146, 65, 116, [10, 10, 0, 0]); ctx.fill();
      ctx.fillStyle = '#5b484e';
      ctx.beginPath(); ctx.ellipse(176, 120, 20, 24, -.10, 0, Math.PI * 2); ctx.fill();
      ctx.fillStyle = '#7b5955';
      ctx.beginPath(); ctx.ellipse(179, 124, 15, 16, -.07, 0, Math.PI * 2); ctx.fill();
      ctx.fillStyle = '#452e3b';
      ctx.beginPath(); ctx.roundRect(151, 111, 50, 13, 4); ctx.fill();
    } else {
      ctx.fillStyle = '#5c384c';
      for (const x of [26, 143]) {
        ctx.beginPath(); ctx.roundRect(x, 163, 82, 103, [14, 14, 0, 0]); ctx.fill();
        ctx.fillStyle = '#82616a'; ctx.fillRect(x + 8, 175, 65, 4); ctx.fillStyle = '#5c384c';
      }
      ctx.fillStyle = '#d4a16d'; ctx.fillRect(117, 39, 4, h - 39);
    }
    ctx.strokeStyle = '#f7d1a04d'; ctx.lineWidth = 2;
    ctx.beginPath(); ctx.moveTo(0, 61); ctx.lineTo(w, 143); ctx.stroke();
  });
  return new T.MeshPhysicalMaterial({
    color: '#e4deee', map, emissiveMap, emissive: '#ffe4bc', emissiveIntensity: 0,
    metalness: .35, roughness: .22, clearcoat: .86, clearcoatRoughness: .18, envMapIntensity: 1.23,
  });
}

function bus(draw, [glass, windscreen], headlamp, trim) {
  const red = new T.MeshPhysicalMaterial({ color: '#b62236', roughness: .285, metalness: .23, clearcoat: .83, clearcoatRoughness: .19 });
  const redLight = new T.MeshPhysicalMaterial({ color: '#ce3041', roughness: .25, metalness: .19, clearcoat: .95, clearcoatRoughness: .15 });
  const stripe = mat('#ebd4a4');
  const black = mat('#28272a');
  const chrome = mat('#dbe0db', { metalness: .77, roughness: .21 });
  const center = 3.49, z = 4.28, length = 6.00, width = 1.97;
  const left = center - length / 2, right = center + length / 2, near = z + width / 2, far = z - width / 2;
  const outline = rounded(left, right, far, near, [.30, .36, .34, .30], 8);
  slab(draw, black, rounded(left + .12, right - .08, far + .08, near - .08, [.24, .26, .26, .24]), .38, .36, .04);
  slab(draw, red, outline, .70, 1.37, .045);
  slab(draw, redLight, outline, 2.04, 1.36, .051);
  slab(draw, redLight, rounded(left + .032, right - .033, far + .041, near - .041, [.33, .39, .34, .30]),
    3.35, .13, .074);
  slab(draw, stripe, outline, 2.02, .075, .023);
  for (const face of [-1, 1]) {
    const side = z + face * (width / 2 + .051), yaw = face > 0 ? 0 : Math.PI;
    for (const [y, h] of [[1.60, .69], [2.81, .70]]) {
      for (let i = 0; i < 7; i++) {
        const x = left + .58 + .805 * i;
        box(draw, black, x, y, side, .736, h + .072, .022, yaw);
        draw.add(new T.PlaneGeometry(.678, h), glass, x, y, side + face * .015, yaw, false);
        box(draw, redLight, x, y + .061, side + face * .022, .69, .023, .017);
        box(draw, chrome, x, y - h / 2 - .03, side + face * .025, .74, .027, .024);
      }
    }
    for (const dx of [left + 1.09, right - 1.20]) {
      draw.add(new T.CylinderGeometry(.515, .515, .255, 24), black, dx, .515, side - face * .043, 0, true, Math.PI / 2);
      draw.add(new T.CylinderGeometry(.268, .268, .039, 16), chrome, dx, .515, side + face * .095, 0, true, Math.PI / 2);
      draw.add(new T.CylinderGeometry(.137, .137, .045, 16), red, dx, .515, side + face * .124, 0, true, Math.PI / 2);
    }
    sign(draw, center - .11, 1.015, side + face * .022, 2.30, .30, 'LONDON TRANSPORT',
      { background: '#8b1c28', colour: '#f4d59b', serif: false, yaw });
    sign(draw, left + .62, 1.03, side + face * .023, .38, .24, '94',
      { background: '#272527', colour: '#f5ead0', serif: false, yaw });
  }
  const head = right + .055;
  for (const [y, h] of [[1.58, .65], [2.79, .70]]) for (const dz of [-.426, .426]) {
    box(draw, black, head, y, z + dz, .035, h + .09, .78);
    draw.add(new T.PlaneGeometry(.72, h), windscreen, head + .026, y, z + dz, Math.PI / 2, false);
  }
  sign(draw, head + .04, 2.24, z, 1.51, .26, '94  ·  ACTON GREEN',
    { background: '#252525', colour: '#f5dfad', serif: false, yaw: Math.PI / 2 });
  box(draw, black, head + .08, .939, z, .07, .415, .64);
  for (let i = 0; i < 7; i++) box(draw, chrome, head + .123, .780 + i * .052, z, .025, .013, .55);
  box(draw, chrome, head + .094, .49, z, .12, .09, 1.60);
  for (const dz of [-.71, .71]) {
    const geo = new T.CylinderGeometry(.113, .113, .062, 16);
    draw.add(geo, headlamp, head + .048, .915, z + dz, 0, false, 0, Math.PI / 2);
  }

  const tail = left - .058;
  for (const [y, h] of [[1.66, .63], [2.79, .67]]) {
    box(draw, black, tail, y, z, .035, h + .08, 1.47);
    draw.add(new T.PlaneGeometry(1.38, h), windscreen, tail - .025, y, z, -Math.PI / 2, false);
    box(draw, redLight, tail - .034, y, z, .026, h + .048, .044);
    tube(draw, trim, [v(tail - .039, y - h * .53, z - .78), v(tail - .039, y - h * .53, z + .78),
      v(tail - .039, y + h * .53, z + .78), v(tail - .039, y + h * .53, z - .78),
      v(tail - .039, y - h * .53, z - .78)], .014, true, 6);
  }
  const rearLamp = mat('#bd313e', { emissive: '#f62a32', emissiveIntensity: .88, roughness: .25 });
  for (const dz of [-.71, .71]) {
    box(draw, rearLamp, tail - .020, .82, z + dz, .039, .164, .116);
    box(draw, stripe, tail - .020, 1.014, z + dz, .039, .043, .113);
  }
  box(draw, chrome, tail - .04, .506, z, .101, .072, 1.60);
  sign(draw, tail - .07, .66, z, .29, .095, 'RM 2194', { background: '#d9b379', colour: '#4c3736', yaw: -Math.PI / 2 });
  sign(draw, left - .040, 2.28, z, 1.17, .27, '94  ·  REGENT ST.',
    { background: '#252525', colour: '#f5dfad', serif: false, yaw: -Math.PI / 2 });
  for (const [dx, dz, w, d] of [[-1.75, -.47, .55, .19], [-1.40, -.51, .37, .14],
    [-.19, -.63, .52, .12], [.38, -.59, .28, .16], [1.83, -.60, .64, .15], [2.32, -.54, .37, .13]]) {
    patchedSnow(draw, center + dx, z + dz, w, d, 3.551);
  }

  for (const face of [-1, 1]) {
    const zSide = z + face * (width / 2 + .083);
    for (const y of [.766, 2.118, 3.295]) {
      tube(draw, trim, [v(left + .24, y, zSide), v(right - .23, y, zSide)], .018, false, 6);
    }
    tube(draw, chrome, [v(right + .021, 1.60, z + face * .79), v(right + .153, 1.73, z + face * 1.02),
      v(right + .129, 1.91, z + face * 1.12)], .022, true, 7);
    box(draw, chrome, right + .11, 1.88, z + face * 1.115, .122, .15, .048);
    box(draw, black, right + .070, 1.881, z + face * 1.123, .045, .117, .040);
    box(draw, headlamp, right + .074, 1.136, z + face * .824, .030, .052, .086);
  }
  for (const [y, h] of [[1.58, .70], [2.80, .74]]) {
    const x = head + .067;
    tube(draw, trim, [v(x, y - h / 2, z - .85), v(x, y - h / 2, z + .85),
      v(x, y + h / 2, z + .85), v(x, y + h / 2, z - .85), v(x, y - h / 2, z - .85)], .017, true, 7);
    tube(draw, chrome, [v(x + .011, y - h * .34, z + .06), v(x + .013, y + h * .06, z + .56)], .015, false, 6);
  }
  box(draw, black, head + .153, .611, z, .037, .107, .36);
  sign(draw, head + .174, .611, z, .33, .08, 'RM 2194', { background: '#302830', colour: '#ffeece', yaw: Math.PI / 2 });
  return new T.Box3(v(left, .05, far), v(right + .13, 3.59, near));
}

function lightPool(parent, x, z, w, d, tint, y) {
  const map = texture(96, 96, (ctx, width, height) => {
    const fade = ctx.createRadialGradient(48, 48, 0, 48, 48, 48);
    fade.addColorStop(0, '#fff9');
    fade.addColorStop(.31, '#fff5');
    fade.addColorStop(1, '#fff0');
    ctx.fillStyle = fade;
    ctx.fillRect(0, 0, width, height);
  });
  const material = new T.MeshBasicMaterial({ map, color: tint, transparent: true, depthWrite: false, blending: T.AdditiveBlending });
  const mesh = new T.Mesh(new T.PlaneGeometry(w, d), material);
  mesh.rotation.x = -Math.PI / 2;
  mesh.position.set(x, y, z);
  parent.add(mesh);
  return material;
}

export function buildStreet(parent, draw, glass, bulbs, covers) {
  ground(draw);
  const lampGlass = mat('#d4af78', { emissive: '#ffb15a', emissiveIntensity: 0 });
  const headlamp = mat('#e4d2a7', { emissive: '#ffcc82', emissiveIntensity: 0 });
  const benchBounds = bench(draw, -3.29, 2.11);
  lamp(draw, -4.68, 2.16, lampGlass);
  buildTree(draw, -6.02, .93, bulbs);
  postBox(draw, 1.32, 2.44);
  nutcracker(draw, .61, 1.30);
  const rackBounds = journalRack(draw, -.94, 2.27, covers);

  const busTrim = mat('#efd0a1', { emissive: '#ffb86c', emissiveIntensity: .1, metalness: .25, roughness: .27 });
  const vehicles = [[4.82, 4.31, 0, .86], [-9.35, 6.26 + curve(-9.35), Math.PI - .18, .76]];
  const busBounds = vehicles.map(([x, z, yaw, scale]) => {
    const vehicle = new T.Group();
    const body = batch(vehicle);
    const bounds = bus(body, glass, headlamp, busTrim);
    body.finish();
    vehicle.scale.setScalar(scale);
    vehicle.rotation.y = yaw;
    const center = v(3.49, 0, 4.28).multiplyScalar(scale).applyAxisAngle(v(0, 1, 0), yaw);
    vehicle.position.set(x - center.x, .014, z - center.z);
    vehicle.updateMatrix();
    parent.add(vehicle);
    return bounds.applyMatrix4(vehicle.matrix);
  });
  for (const x of [-14.92, -11.66, -8.59, 6.3, 8.83, 9.30]) planter(draw, x, .98 + curve(x), .72 + rng() * .22);
  for (const [x, z] of [[-9.04, 2.53 + curve(-9.04)], [9.29, 8.19]]) lamp(draw, x, z, lampGlass);

  railings(draw, -5.23, -3.38, .97);
  railings(draw, 1.22, 1.67, .92);
  railings(draw, 5.77, 6.78, .83);
  const cream = mat('#e1d0b0');
  for (const [x, z] of [[4.98, 1.13], [5.40, 1.12], [2.11, 1.46]]) {
    gift(draw, x, .085, z, .24 + rng() * .18, pick([pillarRed, bottle, cream]), rng());
  }
  sign(draw, 1.70, 2.23, .48, .51, .26, 'NOËL', { background: '#712e38', yaw: .27 });
  const lights = [
    [-4.68, 3.71, 2.16, '#ffb367', 4.6, 18],
    [.26, 1.69, .81, '#ffae5d', 4.1, 12],
    [-6.02, 1.72, 1.20, '#ffb16f', 3.1, 4],
    [-3.94, 1.65, .95, '#ffc381', 3.2, 5],
    [7.48, .82, 4.30, '#ffc585', 3.3, 12],
    [-9.04, 3.65, 2.25 + curve(-9.04), '#ffc78f', 5.5, 14],
    [9.29, 3.60, 8.19, '#ffbb83', 5.2, 13],
  ].map(([x, y, z, colour, reach, power]) => {
    const light = new T.PointLight(colour, 0, reach, 2);
    light.position.set(x, y, z);
    parent.add(light);
    return { light, power };
  });
  const pools = [
    lightPool(parent, -4.65, 2.18, 3.65, 2.2, '#ffb76d', .139),
    lightPool(parent, .26, .99, 3.20, 1.6, '#ffab55', .113),
    lightPool(parent, 7.86, 4.31, 3.55, 2.25, '#ffc982', .044),
    lightPool(parent, -9.04, 2.29 + curve(-9.04), 3.17, 2.07, '#ffb05e', .140),
    lightPool(parent, 9.27, 8.23, 2.41, 2.20, '#ffc05f', .139),
  ];
  return { benchBounds, rackBounds, busBounds, lampGlass, headlamp, busTrim, lights, pools };
}
