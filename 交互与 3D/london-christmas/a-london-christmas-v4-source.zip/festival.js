import * as T from 'three';
import { curve } from './regent.js';
import { brass, iron } from './architecture.js';
import { cylinder, mat, random, tube, v } from './model.js';

const gold = '#ffd697';
const ruby = '#ff7166';
const ice = '#b8e3fa';

export function buildFestival(parent, draw, walls, decorations) {
  const rng = random(2411);
  const wire = mat('#957443', { metalness: .36, roughness: .46 });
  const foliage = ['#1c4539', '#285847', '#42664d'].map(colour => mat(colour));
  const velvet = mat('#9e263e', { roughness: .72 });
  const ornament = [mat('#9b2541', { metalness: .25, roughness: .24 }), brass, mat('#bdd3d8', { metalness: .34, roughness: .32 })];
  const glows = [];
  const bulbs = new Map([gold, ruby, ice].map(colour => [
    colour, mat(colour, { emissive: colour, emissiveIntensity: 0, roughness: .38 }),
  ]));

  function light(point, colour = gold, radius = .17, globe = .025) {
    const { x, y, z } = point;
    draw.add(new T.SphereGeometry(globe, 6, 4), bulbs.get(colour), x, y, z, 0, false);
    glows.push({ point, colour, radius });
  }

  function lightString(points, { spacing = .13, colour = gold, radius = .15, gauge = .009, material = wire } = {}) {
    tube(draw, material, points, gauge);
    const curve = new T.CatmullRomCurve3(points);
    const count = Math.max(2, Math.round(curve.getLength() / spacing));
    for (let i = 0; i <= count; i++) light(curve.getPointAt(i / count), colour, radius, spacing < .09 ? .019 : .024);
  }


  function angel(x, height, scale) {
    const middle = 5.1 + curve(x);
    const origin = v(x, height, middle);
    const shape = (coords, side = 1) => coords.map(([across, y, depth = 0]) =>
      v(depth, y, -side * across).multiplyScalar(scale).add(origin));
    const line = (coords, side = 1) => lightString(shape(coords, side), { spacing: .071, radius: .158 });
    for (const side of [-1, 1]) {
      // The outline and curved ribs follow the wire feathers of a street-light sculpture.
      line([[.12, .47], [.48, .59, .02], [1.13, 1.09, .14], [1.93, 1.47, .21],
        [2.65, 1.62, .17], [3.48, 1.60, .04]], side);
      for (let feather = 0; feather < 9; feather++) {
        const t = feather / 8, end = 3.47 - 2.36 * t;
        const tip = 1.60 - 1.56 * t;
        line([[.17 + t * .08, .43 - t * .15], [.59 + .21 * t, .52 - t * .10, .05],
          [end * .58, tip * .81 - .02, .13], [end * .84, tip - .12, .16],
          [end, tip, .055]], side);
      }
      line([[.17, .37], [.36, .05, .10], [.64, -.03, .13], [1.11, .04, .055]], side);
      line([[.12, .41], [.27, .15, .10], [.13, -.14, .18], [.22, -.51, .19],
        [.43, -.92, .09], [.48, -1.17, -.02]], side);
      for (const offset of [.04, .08, .12]) {
        line([[offset, .32, .10], [offset * .68, .02, .23], [offset, -.34, .27],
          [offset * 1.85, -.72, .24], [offset * 3.0, -1.19, .035]], side);
      }
    }
    line([[-.48, -1.17, -.02], [-.26, -1.25, .08], [0, -1.27, .17], [.26, -1.25, .08], [.48, -1.17, -.02]]);
    const ring = (y, rx, ry, z) => Array.from({ length: 19 }, (_, i) => {
      const angle = i / 18 * 2 * Math.PI;
      return [Math.cos(angle) * rx, y + Math.sin(angle) * ry, z];
    });
    line(ring(.65, .13, .18, .087));
    line(ring(.91, .23, .073, .055));
    line([[.10, .56, .09], [.26, .52, .24], [.45, .65, .24], [.66, .75, .09]]);
    line([[.18, .35], [.43, .43, .22], [.52, .69, .18], [.80, .81, .07], [.94, .87, .06]]);
    line([[.84, .81, .06], [.98, .77, .06], [1.05, .89, .08], [1.00, 1.00, .08], [.84, .81, .06]]);

    for (const side of [-1, 1]) {
      const anchorZ = middle + side * (side < 0 ? 4.94 : 4.26);
      const tipZ = middle + side * 3.48 * scale;
      tube(draw, iron, [v(x - .19, height + 1.75, anchorZ), v(x - .13, height + 1.62, (anchorZ + tipZ) / 2),
        v(x, height + 1.60 * scale, tipZ)], .008);
      for (let row = 0; row < 5; row++) {
        const offset = row * .11;
        lightString([v(x + .34 + offset, height - .29 - offset * .48, middle + side * .34),
          v(x + .40 + offset, height - 1.42 - offset * .77, middle + side * 1.71),
          v(x + .34 + offset, height - 1.06 - offset * .55, middle + side * 3.03),
          v(x + .28 + offset, height + .37 + offset * .13, anchorZ)],
        { spacing: .15, colour: row === 0 || row === 4 ? gold : ice, radius: .16, gauge: .005 });
      }
    }
  }

  function ribbon(x, y, z, size) {
    for (const side of [-1, 1]) {
      const geo = new T.SphereGeometry(1, 12, 8).scale(size * .48, size * .22, size * .16);
      draw.add(geo, velvet, x + side * size * .34, y, z, 0, false, 0, side * .32);
      const tail = new T.Shape([new T.Vector2(-.12, 0), new T.Vector2(.12, 0),
        new T.Vector2(.18, -.72), new T.Vector2(.04, -.62), new T.Vector2(-.09, -.75)]);
      draw.add(new T.ExtrudeGeometry(tail, { depth: .028, bevelEnabled: false }).scale(size, size, size), velvet,
        x + side * size * .09, y - size * .06, z - .021, 0, false, .1, side * .24);
    }
    draw.add(new T.SphereGeometry(size * .23, 10, 7).scale(.84, 1, .7), velvet, x, y, z + .035);
  }

  function garland(left, right, y, z, sag, knots) {
    const pointAt = t => v(T.MathUtils.lerp(left, right, t), y - Math.sin(t * Math.PI) * sag, z);
    const points = Array.from({ length: 17 }, (_, i) => pointAt(i / 16));
    tube(draw, foliage[0], points, .070, true, 8);
    const count = Math.round((right - left) * 57);
    for (let i = 0; i <= count; i++) {
      const p = pointAt(i / count), a = i * 2.39996;
      const geo = new T.SphereGeometry(1, 5, 3).scale(.118 + rng() * .069, .025, .021);
      draw.add(geo, foliage[i % 3], p.x, p.y + Math.sin(a) * .092, p.z + Math.cos(a) * .094,
        a, false, a * .23, a * .67);
      if (i % 5 === 0) light(v(p.x, p.y + Math.sin(a) * .09, p.z + .092), i % 25 === 0 ? ruby : gold, .19);
      if (i % 17 === 0) {
        draw.add(new T.SphereGeometry(.067, 10, 8), ornament[i % 3], p.x, p.y - .105, p.z + .053);
      }
    }
    for (const t of knots) {
      const { x, y: by } = pointAt(t);
      ribbon(x, by + .04, z + .105, .32);
    }
  }

  function bell(x, y, z, size, tilt) {
    const profile = [[.09, .34], [.17, .30], [.21, .15], [.22, -.05], [.28, -.16], [.34, -.23],
      [.33, -.28], [.285, -.28], [.262, -.22], [.20, -.11], [.177, .13], [.13, .27]]
      .map(([r, h]) => new T.Vector2(r * size, h * size));
    draw.add(new T.LatheGeometry(profile, 20), brass, x, y, z, 0, true, 0, tilt);
    draw.add(new T.SphereGeometry(.075 * size, 10, 6), brass, x + tilt * size * .32, y - size * .28, z, 0, false);
  }

  function facade() {
    for (const [index, wall] of walls.entries()) {
      const { min, max } = wall;
      const z = max.z + .172;
      lightString([v(min.x + .075, max.y - .025, z), v((min.x + max.x) / 2, max.y - .04, z),
        v(max.x - .075, max.y - .025, z)], { spacing: .137, radius: .14 });
      for (const x of [min.x + .074, max.x - .074]) {
        lightString([v(x, max.y - .04, z), v(x, 4.48, z), v(x, 3.15, z)],
          { spacing: .161, radius: .13, gauge: .006 });
      }
      if (index === 1) garland(min.x + .18, max.x - .20, 2.75, max.z + .52, .14, [.07, .53, .94]);
      else garland(min.x + .22, max.x - .22, 3.10, max.z + .94, .14, [.22, .79]);
    }
    bell(.93, 2.76, .92, .68, -.31);
    bell(1.31, 2.74, .93, .74, .24);
    ribbon(1.12, 3.02, .96, .50);

    const left = walls[0].min.x - .106;
    const side = walls[0].max.y - .025;
    lightString([v(left, side, walls[0].min.z), v(left, side, -1.30), v(left, side, walls[0].max.z)],
      { spacing: .15, radius: .13 });
  }

  function treeLights() {
    const x = -6.02, z = .93;
    for (let i = 0; i < 92; i++) {
      const t = i / 92;
      const angle = i * 2.39996;
      const radius = 1.20 * (1 - t) ** .82 + .035;
      const p = v(x + Math.sin(angle) * radius, .70 + t * 3.05, z + Math.cos(angle) * radius);
      const colour = i % 8 === 0 ? ruby : i % 7 === 0 ? ice : gold;
      light(p, colour, .23, .029);
    }
    light(v(x, 4.03, z + .062), gold, .69, .063);
    light(v(-4.68, 3.96, 2.24), gold, .98, .035);
  }

  angel(1.30, 6.23, 1.02);
  angel(-5.68, 6.04, .91);
  angel(-11.55, 5.89, .86);
  for (const { point, colour, radius } of decorations) light(point, colour, radius, .022);
  facade();
  treeLights();

  const geometry = new T.BufferGeometry();
  const positions = [], colours = [], radii = [], phases = [];
  for (const { point, colour, radius } of glows) {
    positions.push(...point.toArray());
    colours.push(...new T.Color(colour).toArray());
    radii.push(radius);
    phases.push(rng() * 37);
  }
  geometry.setAttribute('position', new T.Float32BufferAttribute(positions, 3));
  geometry.setAttribute('tint', new T.Float32BufferAttribute(colours, 3));
  geometry.setAttribute('radius', new T.Float32BufferAttribute(radii, 1));
  geometry.setAttribute('phase', new T.Float32BufferAttribute(phases, 1));
  const uniforms = { brightness: { value: 0 }, viewportHeight: { value: 1 }, time: { value: 0 } };
  const halo = new T.ShaderMaterial({
    transparent: true, depthWrite: false, blending: T.AdditiveBlending, uniforms,
    vertexShader: [
      'attribute vec3 tint;',
      'attribute float radius, phase;',
      'uniform float viewportHeight, time;',
      'varying vec3 lampTint;',
      'varying float sparkle;',
      'void main() {',
      '  lampTint = tint;',
      '  float pulse = .5 + .5 * sin(time * 2.1 + phase * 2.8 + position.x * .85);',
      '  sparkle = pow(pulse, 6.) * smoothstep(.44, .95, fract(phase));',
      '  gl_Position = projectionMatrix * modelViewMatrix * vec4(position, 1.);',
      '  gl_PointSize = clamp((radius + sparkle * .13) * viewportHeight * projectionMatrix[1][1] / gl_Position.w, 3., 76.);',
      '}',
    ].join('\n'),
    fragmentShader: [
      'uniform float brightness;',
      'varying vec3 lampTint;',
      'varying float sparkle;',
      'void main() {',
      '  float distanceFromCenter = length(gl_PointCoord - .5) * 2.;',
      '  float falloff = (1. - smoothstep(.13, 1., distanceFromCenter));',
      '  float core = exp(-22. * distanceFromCenter * distanceFromCenter);',
      '  vec2 delta = abs(gl_PointCoord - .5) * 2.;',
      '  float ray = max(exp(-delta.x * 38.) * exp(-delta.y * 4.1), exp(-delta.y * 38.) * exp(-delta.x * 4.1));',
      '  gl_FragColor = vec4(lampTint, brightness * (.21 * falloff * falloff + (.39 + sparkle * .44) * core + .40 * sparkle * ray));',
      '  #include <colorspace_fragment>',
      '}',
    ].join('\n'),
  });
  const pointLights = new T.Points(geometry, halo);
  parent.add(pointLights);

  const reflection = new T.MeshBasicMaterial({
    color: '#e7a968', transparent: true, depthWrite: false, blending: T.AdditiveBlending,
  });
  for (const [x, z, length, spread] of [[-4.67, 3.80, 1.53, .89], [.37, 3.77, 1.38, 1.16], [8.04, 4.35, 1.30, 2.29], [-7.01, 4.42, 2.6, 1.48], [-11.14, 4.38 + curve(-11.14), 1.90, 2.25]]) {
    for (let i = 0; i < 105; i++) {
      const localZ = (rng() - .5) * length;
      const localX = (rng() - .5) * spread * (.70 + 1.4 * Math.abs(localZ) / length);
      const width = .020 + rng() ** 2 * .18;
      draw.add(new T.PlaneGeometry(width, .010 + rng() * .032), reflection,
        x + localX, .0415, z + localZ, 0, false, -Math.PI / 2);
    }
  }
  return {
    setLight(warm) {
      uniforms.brightness.value = warm * .94;
      reflection.opacity = warm * .17;
      for (const bulb of bulbs.values()) bulb.emissiveIntensity = .08 + warm * 2.1;
    },
    animate(time) { uniforms.time.value = time; },
    resize(height) { uniforms.viewportHeight.value = height; },
  };
}
