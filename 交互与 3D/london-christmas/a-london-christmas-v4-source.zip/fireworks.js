import * as T from 'three';
import { random, v } from './model.js';

const colours = ['#ffd38e', '#f08a8a', '#9ddcff', '#ffc68a', '#d3abff'];
const bursts = [
  [1.08, -2.9, 7.85, -.3, .84], [3.42, 3.11, 8.62, -.58, 1.10],
  [5.91, .52, 9.39, -3.21, 1.16], [8.61, -4.37, 8.48, -1.21, .98],
];

export function fireworks(scene) {
  const rng = random(8462);
  const limit = 79;
  const trails = 5;
  const data = bursts.map(([at, x, y, z, scale], index) => {
    const velocity = Array.from({ length: limit }, (_, i) => {
      const a = i * 2.3999632 + rng() * .13;
      const up = 1 - 2 * (i + .5) / limit;
      const side = Math.sqrt(1 - up * up);
      const speed = scale * (.82 + rng() * .57);
      return v(Math.cos(a) * side * speed, up * speed, Math.sin(a) * side * speed);
    });
    return { at, center: v(x, y, z), velocity, color: new T.Color(colours[index]), radius: scale };
  });
  const size = bursts.length * limit * trails;
  const pos = new Float32Array(size * 3);
  const tint = new Float32Array(size * 3);
  const alpha = new Float32Array(size);
  const geom = new T.BufferGeometry();
  geom.setAttribute('position', new T.BufferAttribute(pos, 3));
  geom.setAttribute('tint', new T.BufferAttribute(tint, 3));
  geom.setAttribute('intensity', new T.BufferAttribute(alpha, 1));
  for (const [index, burst] of data.entries()) {
    for (let i = 0; i < limit * trails; i++) burst.color.toArray(tint, (index * limit * trails + i) * 3);
  }
  const uniforms = { ratio: { value: 1 }, power: { value: .8 } };
  const material = new T.ShaderMaterial({
    uniforms, transparent: true, depthWrite: false, blending: T.AdditiveBlending,
    vertexShader: [
      'uniform float ratio; attribute vec3 tint; attribute float intensity; varying vec3 c; varying float fade;',
      'void main(){ c=tint; fade=intensity; gl_Position=projectionMatrix*modelViewMatrix*vec4(position,1.);',
      'gl_PointSize=(1.5+intensity*3.8)*ratio; }',
    ].join('\n'),
    fragmentShader: [
      'uniform float power; varying vec3 c; varying float fade;',
      'void main(){ vec2 p=(gl_PointCoord-.5)*2.;float d=dot(p,p);',
      'gl_FragColor=vec4(c,power*fade*(exp(-d*9.)*.93+exp(-d*3.)*.22));',
      '#include <colorspace_fragment>',
      '}',
    ].join('\n'),
  });
  const points = new T.Points(geom, material);
  points.frustumCulled = false;
  scene.add(points);
  return {
    update(time, ratio, warm, enabled, isStreet, reduced) {
      points.visible = enabled && warm > .12;
      if (!points.visible) return;
      const phase = reduced ? 3.95 : (time + .48) % 11.7;
      uniforms.ratio.value = ratio;
      uniforms.power.value = .58 + warm * .42;
      alpha.fill(0);
      for (const [index, burst] of data.entries()) {
        const age = phase - burst.at;
        if (age < -.72 || age >= 1.92) continue;
        const bx = burst.center.x + (isStreet ? -3.4 : 0);
        const by = burst.center.y + (isStreet ? .72 : 0);
        const bz = burst.center.z - (isStreet ? 2.6 : 0);
        const offset = index * limit * trails;
        if (age < 0) {
          for (let tail = 0; tail < trails; tail++) {
            const t = Math.max(0, 1 + age / .72 - tail * .04);
            pos.set([bx - .65 * (1 - t), by - 4.4 * (1 - t), bz], (offset + tail) * 3);
            alpha[offset + tail] = .97 - tail * .16;
          }
          continue;
        }
        for (let j = 0; j < limit; j++) for (let k = 0; k < trails; k++) {
          const t = Math.max(0, age - k * .058), pull = (1 - Math.exp(-t * 1.85)) * 1.37;
          const velocity = burst.velocity[j];
          const i = offset + j * trails + k;
          pos.set([bx + velocity.x * pull, by + velocity.y * pull - .54 * t * t, bz + velocity.z * pull], i * 3);
          alpha[i] = Math.max(0, 1 - t / 1.98) * (.67 + .33 * Math.sin(j * 3 + t * 16) ** 2) * (1 - k * .17);
        }
      }
      geom.attributes.position.needsUpdate = true;
      geom.attributes.intensity.needsUpdate = true;
    },
  };
}

