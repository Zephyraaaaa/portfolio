import { random } from './model.js';

export function postcardSnow(canvas) {
  const ctx = canvas.getContext('2d');
  const rng = random(72306);
  const flakes = Array.from({ length: 184 }, () => ({
    x: rng(), y: rng(), size: .7 + rng() ** 2.8 * 4.2, speed: .23 + rng() * .58,
    phase: rng() * 2 * Math.PI, opacity: .20 + rng() * .61,
  }));
  let frame = 0, started = 0;
  let width = 0, height = 0;

  function draw(now) {
    frame = 0;
    const w = innerWidth, h = innerHeight;
    if (width !== w || height !== h) {
      const ratio = Math.min(devicePixelRatio, 1.7);
      canvas.width = Math.round(w * ratio);
      canvas.height = Math.round(h * ratio);
      ctx.setTransform(ratio, 0, 0, ratio, 0, 0);
      width = w;
      height = h;
    }
    ctx.clearRect(0, 0, w, h);
    const time = (now - started) / 1000;
    const gust = Math.max(0, 1 - time / 1.65);
    const count = Math.min(flakes.length, Math.floor(w * h / 3900) + 37);
    for (let i = 0; i < count; i++) {
      const { x, y, size, speed, phase, opacity } = flakes[i];
      const spread = (time * (17 + speed * 32) + Math.sin(time * .8 + phase) * (11 + 25 * speed));
      const px = ((x * w + spread + w) % (w + 24)) - 12;
      const py = ((y * (h + 20) + time * (51 + speed * 74) + 28 * (1 - gust ** 2)) % (h + 20)) - 10;
      const diameter = size * (w < 500 ? .83 : 1);
      ctx.globalAlpha = opacity * (i % 4 === 0 ? 1 : .76);
      ctx.fillStyle = i % 8 === 0 ? '#fce8c9' : '#eef7ff';
      ctx.beginPath();
      ctx.arc(px, py, diameter * .60, 0, Math.PI * 2);
      ctx.fill();
      if (size > 3.35 && i % 2 === 0) {
        ctx.globalAlpha *= .77;
        ctx.strokeStyle = '#f8fcff';
        ctx.lineWidth = .72;
        ctx.beginPath();
        for (let arm = 0; arm < 6; arm++) {
          const angle = phase + arm * Math.PI / 3 + time * .23;
          ctx.moveTo(px, py);
          ctx.lineTo(px + Math.cos(angle) * diameter * 1.53, py + Math.sin(angle) * diameter * 1.53);
        }
        ctx.stroke();
      }
    }
    ctx.globalAlpha = 1;
    frame = requestAnimationFrame(draw);
  }

  return {
    start() {
      if (frame) return;
      canvas.hidden = false;
      started = performance.now();
      frame = requestAnimationFrame(draw);
    },
    stop() {
      cancelAnimationFrame(frame);
      frame = 0;
      canvas.hidden = true;
    },
  };
}

