const dialog = document.getElementById('music-dialog');
const music = document.getElementById('street-music');
const chooser = document.getElementById('track-file');
const button = document.getElementById('music-toggle');
const status = document.getElementById('track-status');
let localUrl;

button.addEventListener('click', () => dialog.showModal());
dialog.querySelector('[autofocus]').addEventListener('click', () => dialog.close());
dialog.addEventListener('close', () => button.focus({ preventScroll: true }));
document.getElementById('local-track').addEventListener('click', () => chooser.click());
document.getElementById('official-track').addEventListener('click', () => music.pause());

async function play(src, title) {
  music.pause();
  if (localUrl && localUrl !== src) URL.revokeObjectURL(localUrl);
  localUrl = src.startsWith('blob:') ? src : undefined;
  music.src = src;
  music.hidden = false;
  music.volume = .65;
  status.textContent = title;
  try {
    await music.play();
  } catch (error) {
    if (error.name === 'AbortError') return;
    status.textContent = error.name === 'NotAllowedError' ? 'Use the play button below to start the track.' :
      'This audio file could not be played. Choose another file.';
  }
}

chooser.addEventListener('change', () => {
  const [file] = chooser.files;
  if (file) play(URL.createObjectURL(file), file.name);
  chooser.value = '';
});
document.getElementById('ambient-track').addEventListener('click', () =>
  play(music.dataset.ambient, 'Regent Street · original video soundtrack'));
music.addEventListener('play', () => button.classList.add('is-playing'));
music.addEventListener('pause', () => button.classList.remove('is-playing'));

