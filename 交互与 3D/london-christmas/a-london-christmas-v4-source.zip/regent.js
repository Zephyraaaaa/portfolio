import * as T from 'three';
import { batch, box, cylinder, mat, random, slab, texture, tube, v } from './model.js';
import { brass, greenery, iron, sign, snow } from './architecture.js';

export const westEnd = -21.95;
export const eastEnd = 10.1;
export const curb = 2.94;
export const farCurb = 7.32;
export const curve = x => -.0235 * Math.min(x + 5.48, 0) ** 2;
const yawAt = x => Math.atan(.047 * Math.min(x + 5.48, 0));
const rng = random(9217);
const limestone = mat('#d6b997');
const cream = mat('#e4ceb0');
const ashlar = mat('#bb9878');
const shadowStone = mat('#9b7b6b');
const roof = mat('#404858');
const lead = mat('#59606e');
const forest = mat('#234638');
const bronze = mat('#463833');
const wine = mat('#7f273e');
const oxblood = mat('#aa3b40');
const panel = mat('#552e34');
const chip = mat('#89716b');
const evergreen = ['#244d42', '#355c46', '#476950'].map(colour => mat(colour));

function brickwork() {
  const map = texture(512, 288, (ctx, w, h) => {
    ctx.fillStyle = '#a07e68'; ctx.fillRect(0, 0, w, h);
    const reds = ['#9e6355', '#aa6b58', '#a26656', '#995e50', '#ab715a'];
    for (let row = 0; row < 16; row++) {
      for (let col = -1; col < 16; col++) {
        const x = col * 32 + row % 2 * 16;
        const y = row * 18;
        ctx.fillStyle = reds[Math.floor(rng() * reds.length)];
        ctx.fillRect(x + 1, y + 1, 30, 16);
        ctx.fillStyle = '#ffcca32e'; ctx.fillRect(x + 1, y + 1, 30, 2);
      }
    }
  });
  map.wrapS = map.wrapT = T.RepeatWrapping;
  map.anisotropy = 8;
  return mat('#fff', { map });
}

function extrude(draw, shape, finish, x, y, z, depth = .07, yaw = 0) {
  draw.add(new T.ExtrudeGeometry(shape, { depth, bevelEnabled: false, curveSegments: 14 }),
    finish, x, y, z, yaw);
}

function archShape(w, h) {
  const top = h - w / 2;
  return new T.Shape().moveTo(-w / 2, 0).lineTo(w / 2, 0).lineTo(w / 2, top)
    .absarc(0, top, w / 2, 0, Math.PI, false).closePath();
}

function windowAssembly(draw, glass, x, y, w, h, { z = .017, arch = false, shop = false, yaw = 0, balcony = false } = {}) {
  const jamb = shop ? bronze : cream;
  const aperture = shop ? panel : shadowStone;
  const at = (localX, yy, zz) => [x + localX * Math.cos(yaw) + zz * Math.sin(yaw), yy, z - localX * Math.sin(yaw) + zz * Math.cos(yaw)];
  const part = (finish, localX, yy, zz, width, height, depth) =>
    box(draw, finish, ...at(localX, yy, zz), width, height, depth, yaw);
  if (arch) {
    const base = y - h / 2;
    extrude(draw, archShape(w + .205, h + .125), jamb, ...at(0, base - .024, .045), .078, yaw);
    extrude(draw, archShape(w + .06, h + .025), aperture, ...at(0, base + .005, .128), .012, yaw);
    const inset = new T.ShapeGeometry(archShape(w - .043, h - .048), 14);
    const uv = inset.attributes.uv;
    for (let i = 0; i < uv.count; i++) uv.setXY(i, uv.getX(i) / w + .5, uv.getY(i) / h);
    draw.add(inset, glass, ...at(0, base + .035, .147), yaw, false);
    const spring = base + h - w / 2;
    const arc = Array.from({ length: 13 }, (_, i) => {
      const angle = i * Math.PI / 12;
      return v(...at(Math.cos(angle) * (w / 2 + .072), spring + Math.sin(angle) * (w / 2 + .086), .142));
    });
    tube(draw, shop ? brass : cream, arc, .025, true, 6);
    part(shop ? brass : cream, 0, base + h + .006, .14, .11, .16, .09);
  } else {
    part(jamb, 0, y, .044, w + .145, h + .11, .145);
    part(aperture, 0, y, .128, w + .035, h + .02, .035);
    draw.add(new T.PlaneGeometry(w, h), glass, ...at(0, y, .152), yaw, false);
    part(cream, 0, y + h / 2 + .095, .08, w + .24, .067, .23);
  }
  part(jamb, 0, y - h * .20, .164, w - .01, .035, .044);
  for (const offset of shop ? [-.25, 0, .25] : [0]) {
    part(jamb, w * offset, y - .07, .168, .040, h - (arch ? .19 : .05), .055);
  }
  part(cream, 0, y - h / 2 - .038, .139, w + .26, .093, .32);
  if (balcony) {
    part(ashlar, 0, y - h / 2 - .106, .26, w + .26, .074, .48);
    part(iron, 0, y - h / 2 + .33, .50, w + .27, .025, .038);
    part(iron, 0, y - h / 2 + .095, .50, w + .25, .021, .032);
    for (let i = 0; i < 8; i++) {
      part(iron, (i / 7 - .5) * (w + .24), y - h / 2 + .195, .50, .017, .276, .022);
    }
  }
}

export function buildDistrict(parent, glass) {
  const bricks = brickwork();
  const bounds = [];
  const decorations = [];
  const lamps = [];
  const houses = [
    { x: -18.42, z: 1.88, yaw: 1.76, w: 3.31, h: 5.36, kind: 'stone', name: 'THE OLD EXCHANGE', awning: forest, phase: .68 },
    { x: -16.94, w: 2.31, h: 5.82, kind: 'stone', name: 'NOEL & SONS', awning: forest, phase: .49 },
    { x: -16.95, w: 2.43, h: 5.11, kind: 'stone', name: 'THE READING ROOM', awning: wine, phase: .45, across: true },
    { x: -14.22, w: 3.5, h: 6.7, kind: 'stone', name: 'WINTER BOOKS', awning: forest, phase: .16 },
    { x: -10.75, w: 3.36, h: 7.68, kind: 'regent', name: 'REGENT HOUSE', awning: wine, phase: .76 },
    { x: -7.32, w: 3.33, h: 7.21, kind: 'regent', name: 'WINTER & CO.', awning: forest, phase: .38 },
    { x: 7.57, w: 4.16, h: 6.61, kind: 'pub', name: 'CROWN & ANCHOR', awning: wine, phase: .66 },
    { x: -14.05, w: 3.46, h: 6.0, kind: 'stone', name: 'THE ARCADE', awning: wine, phase: .61, across: true },
    { x: -10.66, w: 3.29, h: 6.55, kind: 'stone', name: 'THE LANTERN', awning: forest, phase: .42, across: true },
  ];

  for (const { x, w, h, kind, name, awning, phase, across, z, yaw } of houses) {
    const pub = kind === 'pub';
    const palace = kind === 'regent';
    const group = new T.Group();
    const d = across ? 2.43 : 3.86;
    group.position.set(x, 0, z ?? curve(x) + (across ? 9.31 : .38));
    group.rotation.y = yaw ?? yawAt(x) + (across ? Math.PI : 0);
    group.updateMatrix();
    parent.add(group);
    const draw = batch(group);
    const world = (a, y, z) => v(a, y, z).applyMatrix4(group.matrix);
    const columns = palace ? [-w * .39, -w * .137, w * .137, w * .39] : [-w * .40, w * .40];
    const wall = pub ? bricks : phase > .6 ? limestone : ashlar;
    const shell = pub ? roundedPlan(w, d) : [[-w / 2, -d], [w / 2, -d], [w / 2, 0], [-w / 2, 0]];
    slab(draw, wall, shell, .15, h - .15, .035);
    slab(draw, shadowStone, shell, .08, .22, .04);
    if (pub) slab(draw, oxblood, shell, .22, 2.08, .048);
    else {
      for (let row = 0; row < 10; row++) {
        box(draw, row % 3 === 0 ? limestone : wall, 0, .34 + row * .212, .015, w + .085, .18, .083);
      }
    }
    for (const [y, height] of [[2.47, .105], [2.61, .12], [4.27, .083], [h - .28, .122], [h - .095, .145], [h + .036, .102]]) {
      slab(draw, cream, shell, y, height, y > h - .3 ? .091 : .057);
    }
    for (let i = 0; i < Math.floor(w / .14); i++) {
      const dx = -w / 2 + .099 + i * .145;
      if (pub && dx > w / 2 - .55) continue;
      box(draw, ashlar, dx, h - .227, .066, .078, .20, .175);
    }
    for (const dx of columns) {
      for (const [y, height] of [[3.39, 1.53], [5.05, 1.52], [h - .65, .53]]) {
        box(draw, limestone, dx, y, .085, palace ? .151 : .126, height, .145);
        box(draw, cream, dx, y - height / 2 + .075, .087, .215, .128, .175);
        box(draw, cream, dx, y + height / 2 - .073, .098, .208, .135, .192);
      }
      if (palace) {
        cylinder(draw, limestone, dx, 1.29, .13, .089, .125, 1.92, 11);
        cylinder(draw, cream, dx, 2.22, .13, .115, .098, .115, 10);
      }
    }
    const bays = pub ? [-w * .31, -w * .025, w * .239] : [-w * .25, 0, w * .25];
    for (const [i, dx] of bays.entries()) {
      const ww = pub ? .81 : palace ? .67 : .70;
      windowAssembly(draw, glass[i % 3], dx, 1.37, ww + (pub ? .22 : .03), 1.60, { arch: true, shop: true });
      windowAssembly(draw, glass[(i + 1) % 3], dx, 3.48, ww, 1.26, { arch: true, balcony: palace || pub && i === 2 });
      windowAssembly(draw, glass[(i + 2) % 3], dx, 5.10, ww * .84, 1.01, { balcony: palace && i === 1 });
      if (h > 7) windowAssembly(draw, glass[i % 3], dx, 6.36, ww * .72, .81, { arch: i === 1 });
      if (!across) {
        box(draw, bronze, dx, 2.18, .088, .037, .048, .42);
        draw.add(new T.BoxGeometry(ww + .31, .045, .44), awning, dx, 2.17, .32, 0, true, .36);
        box(draw, awning, dx, 2.071, .52, ww + .31, .095, .047);
        const p = world(dx, 2.05, .56);
        decorations.push({ point: p, colour: '#ffd697', radius: .34 });
      }
    }
    if (across) {
      for (const dx of [-w * .24, w * .24]) for (const y of [1.35, 3.42, 4.98]) {
        if (y + .42 > h) continue;
        windowAssembly(draw, glass[y < 3 ? 1 : 2], dx, y, .69, y < 3 ? 1.31 : .95,
          { arch: y < 4, z: -d - .046, yaw: Math.PI });
      }
    }
    if (pub) {
      windowAssembly(draw, glass[1], w / 2 - .26, 1.37, .77, 1.60, { arch: true, shop: true, yaw: .92, z: -.29 });
      for (const y of [3.52, 5.12]) windowAssembly(draw, glass[0], w / 2 - .29, y, .72, 1.22,
        { arch: true, yaw: .92, z: -.30, balcony: y < 4 });
    }


    for (const end of across ? [-1, 1] : pub || phase > .6 ? [1] : []) {
      const sideX = end * (w / 2 + .052);
      const depthStops = across ? [-.60, -1.56] : [-.93, -2.08, -3.19];
      for (const localZ of depthStops) {
        for (const [i, y] of [1.37, 3.47, 5.08].entries()) {
          if (y + .39 > h) continue;
          windowAssembly(draw, glass[(i + 1) % 3], sideX, y, .60, i === 0 ? 1.25 : .95,
            { arch: i < 2, z: localZ, yaw: end * Math.PI / 2, shop: i === 0 });
        }
      }
      for (const zz of [-d + .09, -.11]) {
        for (let i = 0; i < 19; i++) {
          box(draw, i % 2 ? cream : limestone, sideX, .34 + i * (h - .65) / 19, zz, .096, .176,
            i % 2 ? .155 : .232);
        }
      }
      if (pub) {
        for (let i = 0; i < 24; i++) {
          decorations.push({ point: world(sideX + .095, h - .046, -.64 - i * .128), radius: .15 });
        }
      }
    }
    box(draw, pub ? wine : bronze, -.055, 2.36, .08, w - .27, .28, .17);
    sign(draw, -.055, 2.36, .175, w - .34, .253, name, { background: pub ? '#6d2034' : '#313c39' });

    const roofWidth = w - .21;
    const gable = new T.Shape().moveTo(-roofWidth / 2, 0).lineTo(roofWidth / 2, 0)
      .lineTo(roofWidth * .40, .76).lineTo(-roofWidth * .39, .76).closePath();
    extrude(draw, gable, roof, 0, h + .085, -d + .24, d - .54);
    box(draw, lead, 0, h + .855, -d / 2, w * .79, .10, d - .51);
    box(draw, snow, -.055, h + .921, -d / 2, w * .73, .030, d * .60, 0, false);
    for (const dx of [-w * .27, w * .27]) {
      box(draw, roof, dx, h + .455, -.274, .65, .67, .56);
      windowAssembly(draw, glass[2], dx, h + .44, .40, .43, { z: -.027 });
      const cap = new T.Shape().moveTo(-.43, 0).lineTo(.43, 0).lineTo(0, .265).closePath();
      extrude(draw, cap, cream, dx, h + .718, -.26, .43);
      extrude(draw, cap, snow, dx, h + .752, -.271, .45);
    }
    if (phase > .5) {
      box(draw, pub ? bricks : ashlar, w * .34, h + .846, -d + .69, .51, 1.06, .54);
      box(draw, limestone, w * .34, h + 1.39, -d + .69, .62, .108, .60);
      for (const dz of [-.115, .115]) cylinder(draw, wine, w * .34, h + 1.56, -d + .69 + dz, .087, .093, .31, 10);
    }

    for (const dx of [-w * .43, w * .43]) {
      for (let i = 0; i < 18; i++) decorations.push({ point: world(dx, 2.70 + i * (h - 2.95) / 18, .16), radius: .132 });
    }
    for (let i = 0; i < 31; i++) {
      const dx = (i / 30 - .5) * (w + .046);
      decorations.push({ point: world(dx, h - .018, .144), radius: .144 });
      if (i % 2 === 0) decorations.push({ point: world(dx, 2.46 - .084 * Math.sin(i / 30 * Math.PI), .208), radius: .193 });
    }
    if (!across) {
      for (const dx of [-w * .30, w * .30]) {
        greenery(draw, dx, 3.31, .29, .245, .28, 34);
        for (let i = 0; i < 18; i++) {
          const angle = i * 2 * Math.PI / 18;
          decorations.push({ point: world(dx + .25 * Math.cos(angle), 3.31 + .28 * Math.sin(angle), .34), radius: .118 });
        }
        draw.add(new T.SphereGeometry(1, 10, 6).scale(.17, .058, .027), wine, dx, 3.63, .327);
        box(draw, wine, dx - .068, 3.45, .331, .083, .29, .027);
      }
      const light = new T.PointLight(pub ? '#ffb378' : '#ffcb8e', 0, 5.7, 2);
      light.position.copy(world(0, 2.26, .94));
      parent.add(light);
      lamps.push({ light, power: pub ? 14 : 12 });
      if (pub) pubSign(draw, w * .37);
    }

    draw.finish();
    bounds.push(new T.Box3(v(-w / 2, 0, -d), v(w / 2, h, .10)).applyMatrix4(group.matrix));
  }
  return { bounds, decorations, lamps };
}

function roundedPlan(w, d) {
  const right = w / 2;
  const radius = .69;
  const corner = Array.from({ length: 13 }, (_, i) => {
    const angle = i * Math.PI / 24;
    return [right - radius + Math.cos(angle) * radius, -radius + Math.sin(angle) * radius];
  });
  return [[-right, -d], [right, -d], ...corner, [-right, 0]];
}

function pubSign(draw, x) {
  tube(draw, iron, [v(x, 3.72, .20), v(x, 3.72, .93), v(x, 3.61, 1.09)], .035);
  const geo = new T.CylinderGeometry(.285, .285, .062, 20);
  draw.add(geo, wine, x, 3.25, .86, 0, true, 0, Math.PI / 2);
  sign(draw, x - .034, 3.25, .86, .42, .18, 'C & A', { background: '#742e3d', yaw: -Math.PI / 2 });
}

export function planter(draw, x, z, s) {
  cylinder(draw, chip, x, .2 * s + .1, z, .245 * s, .18 * s, .38 * s, 10);
  for (let i = 0; i < 28; i++) {
    const t = i / 28, a = i * 2.39996, r = (.29 - t * .23) * s;
    draw.add(new T.ConeGeometry((.14 - t * .095) * s, .43 * s, 5),
      evergreen[i % 3], x + Math.cos(a) * r, (.49 + t * .84) * s + .06, z + Math.sin(a) * r,
      a, true, .6);
  }
}


