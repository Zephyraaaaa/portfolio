import * as T from 'three';
import { pbr, parcel } from './atlas-finish.js';

const coats = ['#775261', '#464758', '#a18064', '#476256', '#6b3c48', '#44464d'].map(c => pbr(c));
const faces = ['#d5ad95', '#b48165', '#a06b5b', '#d3a587'].map(c => pbr(c));
const boots = pbr('#332e36');

function visitor(draw, x, z, index, yaw) {
  const shade = coats[index % coats.length];
  const scarf = coats[(index + 2) % coats.length];
  const skin = faces[index % faces.length];
  const scale = .57 + (index % 4) * .039;
  const walk = (index % 3 - 1) * .055;
  const spot = (u, y, d) => [x + u * Math.cos(yaw) + d * Math.sin(yaw), y, z - u * Math.sin(yaw) + d * Math.cos(yaw)];
  const form = (material, u, y, d, w, h, l) =>
    draw.add(new T.SphereGeometry(1, 11, 8).scale(w * scale, h * scale, l * scale),
      material, ...spot(u * scale, .067 + y * scale, d * scale), yaw);
  form(shade, 0, .81, 0, .195, .306, .137);
  form(scarf, -.025, 1.093, .027, .124, .058, .103);
  form(skin, 0, 1.226, .015, .092, .117, .089);
  form(boots, .004, 1.286, -.017, .097, .082, .091);
  if (index % 2) {
    form(scarf, 0, 1.315, -.006, .107, .077, .093);
    form(scarf, 0, 1.399, -.005, .033, .033, .029);
  }
  for (const side of [-1, 1]) {
    form(boots, side * .077, .305, side * walk, .067, .276, .064);
    form(boots, side * .078, .067, .034 + side * walk, .071, .056, .110);
    form(shade, side * .173, .851, 0, .056, .182, .053);
    form(skin, side * .179, .675, .015, .042, .055, .039);
  }
  if (index % 3 === 0) parcel(draw, ...spot(scale * .21, .067 + scale * .33, scale * .098), scale * .247, index, yaw + .13);
}

const visitors = {
  trafalgar: [[-4.80, 3.81], [-2.61, 3.99], [-2.08, 4.01], [2.27, 4.39], [3.01, 4.47], [1.39, -1.69]],
  waterloo: [[-3.18, 3.51], [-3.30, 2.88], [3.16, 4.16], [3.26, 3.59], [-2.90, -1.22]],
  regent: [[-3.12, 4.49], [-3.08, 3.96], [3.08, 2.80], [3.19, 2.21], [2.97, -1.68]],
  fortnum: [[-4.03, 1.57], [-2.55, .84], [-1.86, .74], [.30, 1.55], [1.54, 1.94], [4.01, 1.27]],
  bond: [[-4.71, -.03], [-2.24, 4.97], [-1.68, 4.82], [.86, -.13], [1.49, -.08], [3.71, 4.67]],
  annabel: [[-4.86, 2.44], [-4.35, 2.56], [1.61, 2.79], [2.30, 2.70], [4.27, 2.28]],
  selfridges: [[-4.22, 1.31], [-3.69, 1.26], [-2.01, .32], [.62, .53], [1.31, .47], [3.48, 1.18], [4.24, 1.22]],
  oxford: [[-3.67, 4.51], [-3.61, 4.03], [3.52, 4.34], [3.62, 2.83], [-3.46, -.37], [3.57, -1.64]],
  liberty: [[-4.32, 1.88], [-3.80, 1.83], [-1.49, .59], [1.73, .69], [2.36, .67], [3.55, 1.63]],
  carnaby: [[-2.35, 4.56], [-1.72, 4.67], [2.32, 3.62], [2.24, 2.83], [-2.31, -.94], [2.18, -2.63]],
  leicester: [[-4.83, 2.12], [-2.77, 2.65], [-2.22, 2.89], [.12, 2.89], [1.22, 2.14], [4.39, 2.67], [4.94, 2.60], [-.69, -1.42]],
  dials: [[-.92, 1.17], [-1.38, 1.25], [1.72, 1.77], [-2.41, -.54], [2.39, -.97], [.60, -2.93]],
  covent: [[-5.19, 3.52], [-2.57, 3.48], [-2.03, 3.36], [-.12, 2.92], [1.02, 2.82],
    [3.37, 2.26], [5.21, 2.33], [4.66, -3.27], [2.76, -3.00], [1.27, -3.34], [-.52, -3.20]],
};
export function atlasVisitors(draw, id) {
  visitors[id].forEach(([x, z], index) => visitor(draw, x, z, index, index % 3 === 0 ? .63 : -.46));
}

