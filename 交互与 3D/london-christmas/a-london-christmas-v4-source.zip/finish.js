import * as T from 'three';
import { texture } from './model.js';

export function reflections(renderer) {
  const source = texture(512, 256, (ctx, w, h) => {
    const sky = ctx.createLinearGradient(0, 0, 0, h);
    sky.addColorStop(0, '#9bb6dd');
    sky.addColorStop(.38, '#4b648d');
    sky.addColorStop(.51, '#394961');
    sky.addColorStop(.62, '#524654');
    sky.addColorStop(1, '#282332');
    ctx.fillStyle = sky;
    ctx.fillRect(0, 0, w, h);
    for (const [x, y, ww, hh, colour] of [
      [26, 58, 28, 78, '#ffdcab'], [88, 92, 14, 32, '#a5c6ec'], [199, 42, 91, 45, '#e0eaf9'],
      [301, 78, 18, 55, '#ffdaa4'], [337, 83, 25, 48, '#ffe6bf'], [443, 51, 44, 36, '#bdc9f0'],
    ]) {
      ctx.shadowBlur = 13;
      ctx.shadowColor = colour;
      ctx.fillStyle = colour;
      ctx.fillRect(x, y, ww, hh);
    }
  });
  source.mapping = T.EquirectangularReflectionMapping;
  const pmrem = new T.PMREMGenerator(renderer);
  const target = pmrem.fromEquirectangular(source);
  source.dispose();
  pmrem.dispose();
  return target.texture;
}

