import * as T from 'three';
import { random } from './model.js';

export function buildSnow(parent) {
  const rng = random(11422), count = 156;
  const positions = new Float32Array(count * 3);
  const sizes = new Float32Array(count);
  const speeds = new Float32Array(count);
  const seeds = new Float32Array(count);
  for (let i = 0; i < count; i++) {
    positions.set([-19 + rng() * 32, rng() * 11, -3.5 + rng() * 14.2], i * 3);
    sizes[i] = 1.45 + rng() ** 1.9 * 2.40;
    speeds[i] = .27 + rng() * .55;
    seeds[i] = rng() * 6.28;
  }
  const geometry = new T.BufferGeometry();
  for (const [name, values, size] of [['position', positions, 3], ['size', sizes, 1], ['speed', speeds, 1], ['seed', seeds, 1]]) {
    geometry.setAttribute(name, new T.BufferAttribute(values, size));
  }
  const uniforms = { time: { value: 0 }, ratio: { value: 1 }, night: { value: 0 } };
  const material = new T.ShaderMaterial({
    transparent: true, depthWrite: false, uniforms,
    vertexShader: [
      'attribute float size, speed, seed;',
      'uniform float time, ratio;',
      'varying float opacity;',
      'void main() {',
      '  vec3 p = position;',
      '  p.y = mod(p.y - time * speed, 11.0);',
      '  p.x = mod(p.x + 19.0 + time * .17, 32.0) - 19.0 + .16 * sin(seed + time * .83);',
      '  p.z += .13 * cos(time * .60 + seed);',
      '  opacity = smoothstep(.12, .52, p.y) * (1. - smoothstep(10.0, 11., p.y));',
      '  gl_PointSize = size * ratio;',
      '  gl_Position = projectionMatrix * modelViewMatrix * vec4(p, 1.0);',
      '}',
    ].join('\n'),
    fragmentShader: [
      'uniform float night;',
      'varying float opacity;',
      'void main() {',
      '  float edge = 1. - smoothstep(.13, .49, length(gl_PointCoord - .5));',
      '  vec3 tint = mix(vec3(.98,.99,1.), vec3(.78,.87,1.), night);',
      '  gl_FragColor = vec4(tint, edge * opacity * (.70 - night * .13));',
      '}',
    ].join('\n'),
  });
  const flakes = new T.Points(geometry, material);
  flakes.frustumCulled = false;
  parent.add(flakes);
  return {
    update(time) { uniforms.time.value = time; },
    resize(ratio) { uniforms.ratio.value = ratio; },
    setNight(night) { uniforms.night.value = night; },
  };
}


