import * as T from 'three';
import { RoundedBoxGeometry } from 'three/addons/geometries/RoundedBoxGeometry.js';
import { batch, box, cylinder, plane, rounded, slab, texture, tube, v } from './model.js';
import { arch, bell, palette } from './atlas-kit.js';
import { glints, mapBox, metals, parcel, pbr, spruce, strand, texturedStone, velvetBow, woodFinish, wreath } from './atlas-finish.js';

const wainscot = pbr('#bfab91', { roughness: .70 });
const plaster = pbr('#e1cdb2', { roughness: .88 });
const cream = pbr('#e6d2b7', { roughness: .67 });
const alabaster = texturedStone('#b39d8a', 'stone');
const warmBrick = texturedStone('#99624d', 'brick');
const walnut = woodFinish('#533327');
const honey = woodFinish('#936849', true);
const oak = woodFinish('#75513c', true);
const frame = woodFinish('#442d29');
const iron = metals.iron;
const gold = metals.gold;
const whiteChina = pbr('#f0e4c9', { roughness: .28 });
const candleWax = pbr('#ecddc5');
const ember = pbr('#b73d20', { emissive: '#ff541a', emissiveIntensity: .85 });
const amber = pbr('#ffb968', { emissive: '#ff9b53', emissiveIntensity: 2.4, roughness: .49 });
const flameCore = pbr('#fff1c4', { emissive: '#ffae58', emissiveIntensity: 3.3 });
const berry = pbr('#912938', { roughness: .29, metalness: .15 });
const leaves = ['#214633', '#30523e', '#557457'].map(c => pbr(c));
const rugColor = pbr('#e7d8c2', { roughness: .97 });
const glass = new T.MeshPhysicalMaterial({
  color: '#bad7e6', transparent: true, opacity: .21, roughness: .13, metalness: .56, clearcoat: .9,
  side: T.DoubleSide, depthWrite: false,
});
const chinaTea = pbr('#8f4b2d', { roughness: .33, metalness: .03 });

function woven(color, plaid = false) {
  const map = texture(384, 384, (ctx, w, h) => {
    ctx.fillStyle = color; ctx.fillRect(0, 0, w, h);
    if (plaid) {
      for (const [offset, width, ink] of [[12, 56, '#233d38a8'], [66, 5, '#e5d6b5ad'], [106, 14, '#6b263b'], [147, 7, '#c6ac6d9c']]) {
        for (let i = 0; i < 2; i++) {
          ctx.fillStyle = ink;
          ctx.fillRect(offset + i * 192, 0, width, h);
          ctx.fillRect(0, offset + i * 192, w, width);
        }
      }
    }
    ctx.globalAlpha = .16;
    for (let i = 0; i < w; i += 2) {
      ctx.fillStyle = i % 6 === 0 ? '#ffffff' : '#302b35';
      ctx.fillRect(i, 0, 1, h);
      ctx.fillRect(0, i, w, 1);
    }
  });
  map.wrapS = map.wrapT = T.RepeatWrapping;
  map.anisotropy = 8;
  return pbr('#fff', { map, bumpMap: map, bumpScale: .019, roughness: .91 });
}
const redVelvet = woven('#773040');
const greenVelvet = woven('#364b3c');
const plaid = woven('#994051', true);
const cushion = woven('#c8ae90');
const curtain = woven('#b9a283');
const volume = pbr('#29212a', { roughness: .75 });
const logBark = texturedStone('#5a3a2e', 'stone');
const bookSpines = ['#733c43', '#36554a', '#6e594b', '#92775d', '#55516d', '#b89c75'].map(c => pbr(c));

function roundedBox(draw, mat, x, y, z, w, h, d, corner, yaw = 0, roll = 0) {
  draw.add(new RoundedBoxGeometry(w, h, d, 4, corner), mat, x, y, z, yaw, true, 0, roll);
}
function oval(draw, mat, x, y, z, a, b, c, yaw = 0) {
  draw.add(new T.SphereGeometry(1, 16, 12).scale(a, b, c), mat, x, y, z, yaw);
}
function turned(draw, mat, x, y, z, scale) {
  const profile = [[.065, 0], [.104, .04], [.083, .09], [.063, .18], [.102, .31], [.115, .39],
    [.073, .51], [.057, .63], [.102, .72], [.101, .82], [.066, .93], [.079, 1]]
    .map(([r, h]) => new T.Vector2(r * scale, h * scale));
  draw.add(new T.LatheGeometry(profile, 22), mat, x, y, z);
}

function panelling(draw, x, y, z, w, h, yaw = 0) {
  box(draw, wainscot, x, y, z, w, h, .052, yaw);
  const at = (dx, yy) => [x + Math.cos(yaw) * dx + Math.sin(yaw) * .045, y + yy,
    z - Math.sin(yaw) * dx + Math.cos(yaw) * .045];
  for (const side of [-1, 1]) {
    box(draw, cream, ...at(side * w * .469, 0), .039, h * .934, .040, yaw);
    box(draw, cream, ...at(0, side * h * .465), w * .970, .046, .041, yaw);
  }
}

function books(draw) {
  const x = -3.70, z = -3.77;
  mapBox(draw, walnut, x, 2.36, z, 1.91, 4.49, .39, 1.68);
  for (const side of [-1, 1]) mapBox(draw, frame, x + side * .92, 2.36, z + .272, .106, 4.57, .19, 1.7);
  for (let row = 0; row < 6; row++) {
    const y = .83 + row * .606;
    mapBox(draw, honey, x, y, z + .16, 1.80, .071, .59, 1.4);
    for (let i = 0; i < 9; i++) {
      const xx = x - .779 + i * .185;
      const h = .205 + (i * 13 % 5) * .045;
      box(draw, bookSpines[(row + i) % bookSpines.length], xx, y + .039 + h / 2, z + .339, .128 + i % 3 * .021, h, .19);
      box(draw, gold, xx, y + .077, z + .437, .105, .012, .007, 0, false);
      box(draw, gold, xx, y + h - .017, z + .437, .109, .011, .007, 0, false);
    }
    if (row === 4 || row === 2) {
      box(draw, frame, x + .63, y + .29, z + .485, .31, .42, .065, .11);
      box(draw, gold, x + .633, y + .293, z + .519, .275, .386, .018, .11);
      box(draw, bookSpines[row], x + .635, y + .292, z + .535, .224, .30, .008, .11);
      oval(draw, cream, x + .643, y + .32, z + .542, .077, .121, .005, .1);
    }
  }
  mapBox(draw, frame, x, 4.62, z + .078, 2.02, .21, .58, 1.4);
}

function stocking(draw, x, y, z, yaw) {
  const stockingShape = new T.Shape().moveTo(-.12, 0).lineTo(.12, 0).lineTo(.107, -.38)
    .quadraticCurveTo(.236, -.35, .258, -.48).quadraticCurveTo(.255, -.58, .108, -.565)
    .quadraticCurveTo(-.105, -.54, -.132, -.445).closePath();
  draw.add(new T.ExtrudeGeometry(stockingShape, { depth: .04, bevelEnabled: true, bevelSize: .028,
    bevelThickness: .031, bevelSegments: 2 }), redVelvet, x, y, z, yaw, false);
  roundedBox(draw, cushion, x, y + .014, z + .022, .265, .117, .105, .034, yaw);
}

function candle(draw, dots, x, y, z, height = .27) {
  cylinder(draw, gold, x, y + .026, z, .076, .10, .055, 15);
  cylinder(draw, candleWax, x, y + height / 2 + .05, z, .038, .044, height, 16);
  oval(draw, flameCore, x + .002, y + height + .076, z, .018, .049, .018);
  dots.push({ point: v(x, y + height + .081, z + .041), color: '#ffc486', radius: .265 });
}

function garland(draw, dots, x0, x1, y, z) {
  const count = Math.round((x1 - x0) * 65);
  tube(draw, leaves[0], [v(x0, y + .14, z), v((x0 + x1) / 2, y - .049, z),
    v(x1, y + .14, z)], .060, true, 7);
  for (let i = 0; i <= count; i++) {
    const t = i / count, x = x0 + (x1 - x0) * t, a = i * 2.39996;
    const yy = y + .136 - .189 * Math.sin(Math.PI * t);
    const zz = z + .074 * Math.cos(a);
    draw.add(new T.ConeGeometry(.026 + .014 * (i % 3), .219, 6), leaves[i % leaves.length],
      x, yy + .075 * Math.sin(a), zz, 0, false, .44 + Math.sin(a) * .76, a);
    if (i % 7 === 0) {
      oval(draw, berry, x, yy - .069, zz + .07, .038, .041, .041);
      dots.push({ point: v(x, yy + .044, zz + .071), color: '#ffd191', radius: .178 });
    }
  }
}

function fireplace(scene, dots) {
  const group = new T.Group();
  group.position.set(-4.91, 0, -.78);
  group.rotation.y = Math.PI / 2;
  group.updateMatrix();
  scene.add(group);
  const draw = batch(group);
  const local = [];
  const cut = new T.Shape().moveTo(-1.64, 0).lineTo(1.64, 0).lineTo(1.64, 2.25).lineTo(-1.64, 2.25).closePath();
  cut.holes.push(new T.Path(arch(2.26, 1.64).getPoints(15).map(p => p.add(new T.Vector2(0, .23))).reverse()));
  const stoneGeo = new T.ExtrudeGeometry(cut, { depth: .33, bevelEnabled: true, bevelSize: .029,
    bevelThickness: .027, bevelSegments: 2 });
  const uv = stoneGeo.attributes.uv;
  for (let i = 0; i < uv.count; i++) uv.setXY(i, uv.getX(i) * .59, uv.getY(i) * .67);
  draw.add(stoneGeo, alabaster, 0, .071, 0);
  mapBox(draw, warmBrick, 0, .938, .108, 2.30, 1.71, .16, 1.33);
  for (let i = 0; i < 12; i++) {
    const a = i * Math.PI / 11, y = .77 + Math.sin(a) * 1.15;
    draw.add(new T.BoxGeometry(.19, .224, .078), cream, Math.cos(a) * 1.15, y, .374, 0, true, 0, a - Math.PI / 2);
  }
  mapBox(draw, alabaster, 0, .122, .424, 3.58, .199, .94, 1.6);
  mapBox(draw, cream, 0, .266, .507, 3.64, .096, .82, 1.6);
  mapBox(draw, walnut, 0, 2.289, .247, 3.54, .151, .708, 1.61);
  mapBox(draw, honey, 0, 2.389, .252, 3.66, .093, .727, 1.61);
  for (const x of [-1.65, 1.65]) turned(draw, frame, x, .321, .341, 1.89);
  const grateY = .342;
  for (let i = 0; i < 8; i++) {
    box(draw, iron, -.835 + i * .241, .571, .631, .042, .461, .042);
  }
  box(draw, iron, 0, .746, .637, 1.88, .046, .048);
  for (let i = 0; i < 5; i++) {
    draw.add(new T.CylinderGeometry(.092, .102, .83 + .12 * (i % 3), 12), i % 3 ? logBark : ember,
      -.39 + i * .183, grateY + i % 2 * .064, .470 + i % 3 * .063, 0, false, 0, Math.PI / 2 + (i % 2 ? .23 : -.18));
  }
  for (let i = 0; i < 26; i++) oval(draw, i % 3 ? ember : flameCore, -.68 + i % 11 * .135,
    .385 + (i % 4) * .038, .493 + i % 7 * .027, .056, .032, .035);
  wreath(draw, local, 0, 3.45, .192, .637);
  garland(draw, local, -1.69, 1.69, 2.44, .595);
  for (const x of [-1.19, -.49, .27, .97]) stocking(draw, x, 2.26, .578, -.08);
  candle(draw, local, -1.29, 2.457, .420, .36);
  candle(draw, local, -1.02, 2.454, .410, .245);
  candle(draw, local, 1.37, 2.457, .421, .30);
  bell(draw, local, .75, 2.57, .381, .27, -.10);
  draw.finish();
  for (const dot of local) dots.push({ ...dot, point: dot.point.applyMatrix4(group.matrix) });
  const flames = [];
  for (let i = 0; i < 7; i++) {
    const mesh = new T.Mesh(new T.SphereGeometry(1, 12, 8), i % 2 ? amber : flameCore);
    mesh.position.set(-.66 + i * .214, .66, .55 + i % 3 * .032);
    mesh.scale.set(.083 + i % 2 * .017, .284 + i % 3 * .080, .031);
    group.add(mesh);
    flames.push(mesh);
  }
  const light = new T.PointLight('#ff9d4d', 8, 6.4, 2);
  light.position.set(.041, .83, .906);
  group.add(light);
  return time => {
    flames.forEach((flame, i) => {
      const flicker = .5 + .5 * Math.sin(time * (7.8 + i * .23) + i * 2.4);
      flame.scale.y = .18 + .24 * flicker + i % 3 * .044;
      flame.position.y = .415 + flame.scale.y * .78;
      flame.rotation.z = Math.sin(time * 5.8 + i) * .16;
    });
    light.intensity = 9.4 + Math.sin(time * 5.4) * 1.35 + Math.sin(time * 8.1) * .68;
  };
}

function couch(scene, x, z, yaw, twoSeats) {
  const group = new T.Group();
  group.position.set(x, .065, z);
  group.rotation.y = yaw;
  scene.add(group);
  const draw = batch(group);
  const cover = twoSeats ? greenVelvet : redVelvet;
  const w = twoSeats ? 3.03 : 1.35;
  const d = twoSeats ? 1.07 : 1.05;
  roundedBox(draw, cover, 0, .337, 0, w, .49, d, .119);
  roundedBox(draw, cover, 0, .967, -.418, w * .944, 1.03, .37, .162);
  for (const side of [-1, 1]) {
    roundedBox(draw, cover, side * (w / 2 - .13), .804, .026, .28, .68, d, .126);
    for (const zz of [-.348, .345]) turned(draw, walnut, side * (w / 2 - .163), -.008, zz, .201);
  }
  const cushions = twoSeats ? [-.71, .71] : [0];
  for (const xx of cushions) {
    roundedBox(draw, cover, xx, .672, .063, twoSeats ? 1.37 : .938, .221, .84, .103);
    roundedBox(draw, xx < 0 ? cushion : plaid, xx + .075, 1.025, -.184, .48, .485, .216, .107, -.09, xx < 0 ? .22 : -.19);
  }
  draw.finish();
}
function teacup(draw, x, y, z) {
  cylinder(draw, whiteChina, x, y + .011, z, .092, .081, .022, 24);
  const profile = [[.035, 0], [.039, .008], [.046, .047], [.052, .099], [.046, .102], [.041, .091], [.039, .042]]
    .map(([r, h]) => new T.Vector2(r, h));
  draw.add(new T.LatheGeometry(profile, 20), whiteChina, x, y + .021, z);
  cylinder(draw, chinaTea, x, y + .10, z, .043, .040, .008, 16);
  draw.add(new T.TorusGeometry(.032, .007, 6, 16), whiteChina, x + .062, y + .078, z, 0, false);
}
function table(draw, dots) {
  const x = -.23, z = 1.54;
  roundedBox(draw, honey, x, .745, z, 2.58, .139, 1.15, .045);
  roundedBox(draw, walnut, x, .636, z, 2.43, .158, 1.017, .035);
  roundedBox(draw, oak, x, .201, z, 2.34, .076, .993, .027);
  for (const side of [-1, 1]) for (const zz of [-.44, .44]) turned(draw, walnut, x + side * 1.074, .075, z + zz, .598);
  box(draw, plaid, x + .45, .826, z, .64, .029, 1.14);
  box(draw, plaid, x + .45, .678, z + .573, .64, .318, .028);
  for (const [dx, dz] of [[-.66, .23], [-.26, .30]]) teacup(draw, x + dx, .832, z + dz);
  oval(draw, whiteChina, x - .25, .841, z - .16, .19, .020, .17);
  for (let i = 0; i < 7; i++) oval(draw, bookSpines[i % 2 ? 3 : 5],
    x - .26 + Math.cos(i * 2.39996) * .125, .874, z - .15 + Math.sin(i * 2.39996) * .11, .051, .018, .046);
  box(draw, bookSpines[1], x + .94, .856, z - .17, .31, .063, .229, -.14);
  box(draw, cream, x + .94, .864, z - .175, .286, .035, .232, -.14);
  candle(draw, dots, x + .28, .836, z - .267, .31);
  candle(draw, dots, x + .56, .836, z - .15, .22);
  garland(draw, dots, x - .90, x + .09, .899, z - .19);
}

function drape(draw, x, y, z, height, width) {
  const geo = new T.PlaneGeometry(width, height, 24, 22);
  const pos = geo.attributes.position;
  for (let i = 0; i < pos.count; i++) {
    const u = pos.getX(i) / width + .5, t = pos.getY(i) / height + .5;
    pos.setX(i, pos.getX(i) * (.75 + .27 * (1 - t)) + .058 * Math.sin(t * 2.3));
    pos.setZ(i, Math.sin(u * Math.PI * 13) * (.041 + .035 * (1 - t)) + .042 * t);
  }
  geo.computeVertexNormals();
  draw.add(geo, curtain, x, y, z, 0, true);
  box(draw, gold, x + .041, y - height * .14, z + .073, width * .78, .060, .038);
}
function train(scene, draw, x, z) {
  const radius = 1.46;
  for (const r of [radius - .086, radius + .086]) draw.add(new T.TorusGeometry(r, .016, 8, 72),
    iron, x, .121, z, 0, false, -Math.PI / 2);
  for (let i = 0; i < 52; i++) {
    const a = i / 52 * 2 * Math.PI;
    box(draw, frame, x + Math.cos(a) * radius, .088, z + Math.sin(a) * radius, .302, .032, .058, -a);
  }
  const cars = [];
  for (let i = 0; i < 3; i++) {
    const car = new T.Group();
    scene.add(car);
    const parts = batch(car);
    box(parts, i ? bookSpines[1] : redVelvet, 0, .118, 0, .47, .203, .231);
    box(parts, gold, 0, .224, 0, .49, .029, .24);
    if (!i) {
      drawTrainBoiler(parts);
      oval(parts, amber, .282, .206, 0, .040, .039, .039);
    } else parcel(parts, -.016, .238, 0, .182, i);
    for (const dx of [-.145, .145]) for (const zz of [-.124, .124]) {
      parts.add(new T.CylinderGeometry(.069, .069, .034, 12), iron, dx, .049, zz, 0, false, Math.PI / 2);
    }
    parts.finish();
    car.traverse(item => { if (item.isMesh) item.castShadow = false; });
    cars.push(car);
  }
  return time => cars.forEach((car, i) => {
    const a = .42 + time * .71 - i * .366;
    car.position.set(x + Math.cos(a) * radius, .117, z + Math.sin(a) * radius);
    car.rotation.y = -a - Math.PI / 2;
  });
}
function drawTrainBoiler(draw) {
  draw.add(new T.CylinderGeometry(.102, .102, .292, 16), redVelvet, .11, .206, 0, 0, false, 0, Math.PI / 2);
  cylinder(draw, iron, .184, .319, 0, .038, .023, .126, 11);
  roundedBox(draw, frame, -.142, .264, 0, .181, .187, .223, .027);
}

function windowAssembly(scene, draw) {
  const x = .957, z = -4.013, width = 5.65, height = 3.19, y = 2.776;
  const target = new T.WebGLRenderTarget(960, 542, { type: T.HalfFloatType, depthBuffer: true, samples: 2 });
  const screen = new T.Mesh(new T.PlaneGeometry(width, height), new T.MeshBasicMaterial({ map: target.texture, toneMapped: true }));
  screen.position.set(x, y, z - .153);
  scene.add(screen);
  for (const side of [-1, 1]) {
    box(draw, walnut, x + side * width / 2, y, z, .136, height + .155, .212);
    box(draw, cream, x, y + side * height / 2, z + .025, width + .23, .125, .291);
  }
  mapBox(draw, walnut, x, y - height / 2 - .078, z + .103, width + .386, .105, .64, 2.03);
  const casements = [];
  for (const side of [-1, 1]) {
    const pivot = new T.Group();
    pivot.position.set(x + side * (width / 2 - .049), y, z + .026);
    scene.add(pivot);
    const panel = batch(pivot);
    const span = width / 2 - .062;
    const widthPosition = -side * span / 2;
    for (const yy of [-height / 2 + .066, 0, height / 2 - .067]) {
      box(panel, frame, widthPosition, yy, 0, span, yy ? .095 : .057, .102);
    }
    for (let i = 0; i < 4; i++) {
      box(panel, frame, -side * i * span / 3, 0, 0, i % 3 === 0 ? .086 : .039, height, .084);
    }
    panel.add(new T.PlaneGeometry(span - .066, height - .139), glass, widthPosition, 0, .014, 0, false);
    box(panel, gold, -side * (span - .093), -.066, .096, .080, .23, .039);
    tube(panel, gold, [v(-side * (span - .093), -.015, .108), v(-side * (span - .105), -.015, .175),
      v(-side * (span - .202), -.048, .181)], .015);
    panel.finish();
    casements.push({ pivot, side });
  }
  return { target, casements, bounds: new T.Box3(v(x - width / 2, y - height / 2, z - .16),
    v(x + width / 2, y + height / 2, z + .21)) };
}

export function makeSittingRoom(environment, rugImage) {
  const scene = new T.Scene();
  scene.environment = environment;
  scene.environmentIntensity = .46;
  const draw = batch(scene);
  const dots = [];
  const outline = rounded(-5.24, 5.24, -4.30, 4.63, [.22, .22, .22, .22], 8);
  slab(draw, walnut, outline, -.60, .59, .055);
  mapBox(draw, honey, 0, -.001, .16, 10.40, .127, 8.83, 3.27);
  const carpet = new T.Texture(rugImage);
  carpet.colorSpace = T.SRGBColorSpace;
  carpet.anisotropy = 8;
  carpet.needsUpdate = true;
  rugColor.map = carpet;
  rugColor.bumpMap = carpet;
  rugColor.bumpScale = .013;
  const rug = plane(scene, rugColor, -.075, .071, 1.29, 6.36, 4.63);
  rug.receiveShadow = true;
  for (const side of [-1, 1]) for (let i = 0; i < 97; i++) {
    const xx = -.075 - 3.135 + i * .0652;
    box(draw, cushion, xx, .075, 1.29 + side * 2.337, .015, .017, .068 + i % 4 * .009, 0, false);
  }

  box(draw, plaster, -4.995, 2.341, .021, .21, 4.56, 8.43);
  box(draw, plaster, -3.583, 2.347, -4.160, 3.07, 4.57, .227);
  box(draw, plaster, 4.412, 2.347, -4.160, 1.24, 4.57, .227);
  box(draw, plaster, .96, .598, -4.158, 5.72, 1.062, .225);
  box(draw, plaster, .96, 4.512, -4.158, 5.72, .306, .225);
  for (const y of [.146, 1.132, 4.59]) {
    box(draw, cream, 0, y, -4.015, 10.16, .099, .117);
    box(draw, cream, -4.834, y, .006, .132, .103, 8.32);
  }
  for (let i = 0; i < 6; i++) panelling(draw, -4.851, .607, -3.55 + i * 1.39, 1.31, .86, Math.PI / 2);
  for (let i = 0; i < 7; i++) panelling(draw, -4.32 + i * 1.43, .625, -4.028, 1.35, .85);
  for (const x of [-1.97, 3.904]) {
    box(draw, cream, x, 2.358, -3.943, .225, 4.58, .255);
    box(draw, cream, x, 4.458, -3.833, .379, .185, .329);
    box(draw, cream, x, .225, -3.823, .334, .255, .327);
  }
  mapBox(draw, cream, 0, 4.72, -3.979, 10.34, .234, .448, 1.62);
  mapBox(draw, cream, -4.87, 4.72, -.08, .453, .233, 8.03, 1.67);
  for (const z of [-3.52, -2.74]) box(draw, cream, 0, 4.72, z, 10.17, .159, .189);
  for (const x of [-1.925, 3.913]) drape(draw, x, 2.658, -3.58, 3.72, .698);
  tube(draw, gold, [v(-2.38, 4.491, -3.66), v(4.38, 4.491, -3.66)], .025, false, 8);
  books(draw);
  const window = windowAssembly(scene, draw);
  const fire = fireplace(scene, dots);

  couch(scene, 3.34, 2.16, -Math.PI / 2 - .02, true);
  couch(scene, -2.64, 2.94, .36, false);
  couch(scene, -.97, -1.99, .134, false);
  table(draw, dots);
  const treeX = 3.28, treeZ = -1.77;
  spruce(draw, dots, treeX, .072, treeZ, 4.33, { radius: 1.18, seed: 1839 });
  const moveTrain = train(scene, draw, treeX, treeZ);
  for (let i = 0; i < 6; i++) {
    const a = i * 2.39996, r = 1.07 + i % 2 * .13;
    parcel(draw, treeX + Math.cos(a) * r, .073, treeZ + Math.sin(a) * r, .293 + i % 3 * .081, i + 4, a);
  }
  const lx = -.34, lz = -2.71;
  turned(draw, walnut, lx, .087, lz, .892);
  cylinder(draw, honey, lx, .987, lz, .314, .277, .077, 18);
  cylinder(draw, gold, lx, 1.33, lz, .035, .042, .584, 14);
  cylinder(draw, amber, lx, 1.628, lz, .134, .243, .316, 28);
  dots.push({ point: v(lx, 1.532, lz + .228), color: '#ffcb88', radius: .74 });
  candle(draw, dots, -3.70, .868, -3.25, .21);
  draw.finish();
  const sparkles = glints(scene, dots);
  const fill = new T.HemisphereLight('#ffdfb2', '#795345', 1.33);
  const windowLight = new T.DirectionalLight('#d3e8ff', 1.41);
  windowLight.position.set(1.4, 4.7, -4.9);
  const warm = new T.DirectionalLight('#ffcf9e', 1.83);
  warm.position.set(1.36, 7.1, 5.25);
  warm.castShadow = true;
  warm.shadow.mapSize.set(1536, 1536);
  Object.assign(warm.shadow.camera, { left: -8.2, right: 8.2, top: 7.8, bottom: -7.4, near: .3, far: 24 });
  warm.shadow.camera.updateProjectionMatrix();
  warm.shadow.normalBias = .023;
  warm.shadow.bias = -.00021;
  const lamps = new T.PointLight('#ffc37d', 9.2, 6.61, 2);
  lamps.position.set(lx, 1.53, lz + .04);
  const treeLight = new T.PointLight('#ffcc83', 8.9, 5.0, 2);
  treeLight.position.set(treeX - .44, 2.5, treeZ + .31);
  scene.add(fill, windowLight, warm, lamps, treeLight);
  const clock = new T.PerspectiveCamera(37, 960 / 542, .13, 120);
  let opening = 0, isOpen = false;
  return {
    scene, bounds: window.bounds, renderTarget: window.target, exteriorCamera: clock,
    get isOpen() { return isOpen; },
    setOpen(open) { isOpen = open; },
    update(time, dt, height, daylight, reduced) {
      fire(time);
      moveTrain(time);
      sparkles.update(time, height, .83);
      windowLight.intensity = .65 + daylight * 1.35;
      opening += ((isOpen ? 1 : 0) - opening) * (reduced ? 1 : 1 - Math.exp(-8 * dt));
      for (const { pivot, side } of window.casements) pivot.rotation.y = side * opening * 1.24;
    },
  };
}


