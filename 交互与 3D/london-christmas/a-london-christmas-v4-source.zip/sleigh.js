import * as T from 'three';
import { batch, box, mat, random, tube, v } from './model.js';
import { brass, gift } from './architecture.js';

const red = new T.MeshPhysicalMaterial({ color: '#bd3045', metalness: .18, roughness: .30, clearcoat: .8 });
const velvet = mat('#c3404a');
const fur = mat('#fff2dc');
const skin = mat('#f0b68e');
const boot = mat('#332b3a');
const gold = mat('#f1c17b', { emissive: '#ffb86a', emissiveIntensity: .5, metalness: .36, roughness: .28 });
const harness = mat('#693443');
const suede = mat('#9b624b');
const antler = mat('#c99362');
const nose = mat('#a1343d', { emissive: '#ff5d50', emissiveIntensity: .28 });
const sack = mat('#af7650');

function egg(draw, material, x, y, z, rx, ry, rz, roll = 0) {
  draw.add(new T.SphereGeometry(1, 13, 9).scale(rx, ry, rz), material, x, y, z, 0, true, 0, roll);
}

function makeDeer(parent, x, y, z, scale) {
  const deer = new T.Group();
  deer.position.set(x, y, z);
  deer.scale.setScalar(scale);
  parent.add(deer);
  const draw = batch(deer);
  egg(draw, suede, 0, .04, 0, .41, .23, .163);
  egg(draw, suede, .274, .196, 0, .136, .273, .117, -.34);
  egg(draw, suede, .419, .376, 0, .175, .114, .092, -.13);
  egg(draw, antler, .511, .326, 0, .112, .061, .076);
  egg(draw, nose, .604, .329, 0, .043, .043, .046);
  egg(draw, suede, -.411, .17, 0, .14, .069, .061, -.31);
  for (const side of [-1, 1]) {
    egg(draw, boot, .471, .409, side * .077, .016, .017, .012);
    egg(draw, suede, .333, .467, side * .092, .086, .036, .034, -.38);
    const z = side * .081;
    const points = [v(.35, .439, z), v(.297, .569, z * 1.52),
      v(.231, .685, z * 2.1), v(.183, .802, z * 2.2)];
    tube(draw, antler, points, .017, true, 6);
    tube(draw, antler, [v(.255, .643, z * 1.89), v(.334, .712, z * 2.13), v(.356, .762, z * 2.43)], .014);
    tube(draw, antler, [v(.288, .578, z * 1.65), v(.206, .608, z * 2.2)], .012, false);
    for (const p of points.slice(1)) egg(draw, gold, p.x, p.y, p.z, .027, .029, .026);
  }
  draw.add(new T.TorusGeometry(.146, .018, 6, 16).scale(1, .94, .86),
    harness, .199, .15, 0, Math.PI / 2);
  egg(draw, gold, .181, .104, .149, .048, .054, .042);
  draw.finish();
  const legs = [];
  for (const [dx, dz, rest] of [[-.251, -.115, -.41], [-.251, .115, -.21], [.243, -.108, .26], [.243, .108, .44]]) {
    const leg = new T.Group();
    deer.add(leg);
    leg.position.set(dx, -.091, dz);
    const joints = batch(leg);
    tube(joints, suede, [v(0, 0, 0), v(.035, -.16, 0), v(-.038, -.306, 0)], .034, true, 6);
    egg(joints, boot, -.036, -.310, 0, .057, .038, .041);
    joints.finish();
    legs.push({ leg, rest });
  }
  return { deer, legs, height: y };
}

export function buildSleigh(parent) {
  const flight = new T.Group();
  parent.add(flight);
  const draw = batch(flight);
  const silhouette = new T.Shape().moveTo(-.99, .13).quadraticCurveTo(-1.21, .45, -1.09, .83)
    .quadraticCurveTo(-.87, .66, -.52, .56).lineTo(.45, .53).quadraticCurveTo(.70, .60, .79, .77)
    .quadraticCurveTo(.94, .68, .78, .44).quadraticCurveTo(.61, .19, .37, .125).closePath();
  for (const z of [-.34, .34]) {
    draw.add(new T.ExtrudeGeometry(silhouette, { depth: .073, bevelEnabled: true, bevelThickness: .032,
      bevelSize: .032, bevelSegments: 2, curveSegments: 15 }), red, 0, 0, z - .037);
    tube(draw, gold, [v(-1.02, .75, z + .045), v(-.80, .63, z + .045), v(-.50, .56, z + .045),
      v(.23, .54, z + .045), v(.56, .58, z + .045), v(.77, .72, z + .045)], .025, true, 8);
    tube(draw, gold, [v(-1.14, -.133, z), v(-.62, -.15, z), v(.24, -.147, z),
      v(.75, -.12, z), v(.98, .006, z), v(.96, .19, z)], .030, true, 8);
    for (const x of [-.74, .45]) tube(draw, brass, [v(x, -.13, z), v(x - .09, .08, z), v(x, .19, z)], .030, true, 7);
    for (let i = 0; i < 12; i++) egg(draw, gold, -.84 + i * .132, .276 + .082 * Math.sin(i * .32), z + Math.sign(z) * .054,
      .025, .027, .020);
  }
  box(draw, red, -.17, .198, 0, 1.44, .17, .64);
  box(draw, harness, -.43, .443, 0, .51, .16, .58);
  egg(draw, sack, -.78, .683, -.117, .35, .38, .274, -.29);
  gift(draw, -.88, .72, .184, .21, mat('#305747'), .31);
  gift(draw, -.66, .76, .157, .16, mat('#927197'), -.28);
  egg(draw, velvet, -.145, .747, .01, .257, .305, .226, .28);
  egg(draw, boot, -.13, .546, .014, .223, .081, .222);
  egg(draw, fur, -.072, .966, .020, .185, .054, .181);
  egg(draw, skin, -.028, 1.111, .025, .154, .171, .149);
  egg(draw, fur, .059, 1.025, .046, .136, .123, .138, -.24);
  egg(draw, skin, .120, 1.126, .057, .050, .040, .042);
  egg(draw, boot, .092, 1.166, .112, .012, .015, .010);
  egg(draw, velvet, -.065, 1.28, .015, .177, .125, .158, .37);
  egg(draw, velvet, -.180, 1.322, .021, .155, .088, .104, .40);
  egg(draw, fur, -.033, 1.216, .020, .180, .040, .162);
  egg(draw, fur, -.311, 1.310, .036, .050, .052, .049);
  egg(draw, velvet, .152, .826, -.129, .202, .084, .075, .24);
  egg(draw, fur, .313, .852, -.122, .063, .057, .053);
  draw.finish();

  const arm = new T.Group();
  arm.position.set(-.013, .916, .206);
  flight.add(arm);
  const waving = batch(arm);
  egg(waving, velvet, .078, .145, .03, .081, .195, .076, -.49);
  egg(waving, fur, .163, .285, .031, .071, .047, .069);
  egg(waving, skin, .176, .338, .034, .059, .082, .044);
  waving.finish();

  const team = [
    makeDeer(flight, 1.43, .49, -.30, .85),
    makeDeer(flight, 1.57, .44, .28, .91),
    makeDeer(flight, 2.58, .62, .01, .84),
  ];
  const reins = batch(flight);
  for (const side of [-1, 1]) {
    tube(reins, harness, [v(.31, .86, side * .22), v(.90, .58, side * .3), v(1.70, .64, side * .37),
      v(2.82, .84, side * .06)], .018);
  }
  reins.finish();

  const sparks = 64;
  const positions = new Float32Array(sparks * 3);
  const origins = Array.from({ length: sparks }, (_, i) => i / sparks);
  const rand = random(410);
  const wiggles = Array.from({ length: sparks }, () => rand() - .5);
  const geometry = new T.BufferGeometry();
  geometry.setAttribute('position', new T.BufferAttribute(positions, 3));
  const material = new T.PointsMaterial({ color: '#ffc98a', size: .048, transparent: true, opacity: .63,
    depthWrite: false, blending: T.AdditiveBlending });
  const tail = new T.Points(geometry, material);
  tail.frustumCulled = false;
  flight.add(tail);

  function update(time, still) {
    const trip = ((time + 7.25) % 20) / 20;
    const x = still ? 1.5 : -24 + 42 * trip;
    const sway = Math.sin(time * .84);
    flight.position.set(x, 9.17 + .45 * Math.sin(trip * Math.PI) + sway * .12, 1.62 + Math.sin(trip * Math.PI) * .58);
    flight.rotation.z = .04 + sway * .023;
    arm.rotation.z = -.41 + .29 * Math.sin(time * 6.2);
    for (const [i, { deer, legs, height }] of team.entries()) {
      deer.position.y = height + .08 * Math.sin(time * 5.8 + i * .57);
      deer.rotation.z = .11 * Math.sin(time * 5.8 + i * .57);
      for (const [j, { leg, rest }] of legs.entries()) leg.rotation.z = rest + .31 * Math.sin(time * 5.8 + j * 1.7 + i * .67);
    }
    for (let i = 0; i < sparks; i++) {
      const age = (origins[i] + time * .23) % 1;
      positions[i * 3] = -1.1 - age * 2.9;
      positions[i * 3 + 1] = -.03 + age * wiggles[i] * .85;
      positions[i * 3 + 2] = wiggles[i] * (.16 + age * .77);
    }
    geometry.attributes.position.needsUpdate = true;
  }

  flight.traverse(object => { if (object.isMesh) object.castShadow = false; });
  return { update, setLight(warm) { gold.emissiveIntensity = .32 + warm * 1.55; } };
}


