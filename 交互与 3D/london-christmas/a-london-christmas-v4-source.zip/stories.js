import { gsap } from 'gsap';
import { texture } from './model.js';
import { postcardSnow } from './postcard-snow.js';

export function journalCovers() {
  const issues = [
    { ink: '#1e443a', trim: '#d8bf8e', title: ['Evergreens', 'on the step'] },
    { ink: '#263a55', trim: '#ebbb7c', title: ['The last bus', 'up Regent Street'] },
  ];
  return issues.map(({ ink, trim, title }, issue) => texture(320, 440, (ctx, w, h) => {
    ctx.fillStyle = ink; ctx.fillRect(0, 0, w, h);
    ctx.strokeStyle = trim; ctx.fillStyle = trim;
    ctx.lineWidth = 2;
    ctx.strokeRect(15, 15, w - 30, h - 30);
    ctx.strokeRect(22, 22, w - 44, h - 44);
    ctx.textAlign = 'center';
    ctx.font = 'bold 13px Georgia';
    ctx.fillText('F I E L D   E D I T I O N S', 160, 54);
    ctx.fillRect(46, 67, 228, 1);
    ctx.font = 'italic 36px Georgia';
    title.forEach((line, i) => ctx.fillText(line, 160, 112 + i * 40));
    ctx.beginPath();
    ctx.arc(160, 256, 75, 0, 2 * Math.PI);
    ctx.stroke();
    if (issue === 0) {
      ctx.save();
      ctx.translate(96, 296);
      ctx.rotate(-.27);
      ctx.strokeStyle = trim;
      ctx.lineWidth = 3;
      ctx.beginPath();
      ctx.moveTo(0, 0);
      ctx.quadraticCurveTo(74, -28, 130, -68);
      ctx.stroke();
      for (const [x, y, angle] of [[31, -13, -2.15], [53, -20, .45], [73, -33, -1.86], [102, -51, .18]]) {
        ctx.save();
        ctx.translate(x, y);
        ctx.rotate(angle);
        ctx.fillStyle = '#7e9673';
        ctx.beginPath(); ctx.moveTo(0, 0);
        ctx.quadraticCurveTo(10, -7, 10, -17); ctx.quadraticCurveTo(19, -14, 24, -25);
        ctx.quadraticCurveTo(34, -19, 50, -21); ctx.quadraticCurveTo(44, -11, 48, -6);
        ctx.quadraticCurveTo(37, -6, 34, 2); ctx.quadraticCurveTo(26, -4, 22, 5);
        ctx.quadraticCurveTo(11, 1, 0, 0); ctx.fill();
        ctx.strokeStyle = '#c5c696';
        ctx.lineWidth = 1;
        ctx.beginPath(); ctx.moveTo(3, 0); ctx.lineTo(40, -15); ctx.stroke();
        ctx.restore();
      }
      for (const [x, y] of [[69, -28], [81, -20], [87, -30]]) {
        ctx.fillStyle = '#c6544e';
        ctx.beginPath(); ctx.arc(x, y, 6, 0, 2 * Math.PI); ctx.fill();
      }
      ctx.restore();
    } else {
      ctx.fillStyle = '#aa4243';
      ctx.beginPath(); ctx.roundRect(97, 223, 126, 62, 9); ctx.fill();
      ctx.fillStyle = trim;
      ctx.fillRect(99, 253, 122, 3);
      for (const y of [231, 260]) for (let i = 0; i < 6; i++) ctx.fillRect(105 + 18 * i, y, 14, 13);
      for (const x of [119, 201]) {
        ctx.fillStyle = '#152338';
        ctx.beginPath(); ctx.arc(x, 286, 11, 0, 2 * Math.PI); ctx.fill();
        ctx.fillStyle = trim;
        ctx.beginPath(); ctx.arc(x, 286, 4, 0, 2 * Math.PI); ctx.fill();
      }
      ctx.strokeStyle = trim;
      ctx.beginPath(); ctx.moveTo(97, 303); ctx.lineTo(223, 303); ctx.stroke();
    }
    ctx.fillStyle = trim;
    ctx.font = 'bold 12px Georgia';
    ctx.fillText('T H E   L O N D O N   I S S U E', 160, 365);
    ctx.fillText(issue === 0 ? 'CHAPTER 01   ·   WINTER GREEN' : 'CHAPTER 02   ·   AFTER HOURS', 160, 389);
  }));
}

export function prepareStories(covers, reduced, cast, onClose) {
  const postcard = document.querySelector('#london-postcard');

  const journal = document.querySelector('#street-journal');
  const conversation = document.querySelector('#street-conversation');
  const dialogs = [postcard, journal, conversation];
  const snow = postcardSnow(postcard.querySelector('.postcard-snow'));
  const castList = conversation.querySelector('.conversation-cast');
  const topics = conversation.querySelector('.conversation-topics');
  const reply = conversation.querySelector('#conversation-reply');
  const characters = new Map(cast.map(character => [character.id, character]));
  for (const { id, name } of cast) {
    const button = document.createElement('button');
    button.type = 'button';
    button.dataset.person = id;
    button.textContent = name;
    button.addEventListener('click', () => selectCharacter(id));
    castList.append(button);
  }

  function selectCharacter(id) {
    const character = characters.get(id) ?? cast[0];
    conversation.querySelector('#conversation-title').textContent = character.name;
    conversation.querySelector('#conversation-role').textContent = character.role;
    conversation.querySelector('#conversation-intro').textContent = character.intro;
    for (const button of castList.children) {
      button.setAttribute('aria-pressed', String(button.dataset.person === character.id));
    }
    reply.textContent = '';
    topics.replaceChildren(...character.topics.map(([label, answer]) => {
      const button = document.createElement('button');
      button.type = 'button';
      button.textContent = label;
      button.setAttribute('aria-pressed', 'false');
      button.addEventListener('click', () => {
        for (const option of topics.children) option.setAttribute('aria-pressed', String(option === button));
        reply.textContent = answer;
      });
      return button;
    }));
  }

  const artwork = postcard.querySelector('.postcard-artwork');
  const swing = artwork.querySelector('.postcard-swing');
  const paper = artwork.querySelector('.postcard-perspective');
  const clip = document.querySelector('#postcard-reveal');
  const ns = 'http://www.w3.org/2000/svg';
  const bands = Array.from({ length: 9 }, (_, index) => {
    const rect = document.createElementNS(ns, 'rect');
    rect.setAttribute('y', index * .113 - .007);
    rect.setAttribute('height', .137);
    rect.setAttribute('rx', .071);
    rect.setAttribute('ry', .068);
    clip.append(rect);
    return { rect, right: index % 2 !== 0, width: 0 };
  });
  const pages = [...journal.querySelectorAll('[data-journal-page]')];
  const buttons = [...journal.querySelectorAll('[data-page-step]')];
  pages.forEach((page, i) => {
    page.querySelector('[data-journal-cover]').src = covers[i].image.toDataURL();
  });
  let currentPage = 0;
  function showPage(index) {
    currentPage = Math.max(0, Math.min(pages.length - 1, index));
    pages.forEach((page, i) => { page.hidden = i !== currentPage; });
    buttons[0].disabled = currentPage === 0;
    buttons[1].disabled = currentPage === pages.length - 1;
    journal.querySelector('#journal-page-number').textContent = '0' + (currentPage + 1) + ' / 0' + pages.length;
  }
  buttons.forEach(button => button.addEventListener('click', () => showPage(currentPage + Number(button.dataset.pageStep))));

  let animation, opener;
  function clearPointer() {
    for (const name of ['tilt-x', 'tilt-y', 'paper-x', 'paper-y', 'scene-x', 'scene-y', 'branches-x', 'branches-y']) {
      paper.style.removeProperty('--' + name);
    }
  }
  function stopMotion() {
    animation?.kill();
    animation = undefined;
    gsap.set(swing, { clearProps: 'transform' });
    delete artwork.dataset.revealing;
    delete artwork.dataset.rocking;
    clearPointer();
  }
  function playPostcard() {
    stopMotion();
    if (reduced.matches) return;
    snow.start();
    artwork.dataset.revealing = '';
    const drawBand = band => {
      band.rect.setAttribute('x', band.right ? 1.07 - band.width : -.07);
      band.rect.setAttribute('width', band.width);
    };
    animation = gsap.timeline();
    bands.forEach((band, index) => {
      band.width = 0;
      drawBand(band);
      animation.to(band, {
        width: 1.14, duration: .52, ease: 'power3.inOut', onUpdate: () => drawBand(band),
      }, index * .052);
    });
    animation.call(() => {
      delete artwork.dataset.revealing;
      artwork.dataset.rocking = '';
    });
    animation.to(swing, { rotationY: -16, rotationX: 2.8, duration: .32, ease: 'sine.out' });
    animation.to(swing, { rotationY: 12, rotationX: -1.8, duration: .50, ease: 'sine.inOut' });
    animation.to(swing, { rotationY: -4.5, rotationX: .7, duration: .39, ease: 'sine.inOut' });
    animation.to(swing, { rotationY: 0, rotationX: 0, duration: .34, ease: 'sine.inOut' });
    animation.call(stopMotion);
  }
  artwork.addEventListener('pointermove', event => {
    if (event.pointerType !== 'mouse' || reduced.matches ||
        artwork.hasAttribute('data-revealing') || artwork.hasAttribute('data-rocking')) return;
    const { left, top, width, height } = artwork.getBoundingClientRect();
    const unit = value => Math.max(-1, Math.min(1, value * 2 - 1));
    const x = unit((event.clientX - left) / width), y = unit((event.clientY - top) / height);
    for (const [key, value] of Object.entries({
      'tilt-x': -y * 4.3 + 'deg', 'tilt-y': x * 8.5 + 'deg',
      'paper-x': x * 2.8 + 'px', 'paper-y': y * 2.0 + 'px',
      'scene-x': -x * 7 + 'px', 'scene-y': -y * 4 + 'px',
      'branches-x': x * 8 + 'px', 'branches-y': y * 5 + 'px',
    })) paper.style.setProperty('--' + key, value);
  });
  artwork.addEventListener('pointerleave', clearPointer);
  reduced.addEventListener('change', () => {
    if (reduced.matches) {
      stopMotion();
      snow.stop();
    } else if (postcard.open) snow.start();
  });

  for (const dialog of dialogs) {
    dialog.querySelector('button[autofocus]').addEventListener('click', () => dialog.close());
    let pressedBackdrop = false;
    const isBackdrop = event => {
      if (event.target !== dialog) return false;
      const bounds = dialog.getBoundingClientRect();
      return event.clientX < bounds.left || event.clientX > bounds.right ||
        event.clientY < bounds.top || event.clientY > bounds.bottom;
    };
    // Touch can send a click to the new modal immediately after the scene's pointerup.
    dialog.addEventListener('pointerdown', event => { pressedBackdrop = isBackdrop(event); });
    dialog.addEventListener('pointercancel', () => { pressedBackdrop = false; });
    dialog.addEventListener('click', event => {
      if (pressedBackdrop && isBackdrop(event)) dialog.close();
      pressedBackdrop = false;
    });
    dialog.addEventListener('close', () => {
      pressedBackdrop = false;
      if (dialog === postcard) {
        stopMotion();
        snow.stop();
      }
      opener?.focus({ preventScroll: true });
      opener = undefined;
      onClose(dialog);
    });
  }
  return {
    get holdCamera() { return postcard.open || conversation.open; },
    open(story, source) {
      if (dialogs.some(dialog => dialog.open)) return false;
      opener = source;
      if (story === 'postcard') {
        postcard.showModal();
        playPostcard();
      } else if (story === 'journal') {
        showPage(0);
        journal.showModal();
      } else {
        selectCharacter(story.split(':')[1]);
        conversation.showModal();
      }
      return true;
    },
  };
}
