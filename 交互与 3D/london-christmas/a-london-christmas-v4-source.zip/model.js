import * as T from 'three';
import { mergeGeometries } from 'three/addons/utils/BufferGeometryUtils.js';

export const v = (x, y, z) => new T.Vector3(x, y, z);
export const tau = Math.PI * 2;
export const mix = T.MathUtils.lerp;
export const clamp = T.MathUtils.clamp;
export function mat(color, options) {
  const material = new T.MeshStandardMaterial({ color, roughness: .88, ...options });
  // Shape the diffuse light in soft bands while leaving the physical specular lobe intact.
  material.onBeforeCompile = shader => {
    shader.fragmentShader = shader.fragmentShader.replace('#include <lights_fragment_end>', [
      '#include <lights_fragment_end>',
      'float litLuma = dot(reflectedLight.directDiffuse, vec3(.2126, .7152, .0722));',
      'float pigment = max(.035, dot(diffuseColor.rgb, vec3(.2126, .7152, .0722)));',
      'float incidence = litLuma / pigment;',
      'float band = .095 * smoothstep(.045, .085, incidence) + .28 * smoothstep(.18, .27, incidence)',
      '    + .34 * smoothstep(.41, .51, incidence) + .28 * smoothstep(.76, .91, incidence);',
      'float toonWeight = .14 * (1. - smoothstep(.93, 1.3, incidence));',
      'reflectedLight.directDiffuse *= mix(1., band / max(.03, incidence), toonWeight);',
    ].join('\n'));
  };
  return material;
}
export function random(seed) {
  return () => {
    let n = seed += 0x6D2B79F5;
    n = Math.imul(n ^ n >>> 15, n | 1);
    n ^= n + Math.imul(n ^ n >>> 7, n | 61);
    return ((n ^ n >>> 14) >>> 0) / 4294967296;
  };
}

export function batch(parent) {
  const sets = new Map();
  const transform = new T.Object3D();
  return {
    add(geometry, material, x = 0, y = 0, z = 0, yaw = 0, cast = true, pitch = 0, roll = 0) {
      const key = material.uuid + cast;
      if (!sets.has(key)) sets.set(key, { material, cast, items: [] });
      transform.position.set(x, y, z);
      transform.rotation.set(pitch, yaw, roll, 'YXZ');
      transform.updateMatrix();
      const shape = geometry.index ? geometry.toNonIndexed() : geometry.clone();
      shape.applyMatrix4(transform.matrix);
      sets.get(key).items.push(shape);
      geometry.dispose();
    },
    finish() {
      for (const { material, cast, items } of sets.values()) {
        const mesh = new T.Mesh(mergeGeometries(items), material);
        mesh.castShadow = cast;
        mesh.receiveShadow = true;
        parent.add(mesh);
        items.forEach(item => item.dispose());
      }
      sets.clear();
    },
  };
}

export function box(draw, material, x, y, z, width, height, depth, yaw = 0, cast = true) {
  draw.add(new T.BoxGeometry(width, height, depth), material, x, y, z, yaw, cast);
}

export function cylinder(draw, material, x, y, z, top, bottom, height, sides = 12) {
  draw.add(new T.CylinderGeometry(top, bottom, height, sides), material, x, y, z);
}

export function tube(draw, material, points, radius, smooth = true, sides = 5, cast = false) {
  const curve = smooth ? new T.CatmullRomCurve3(points) : new T.LineCurve3(points[0], points[1]);
  draw.add(new T.TubeGeometry(curve, smooth ? Math.max(8, points.length * 3) : 1, radius, sides),
    material, 0, 0, 0, 0, cast);
}

export function rounded(left, right, back, front, radii, steps = 14) {
  const centers = [
    [right - radii[0], front - radii[0]], [left + radii[1], front - radii[1]],
    [left + radii[2], back + radii[2]], [right - radii[3], back + radii[3]],
  ];
  return centers.flatMap(([x, z], corner) => {
    const radius = radii[corner];
    if (radius === 0) return [[x, z]];
    return Array.from({ length: steps + 1 }, (_, i) => {
      const angle = (corner + i / steps) * Math.PI / 2;
      return [x + Math.cos(angle) * radius, z + Math.sin(angle) * radius];
    });
  });
}

export function slab(draw, material, contour, y, depth, bevel = 0, cast = true, hole) {
  const shape = new T.Shape(contour.map(([x, z]) => new T.Vector2(x, -z)));
  if (hole) shape.holes.push(new T.Path(hole.map(([x, z]) => new T.Vector2(x, -z)).reverse()));
  const geometry = new T.ExtrudeGeometry(shape, {
    depth, bevelEnabled: bevel > 0, bevelSegments: 2, bevelThickness: bevel, bevelSize: bevel, steps: 1,
  });
  geometry.rotateX(-Math.PI / 2);
  draw.add(geometry, material, 0, y, 0, 0, cast);
}

export function texture(width, height, paint) {
  const canvas = document.createElement('canvas');
  canvas.width = width;
  canvas.height = height;
  paint(canvas.getContext('2d'), width, height);
  const map = new T.CanvasTexture(canvas);
  map.colorSpace = T.SRGBColorSpace;
  return map;
}

export function plane(parent, material, x, y, z, width, depth) {
  const mesh = new T.Mesh(new T.PlaneGeometry(width, depth), material);
  mesh.rotation.x = -Math.PI / 2;
  mesh.position.set(x, y, z);
  parent.add(mesh);
  return mesh;
}


